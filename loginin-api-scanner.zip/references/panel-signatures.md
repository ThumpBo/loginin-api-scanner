# 管理后台指纹识别库 (Admin Panel Fingerprints)

## 文件用途

本文件为 Active Deep Dive 阶段提供管理后台路径字典和指纹识别模式。
当被动扫描未发现 Critical/High 漏洞时，自动探测下列路径，查找隐藏的管理功能。

---

## 一、通用管理路径 (优先级排序)

### Tier 1 — 最常见 (80% 覆盖)
```
/admin
/manager
/console
/dashboard
/backend
/system
/manage
/panel
/cp
/cms
/config
/setup
/install
/administrator
/administration
```

### Tier 2 — Web 服务器/中间件
```
/phpmyadmin
/phpMyAdmin
/mysql
/db
/dbadmin
/pgadmin
/adminer
/rockmongo
/mongo
/redis
/memcached
/info.php
/phpinfo.php
/test.php
/server-status
/server-info
/actuator
/actuator/health
/actuator/env
/actuator/mappings
/.env
/.git/config
/.svn/entries
/.DS_Store
```

### Tier 3 — 应用服务器
```
/jmx-console
/jboss-admin
/weblogic
/console
/web-console
/jenkins
/jenkins/login
/solr
/solr/admin
/grafana
/kibana
/kibana/app
/nifi
/rabbitmq
/resin
/tomcat
/tomcat/manager
/zabbix
/nagios
/prometheus
/prometheus/targets
```

### Tier 4 — 框架特定
```
# Spring Boot
/actuator/mappings
/actuator/beans
/actuator/heapdump
/actuator/loggers
/actuator/jolokia
/swagger-ui.html
/swagger-ui/index.html
/api-docs
/v2/api-docs
/v3/api-docs

# Django
/admin/
/django-admin/
/accounts/login/
/api-auth/login/

# Laravel
/horizon
/telescope
/nova
/debugbar

# Rails
/rails/info
/rails/mailers
/sidekiq

# Express/Koa
/graphql
/graphiql
/api/graphql

# Flask
/admin/
/flask-admin/
```

---

## 二、CMS 特定管理路径

### WordPress
```
/wp-admin
/wp-admin/admin-ajax.php
/wp-login.php
/wp-json/wp/v2/users
/xmlrpc.php
/wp-config.php.bak
/wp-content/debug.log
```

### Drupal
```
/user/login
/admin/config
/admin/content
/admin/modules
/node
/update.php
```

### Joomla
```
/administrator
/administrator/index.php
/administrator/manifests/files/joomla.xml
```

### 国产CMS
```
# 若依 (RuoYi)
/admin
/RuoYi
/dev-api/captchaImage
/prod-api/login
/profile

# 通达OA
/general
/ispirit/login
/module
/attachment

# 泛微OA
/login/Login.jsp
/weaver/weaver.file
/services

# 致远OA
/seeyon
/seeyon/main.do

# 用友
/admin
/service
/yyoa

# 万户OA
/defaultroot
/ewebeditor

# JEECG
/jeecg-boot
/sys/login
/sys/common
```

---

## 三、框架管理端点指纹

### Spring Boot Actuator
```
GET /actuator → HTTP 200 + JSON {"_links": {...}}
GET /actuator/env → 敏感配置泄露
GET /actuator/mappings → 所有路由映射
GET /actuator/heapdump → JVM堆转储（含所有内存数据）
标志: 响应 Content-Type = application/vnd.spring-boot.actuator
```

### Django Admin
```
GET /admin/login/?next=/admin/ → HTTP 200 + "Django administration"
标志: csrfmiddlewaretoken + "Log in | Django site admin"
```

### Laravel
```
GET / → Cookie: laravel_session
标志: X-Powered-By: PHP/8.x + laravel_session Cookie
Horizon: GET /horizon → "Laravel Horizon"
Telescope: GET /telescope → JSON API
```

### Rails
```
标志: Server: 头包含 puma/unicorn/passenger
管理: GET /sidekiq → HTTP 200 + "Sidekiq"
       GET /rails/mailers → Action Mailer 预览
```

### PHPMyAdmin
```
GET /phpmyadmin → HTTP 200 + "phpMyAdmin"
GET /phpMyAdmin → 同上（大小写变体）
标志: Cookie: phpMyAdmin + 响应含 pma_ 前缀CSS类
```

---

## 四、响应指纹识别

### 按页面标题识别
| 标题特征 | 可能的技术栈 |
|---------|------------|
| "若依" / "RuoYi" | 若依管理系统 |
| "通达" / "TongDa" | 通达OA |
| "泛微" / "Weaver" | 泛微OA |
| "phpMyAdmin" | PHPMyAdmin |
| "Django administration" | Django Admin |
| "Swagger UI" | Swagger (OpenAPI) |
| "Grafana" | Grafana |
| "Jenkins" | Jenkins |
| "Apache Tomcat" | Tomcat Manager |
| "RabbitMQ Management" | RabbitMQ |
| "nGrinder" | nGrinder |

### 按 HTTP 响应头识别
| 响应头 | 识别结果 |
|--------|---------|
| `X-Powered-By: PHP/8.x` | PHP 应用（Laravel/ThinkPHP/Yii等） |
| `Server: nginx` + `X-Drupal-Cache` | Drupal |
| `X-Generator: Drupal` | Drupal |
| `Set-Cookie: JSESSIONID` | Java Web 应用（Spring/Tomcat等） |
| `Set-Cookie: laravel_session` | Laravel |
| `Set-Cookie: _csrf` + `X-Powered-By: Express` | Express.js |
| `X-Runtime:` | Ruby on Rails |
| `Server: Werkzeug` | Flask |
| `X-Django-Version:` | Django (少见) |
| `X-AspNet-Version:` | ASP.NET |
| `X-AspNetMvc-Version:` | ASP.NET MVC |

### 按 TTFB (Time To First Byte) 识别
| 响应时间特征 | 可能情况 |
|-------------|---------|
| <50ms 返回 404 | 路径不存在（Nginx直接返回） |
| 100-300ms 返回 200 | 页面正常渲染 |
| 1000-3000ms 返回 200 | 可能有数据库查询 |
| >5000ms | 可能有定时任务/计划任务 |

---

## 五、路径推断策略

当已知路径中有 admin/api/backend 等前缀时，自动推断候选路径：

### 从已知路径推断
```
已知: /api/users, /api/orders, /api/auth
推断: /api/admin, /api/config, /api/system, /api/console, /api/manage

已知: /admin/user/list
推断: /admin, /admin/index, /admin/login, /admin/system, /admin/config,
       /admin/file, /admin/upload, /admin/template, /admin/database

已知: /manage/something
推断: /manage, /manage/index, /manage/login, /manage/system
```

### 从技术栈推断
```
PHP + Apache → 探测 /phpmyadmin, /adminer, /info.php, /.env
Java + Tomcat → 探测 /manager, /host-manager, /jmx-console
Node.js → 探测 /graphql, /api/graphql, /.env
Python → 探测 /admin, /flask-admin, /api/docs
Go → 探测 /debug/pprof, /debug/vars, /metrics
```

---

## 六、探测策略

### 优先级策略
```
1. 从已知路径推断的路径 (相关性最高)
2. 按技术栈匹配的路径 (命中率高)
3. Tier 1 通用路径 (覆盖面广)
4. Tier 2-4 特定路径 (补充探测)
```

### 探测方法
```
每个候选路径使用 HEAD 或 OPTIONS 先验活:
  HEAD /admin → HTTP 200 → 存在
  HEAD /admin → HTTP 302 → 重定向（可能是登录页）
  HEAD /admin → HTTP 401/403 → 存在但需要更高权限
  HEAD /admin → HTTP 404 → 不存在

HEAD 确认存在后，使用 GET 获取完整页面内容用于后续分析。
```

### 速率控制
```
默认: 3 个请求/秒
遇到 429 Too Many Requests: 降至 0.2 个请求/秒 (每 5 秒 1 个)
遇到 403 Forbidden (WAF): 暂停当前目标，切换到下一个
连续 5 次超时: 跳过当前目标
```
