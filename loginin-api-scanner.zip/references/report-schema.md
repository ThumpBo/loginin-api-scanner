# 漏洞报告Schema (Vulnerability Report Schema)

## JSON输出格式

每条漏洞发现必须遵循以下JSON Schema：

```json
{
  "findings": [
    {
      "id": "VULN-001",
      "vulnerability": "SQL Injection",
      "category": "injection",
      "severity": "High",
      "confidence": "High",
      "url": "https://example.com/api/search?keyword=test",
      "host": "example.com",
      "method": "GET",
      "path": "/api/search",
      "parameter": "keyword",
      "request_evidence": "GET /api/search?keyword=test' OR '1'='1 HTTP/1.1",
      "response_evidence": "error: You have an error in your SQL syntax; check the manual that corresponds to your MySQL server",
      "description": "在keyword参数中检测到SQL注入。请求中使用了经典的SQL注入测试payload，响应中出现了MySQL语法错误消息，确认SQL语句被错误地拼接执行。",
      "impact": "攻击者可通过SQL注入获取数据库中的敏感数据，包括用户密码、个人信息等。若数据库权限配置不当，可能导致整个数据库被控制。",
      "remediation": "1. 使用参数化查询（PreparedStatement）替代字符串拼接\n2. 对输入参数进行严格的类型校验\n3. 数据库使用最小权限原则\n4. 关闭数据库错误信息回显",
      "cwe": "CWE-89",
      "owasp": "A03:2021 - Injection",
      "cvss": "7.5",
      "references": [
        "https://owasp.org/www-community/attacks/SQL_Injection",
        "https://cheatsheetseries.owasp.org/cheatsheets/SQL_Injection_Prevention_Cheat_Sheet.html"
      ]
    }
  ],
  "summary": {
    "total_findings": 15,
    "by_severity": {
      "Critical": 0,
      "High": 3,
      "Medium": 5,
      "Low": 4,
      "Info": 3
    },
    "by_confidence": {
      "Certain": 2,
      "High": 8,
      "Medium": 4,
      "Low": 1
    },
    "affected_hosts": ["example.com", "api.example.com"],
    "scan_duration": "N/A (offline passive analysis)",
    "total_requests_analyzed": 42
  }
}
```

## 严重程度分类标准

| 严重程度 | 定义 | 示例 |
|---------|------|------|
| **Critical** | 可直接导致服务器被完全控制、大量数据泄露 | RCE、无条件SQL注入、任意文件读取导致的源码泄露 |
| **High** | 可导致敏感数据泄露、权限绕过、业务逻辑严重缺陷 | SQL注入（需认证）、存储型XSS、认证绕过 |
| **Medium** | 需要一定前置条件但可造成安全影响 | 反射型XSS、SSRF（仅HTTP）、IDOR（只读） |
| **Low** | 影响有限或利用复杂 | 安全头缺失、轻微信息泄露、CSRF（低敏感操作） |
| **Info** | 未形成实际漏洞，但存在安全最佳实践问题 | 版本信息泄露、缺少安全头、Cookie未设Secure标志 |

## 置信度分类标准

| 置信度 | 标准 |
|--------|------|
| **Certain** | 响应中明确出现漏洞特征（如数据库错误、命令执行结果、反射的XSS payload） |
| **High** | 参数明显可控且响应提供了强烈的间接证据（如时间延迟、差异化响应） |
| **Medium** | 存在可疑迹象，但缺乏决定性证据（如参数未过滤但响应无异常） |
| **Low** | 理论可能存在但当前流量无法确认，建议进一步测试 |

## Markdown报告模板

```markdown
# 🔍 被动漏洞扫描报告

## 📊 概览

| 项目 | 详情 |
|------|------|
| 扫描时间 | {timestamp} |
| 分析请求总数 | {total_requests} |
| 涉及主机 | {hosts} |
| 发现漏洞总数 | {total_findings} |
| Critical | {critical} |
| High | {high} |
| Medium | {medium} |
| Low | {low} |
| Info | {info} |

---

## 📈 漏洞摘要表

| ID | 类型 | 严重程度 | 置信度 | URL | 参数 |
|----|------|---------|--------|-----|------|
| VULN-001 | SQL注入 | 🔴 High | High | /api/search | keyword |
| VULN-002 | XSS | 🟡 Medium | High | /search | q |

---

## 🔴 高危漏洞详情

### VULN-001: SQL Injection in `/api/search`

**严重程度**: 🔴 High | **置信度**: High
**CWE**: CWE-89 | **OWASP**: A03:2021

**请求证据**:
\`\`\`http
GET /api/search?keyword=test' OR '1'='1 HTTP/1.1
Host: example.com
\`\`\`

**响应证据**:
\`\`\`
You have an error in your SQL syntax; check the manual that corresponds to your MySQL server version for the right syntax to use near ''1'='1'' at line 1
\`\`\`

**漏洞描述**:
...

**业务影响**:
...

**修复建议**:
1. ...
2. ...

**参考链接**:
- OWASP: ...
- CWE: ...

---

## 🛡️ 修复优先级建议

### 立即修复 (24小时内)
- [ ] VULN-001: SQL注入

### 近期修复 (本周内)
- [ ] VULN-002: XSS

### 计划修复 (本月内)
- [ ] VULN-005: 安全头缺失

---

*报告由 AI-Powered Passive Vulnerability Scanner 生成*
*扫描模式: 被动分析（无主动请求）*
```

## 输出原则

1. **证据驱动**: 每条发现必须有实际的请求/响应证据
2. **可操作**: 修复建议必须具体、可落地
3. **优先级明确**: 使用严重程度×可利用性排序
4. **中文输出**: 报告主体使用中文，技术术语保留英文
5. **零噪声**: 仅报告确认存在或高度可疑的漏洞
