# Critical & High Vulnerability Detection Patterns

## 文件用途

本文档是AI分析HTTP流量时使用的**高危/严重漏洞**精准检测模式。
仅覆盖可直接导致服务器沦陷(Critical)或大量数据泄露(High)的漏洞类型。
中低危模式请参考 `vulnerability-patterns.md`。

---

## 1. 命令注入 → RCE (CWE-78) — Critical

### 请求侧检测
```
参数名关键词(任一个命中即启动分析):
cmd, exec, command, ping, host, ip, shell, run, do, action, func, method,
trace, nslookup, dig, whois, bash, sh, zsh, ksh, csh, powershell, pwsh

参数值特征(命中任一即高可疑):
; id                → 命令分隔+系统命令
| cat /etc/passwd   → 管道+敏感文件
&& whoami           → AND操作符+系统命令
|| ls -la           → OR操作符
`uname -a`          → 反引号命令替换(id: 注意这种情况，不一定是注入，取决于目标应用的代码实现)
$(whoami)           → 命令替换
%0a%0d              → CRLF编码
\n\t                → 换行制表

HTTP Header攻击面:
X-Forwarded-For: 127.0.0.1; id
User-Agent: () { :; }; /bin/bash -c 'id'   # Shellshock
Cookie: name=value; $(cat /etc/passwd)
X-Custom-Header: `sleep 5`
```

### 响应侧确认（决定性证据）
```
确认RCE(任一项命中 = Critical):
- /etc/passwd 内容(root:x:0:0:...)
- uid=0(root) gid=0(root)
- Linux内核版本字符串
- Windows目录列表(卷序列号)
- 命令执行输出的标准格式(如ping统计信息混杂系统命令输出)
- 进程列表(ps aux输出)

可能是命令注入(任一项命中 = High):
- 目标参数名暗示命令执行且响应中出现预期外输出
- 错误消息中包含命令执行特征("sh: command not found", "bash: syntax error")
- 响应时间异常(长时间执行特征)
```

### 误报排除
- ❌ IP地址格式的参数值 → 可能是正常的网络工具
- ❌ 仅参数名匹配，响应中无任何命令输出证据 → 降低至Medium
- ❌ 正常的系统输出(如ping google.com的正常输出) → 不是注入

---

## 2. 反序列化 → RCE — Critical

### Java 反序列化
```
Content-Type:
- application/x-java-serialized-object
- application/octet-stream (配合其他特征)

Base64编码特征(请求体或Cookie中):
- rO0ABX           → Java序列化魔法字节 base64
- rO0ABXNy         → 含类的序列化对象
- H4sIAAAAAAA      → GZIP压缩的序列化数据

Hex特征:
- aced 0005        → Java序列化魔法字节
- aced 0005 7372   → 含类描述符

参数名关键词:
data, state, object, serialized, payload, input, obj

Cookie中序列化数据:
- JSESSIONID以外的长base64字符串
- 可解码显示java类名(如java.util.HashMap, java.lang.Runtime)
```

### PHP 反序列化
```
请求体特征:
- O:数字:"类名":数字:{...}     → PHP序列化对象
- a:数字:{...}                 → PHP序列化数组
- s:数字:"字符串值";           → PHP序列化字符串
- __PHP_Incomplete_Class       → 不完整类(反序列化利用常见特征)

Cookie/参数特征:
- 参数值含 a: 或 O: 开头
- Laravel: cookie中包含类似 O:数字: 的模式
```

### .NET 反序列化
```
请求体特征:
- AAEAAAD/////                → .NET BinaryFormatter
- <ResourceDictionary          → XAML反序列化
- <ObjectDataProvider          → 危险的ObjectDataProvider(可直接RCE)
- System.Windows.Data          → WPF数据绑定
```

### 响应侧确认
```
确认证据:
- 反序列化异常: ClassNotFoundException, InvalidClassException
- 异常中包含攻击者可控的类名
- 响应延迟(反序列化gadget链执行)

获取Java类信息(可能反序列化):
- 响应中含 java.util.*, java.lang.*, com.sun.*, org.apache.*
- OGNL表达式注入: ${@java.lang.Runtime@getRuntime().exec('id')}
```

---

## 3. SSTI → RCE — Critical

### 各引擎 Payload 特征

```
Jinja2 (Python/Flask):
  请求: {{7*7}} {{config}} {{self._TemplateReference__context}}
  确认: 响应中 49(数学求值) / Flask配置对象 / <class 'jinja2.runtime.TemplateReference'>
  RCE: {{''.__class__.__mro__[2].__subclasses__()}} → Popen

Twig (PHP/Symfony):
  请求: {{7*7}} {{_self.env.registerUndefinedFilterCallback('exec')}}
  确认: 响应中 49 / Twig环境信息
  RCE: {{['id']|filter('system')}} {{['cat /etc/passwd']|filter('exec')}}

Freemarker (Java):
  请求: ${7*7} <#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}
  确认: 响应中 49 / freemarker对象
  RCE: <#assign ex="freemarker.template.utility.Execute"?new()>${ex("cmd")}

Velocity (Java):
  请求: #set($x=7*7)$x  #set($e="e")$e.getClass().forName("java.lang.Runtime")
  确认: 响应中 49 / Runtime对象

Thymeleaf (Java/Spring):
  请求: __${7*7}__::.x  __${T(java.lang.Runtime).getRuntime().exec('id')}__::.x
  确认: 响应中 49 / 命令输出

Smarty (PHP):
  请求: {7*7} {system('id')} {php}echo shell_exec('id');{/php}
  确认: 响应中 49 / 命令输出

ERB (Ruby/Rails):
  请求: <%= 7*7 %> <%= system('id') %> <%= `id` %>
  确认: 响应中 49 / 命令输出

Jade/Pug (Node.js):
  请求: #{7*7} #{global.process.mainModule.require('child_process').execSync('id')}
  确认: 响应中 49 / 命令输出
```

### 判定矩阵
| 证据 | 置信度 | 严重程度 |
|------|--------|---------|
| 数学运算被求值(7*7→49) | Certain | High (确认SSTI) |
| 对象/配置信息泄露 | Certain | High |
| 命令执行结果出现 | Certain | **Critical** |
| 参数值含模板语法但无回显 | Low | Medium |

---

## 4. SSRF → 云控制台接管 — Critical

### 检测决策树
```
1. 参数是否接受URL?
   ├─ 参数名: url/uri/link/path/redirect/callback/webhook/proxy/image_url/src/target
   └─ 参数值: 完整URL(http/https开头)
       │
2. 响应中是否包含远程资源内容?
   ├─ YES → SSRF确认
   │    │
   │    ├─ 内容来自云元数据(169.254.169.254/metadata.google.internal)?
   │    │   ├─ AWS: ami-id / instance-id / iam/security-credentials → CRITICAL
   │    │   ├─ GCP: computeMetadata / service-accounts → CRITICAL
   │    │   ├─ Azure: 169.254.169.254 / CustomData → CRITICAL
   │    │   └─ OCI: 169.254.169.254/opc → CRITICAL
   │    │
   │    ├─ 内容来自内网地址(10./172./192.168.)?
   │    │   └─ High (内网探测能力)
   │    │
   │    └─ 内容来自外部URL?
   │        └─ Medium (SSRF代理)
   │
   └─ 无法确认? → Low(需主动测试)
```

### 云元数据关键标志
```
AWS IMDSv1 (http://169.254.169.254/latest/meta-data/):
  - ami-id
  - iam/security-credentials/<role-name>
  - AccessKeyId, SecretAccessKey, Token

GCP (http://metadata.google.internal/computeMetadata/v1/):
  - service-accounts/default/token
  - access_token, expires_in

Azure (http://169.254.169.254/metadata/instance):
  - computeMetadata
  - CustomData

DigitalOcean (http://169.254.169.254/metadata/v1.json):
  - droplet_id, user_data
```

### 其他高危SSRF目标
```
- file:///etc/passwd              → 本地文件读取 → Critical
- gopher://内网IP:6379/_INFO      → Redis未授权 → Critical
- dict://内网IP:3306              → MySQL探测 → High
- http://内网IP:9200/_cluster     → ElasticSearch未授权 → High
- http://内网IP:8080/actuator     → Spring Boot Actuator → High
```

---

## 5. SQL注入 → RCE — Critical (特定条件)

### 升级至Critical的条件
```
MySQL:
  - 注入点 + UNION注入可用 → High
  - UNION + INTO OUTFILE可写文件 → Critical
  - 注入点 + 可读mysql.user → High
  - 注入点 + UDF库可加载 → Critical

MSSQL:
  - 注入点 + xp_cmdshell可用 → Critical
  - 注入点 + OPENROWSET → High

PostgreSQL:
  - 注入点 + COPY TO/FROM PROGRAM → Critical
  - 注入点 + lo_import/lo_export → High

Oracle:
  - 注入点 + DBMS_JAVA → Critical
  - 注入点 + UTL_FILE → High
```

### 从流量中识别RCE升级可能性的信号
```
- 数据库用户为root/sa/dba → 高权限 → Critical升级可能
- 错误消息显示MySQL版本 < 5.6 → UDF可能 → Critical升级可能
- 错误消息显示MSSQL + 非Azure → xp_cmdshell可能 → Critical升级可能
- 响应中有文件路径+注入点 → INTO OUTFILE可能 → Critical升级可能
```

---

## 6. 文件上传 → Webshell → Critical

### 检测链
```
1. 识别上传请求
   └─ Content-Type: multipart/form-data
   └─ 文件名参数: filename="xxx"
   
2. 检查是否有文件类型校验绕过迹象
   └─ 响应中无"invalid file type" / "不支持的文件类型" → 可能无校验
   └─ Content-Type可设为image/jpeg+上传.php → 仅MIME校验
   └─ 文件扩展名校验基于客户端 → 可绕过

3. 检查上传路径是否返回
   └─ 响应中含文件路径(/uploads/, /files/, /images/) → 路径已知
   └─ 响应中含文件URL → 可直连webshell

4. 判定
   └─ 无类型校验 + 路径已知 = Critical(可上传webshell)
   └─ 有校验但可能绕过 = High
   └─ 仅发现上传接口，无更多信息 = Medium
```

### Webshell扩展名标志
```
直连可执行的扩展名:
.jsp .jspx .jspf        → Java
.php .phtml .pht .php5  → PHP
.asp .aspx .ashx .asmx .ascx → .NET
.py .pyc                → Python
.pl .pm .cgi            → Perl
.rb                     → Ruby
.war                    → Java(自动部署)
```

---

## 7. 认证绕过 — Critical

### 从流量中检测
```
关键信号(任一项命中即需深度分析):
1. 直接访问 /admin /api/admin /manager /console /backdoor /dev 返回200
   └─ 且请求中无Cookie/Authorization头 → 未授权访问 → Critical

2. 修改资源ID后仍返回200但数据属于不同用户 → IDOR(见下文)

3. 修改HTTP方法绕过:
   └─ POST /api/admin/users 返回403
   └─ GET /api/admin/users 返回200 → HTTP方法绕过 → Critical

4. Header注入绕过:
   └─ 添加 X-Original-URL: /admin → 绕过反向代理
   └─ 添加 X-Forwarded-For: 127.0.0.1 → 绕过IP限制
   └─ 添加 X-Rewrite-URL: /admin → 绕过URL重写

5. JWT伪造:
   └─ alg: none → 无签名验证 → Critical
   └─ 响应中泄露了JWT密钥/私钥 → Critical
   └─ JWT无过期时间(exp) → High

6. Session固定/劫持:
   └─ 登录前后Session ID不变 → Session固定 → High
   └─ Session在URL参数中传递 → 可被Referer泄露 → High
```

---

## 8. IDOR / 越权 — High (批量时可升级为Critical)

### 检测方法
```
步骤1: 找"同一Cookie访问不同资源ID"的请求对
  请求A: Cookie=user_100, GET /api/orders/10001 → 200, user_id:100(自己的)
  请求B: Cookie=user_100, GET /api/orders/10042 → 200, user_id:55(别人的!)
  → 确认IDOR

步骤2: 评估影响
  - 数据含PII(身份证/手机/邮箱/地址) → High
  - 数据含密码/令牌/信用卡 → Critical
  - 仅含非敏感信息 → Medium

步骤3: 评估可枚举性
  - ID为自增数字 → 可批量利用 → Critical升级
  - ID为UUID → 需其他方式泄漏 → High
```

---

## 9. 信息泄露 → 凭证 → Critical

### 凭证泄露优先级
```
P0 (立即判定Critical):
  - 数据库密码(DB_PASS, DB_PASSWORD, connectionString含密码)
  - AWS/GCP/Azure访问密钥(AKIA, ASIA, private_key, service_account)
  - 私有SSH密钥(-----BEGIN RSA PRIVATE KEY-----)
  - API Secret(secret_key, api_secret, signing_key)
  - JWT签名密钥(JWT_SECRET, SIGNING_KEY, private_key)
  - 加密密钥(ENCRYPTION_KEY, AES_KEY, fernet_key)

P1 (判定High):
  - 数据库连接串(含内网地址)
  - 内部服务地址和端口
  - Django/Flask/Rails SECRET_KEY
  - OAuth Client Secret
  
P2 (判定Medium):
  - 版本号(Server头, X-Powered-By, X-Generator)
  - 堆栈跟踪(含文件路径但无凭证)
  - 内网IP(不伴随便携凭证)
```

---

## 利用链评分表

分析完成后，若有以下链成立，必须升级严重程度：

| 链 | 前置条件 | 升级后 | 报告ID格式 |
|----|---------|--------|-----------|
| SSRF + 云元数据 | 同类中多个发现 | Critical | CHAIN-001: SSRF→Cloud Takeover |
| SSRF + 内网服务 | 发现内网redis/mysql | High | CHAIN-002: SSRF→Internal Network |
| SQLi + 高权限数据库用户 | root/sa/dba | Critical | CHAIN-003: SQLi→RCE |
| SQLi + 可写文件 | INTO OUTFILE/UDF | Critical | CHAIN-003: SQLi→RCE |
| Upload + 路径泄露 + 无校验 | 三项都有 | Critical | CHAIN-004: Upload→Webshell |
| Info Leak + 数据库凭据 + 内网地址 | 三项都有 | Critical | CHAIN-005: Credential→Lateral |
| IDOR + 自增ID + PII数据 | 三项都有 | Critical | CHAIN-006: IDOR→Mass Data Leak |
| SSTI + 数学求值确认 + 可访问对象 | 确认SSTI | Critical | CHAIN-007: SSTI→RCE |
| JWT None算法 + admin角色 | 两者都有 | Critical | CHAIN-008: JWT→Auth Bypass |
