#!/usr/bin/env python3
"""
Passive Vulnerability Scanner - HTTP Traffic Parser

Parses HTTP traffic from multiple proxy/tool formats into a standardized JSON structure.
Supported formats:
  - BurpSuite XML export (.xml)
  - HAR (HTTP Archive) (.har)
  - Raw HTTP request/response text (.txt, .http)
  - Yakit JSON export (.json)

Usage:
  python3 parse_http.py <input_file> [-o output.json] [-f format]
  python3 parse_http.py burp_export.xml -o parsed.json
  python3 parse_http.py traffic.har -f har -o parsed.json
"""

import json
import sys
import os
import re
import base64
import argparse
from xml.etree import ElementTree as ET
from urllib.parse import urlparse, parse_qs
from collections import Counter


def detect_format(filepath):
    """Auto-detect the input file format."""
    ext = os.path.splitext(filepath)[1].lower()

    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        first_line = f.readline().strip()
        f.seek(0)
        content_start = f.read(500)

    # Check XML (BurpSuite)
    if ext == '.xml' or first_line.startswith('<?xml'):
        if 'burpVersion' in content_start or '<items>' in content_start:
            return 'burp_xml'
        return 'xml'

    # Check HAR
    if ext == '.har':
        return 'har'
    if first_line.startswith('{'):
        try:
            data = json.loads(open(filepath).read()[:10000])
            if 'log' in data and 'entries' in data['log']:
                return 'har'
        except:
            pass

    # Check Yakit/JSON Burp export
    if ext == '.json':
        try:
            data = json.loads(open(filepath).read()[:5000])
            if isinstance(data, list) and len(data) > 0:
                item = data[0]
                if 'request' in item and 'response' in item:
                    return 'burp_json'
        except:
            pass

    # Default: try raw HTTP text
    return 'raw_http'


def parse_burp_xml(filepath):
    """Parse BurpSuite XML export format."""
    items = []
    tree = ET.parse(filepath)
    root = tree.getroot()

    for item_elem in root.findall('.//item'):
        item = {
            'id': len(items) + 1,
            'url': '',
            'host': '',
            'method': 'GET',
            'path': '/',
            'query_params': {},
            'request_headers': {},
            'request_body': None,
            'status_code': 0,
            'response_headers': {},
            'response_body': ''
        }

        # Parse URL
        url_elem = item_elem.find('url')
        if url_elem is not None and url_elem.text:
            item['url'] = url_elem.text
            parsed = urlparse(url_elem.text)
            item['host'] = parsed.netloc
            item['path'] = parsed.path or '/'
            if parsed.query:
                item['query_params'] = dict(parse_qs(parsed.query))

        # Parse request
        request_elem = item_elem.find('request')
        if request_elem is not None and request_elem.text:
            request_b64 = request_elem.text
            try:
                request_raw = base64.b64decode(request_b64).decode('utf-8', errors='replace')
                req_parsed = parse_raw_http_request(request_raw)
                item['method'] = req_parsed.get('method', 'GET')
                item['request_headers'] = req_parsed.get('headers', {})
                item['request_body'] = req_parsed.get('body')
                # Override URL info if available from the raw request
                if req_parsed.get('path'):
                    item['path'] = req_parsed['path']
                    # Parse query from path if URL didn't have it
                    if '?' in req_parsed['path'] and not item['query_params']:
                        qs = req_parsed['path'].split('?', 1)[1]
                        item['query_params'] = dict(parse_qs(qs))
                if req_parsed.get('host') and not item['host']:
                    item['host'] = req_parsed['host']
            except Exception as e:
                pass

        # Parse response
        response_elem = item_elem.find('response')
        if response_elem is not None and response_elem.text:
            response_b64 = response_elem.text
            try:
                response_raw = base64.b64decode(response_b64).decode('utf-8', errors='replace')
                resp_parsed = parse_raw_http_response(response_raw)
                item['status_code'] = resp_parsed.get('status_code', 0)
                item['response_headers'] = resp_parsed.get('headers', {})
                item['response_body'] = resp_parsed.get('body', '')
            except Exception as e:
                pass

        # Parse host
        host_elem = item_elem.find('host')
        if host_elem is not None and host_elem.text:
            item['host'] = host_elem.text

        # Parse method
        method_elem = item_elem.find('method')
        if method_elem is not None and method_elem.text:
            item['method'] = method_elem.text

        # Parse path
        path_elem = item_elem.find('path')
        if path_elem is not None and path_elem.text:
            item['path'] = path_elem.text

        # Parse status code
        status_elem = item_elem.find('statusCode')
        if status_elem is not None and status_elem.text:
            try:
                item['status_code'] = int(status_elem.text)
            except:
                pass

        items.append(item)

    return build_output(items)


def parse_har(filepath):
    """Parse HAR (HTTP Archive) format."""
    with open(filepath, 'r', encoding='utf-8') as f:
        har = json.load(f)

    items = []
    entries = har.get('log', {}).get('entries', [])

    for entry in entries:
        item = {'id': len(items) + 1}

        # Request
        req = entry.get('request', {})
        item['method'] = req.get('method', 'GET')
        item['url'] = req.get('url', '')
        item['request_headers'] = {}
        for h in req.get('headers', []):
            item['request_headers'][h['name']] = h['value']

        # Parse URL
        parsed = urlparse(item['url'])
        item['host'] = parsed.netloc
        item['path'] = parsed.path or '/'
        item['query_params'] = {}
        if parsed.query:
            item['query_params'] = dict(parse_qs(parsed.query))

        # Extract query params from queryString if available
        if req.get('queryString'):
            item['query_params'] = {}
            for q in req['queryString']:
                item['query_params'][q['name']] = q.get('value', '')

        # Request body
        post_data = req.get('postData', {})
        if post_data:
            item['request_body'] = post_data.get('text', '')
        else:
            item['request_body'] = None

        # Response
        resp = entry.get('response', {})
        item['status_code'] = resp.get('status', 0)
        item['response_headers'] = {}
        for h in resp.get('headers', []):
            item['response_headers'][h['name']] = h['value']

        # Response body
        content = resp.get('content', {})
        item['response_body'] = ''
        if content.get('text'):
            item['response_body'] = content['text']
        elif content.get('encoding') == 'base64' and content.get('text'):
            try:
                item['response_body'] = base64.b64decode(content['text']).decode('utf-8', errors='replace')
            except:
                item['response_body'] = '[Base64 encoded - could not decode]'

        items.append(item)

    return build_output(items)


def parse_raw_http(filepath):
    """Parse raw HTTP request/response text files.
    Supports:
    - Single request
    - Request + response separated by blank line
    - Multiple request/response pairs separated by '###' or '---'
    """
    with open(filepath, 'r', encoding='utf-8', errors='replace') as f:
        content = f.read()

    # Split into blocks on lines starting with ### or ---
    # Normalize separators first
    # Match lines like "### Something" or "--- Something" or just "###" / "---"
    blocks = re.split(r'\n(?=#{3,}[^\n]*\n|\-{3,}[^\n]*\n)', content)

    if len(blocks) == 1:
        # Try alternative split: look for "###" or "---" as line prefix
        blocks = re.split(r'\n#{3,}[^\n]*\n|\n\-{3,}[^\n]*\n', content)

    items = []
    for block in blocks:
        block = block.strip()
        if not block:
            continue

        # Remove leading ### comment line if present
        block = re.sub(r'^#{3,}[^\n]*\n', '', block)

        item = parse_http_block(block)
        if item:
            item['id'] = len(items) + 1
            items.append(item)

    return build_output(items)


def parse_http_block(block):
    """Parse a single HTTP request/response text block."""
    item = {
        'url': '',
        'host': '',
        'method': 'GET',
        'path': '/',
        'query_params': {},
        'request_headers': {},
        'request_body': None,
        'status_code': 0,
        'response_headers': {},
        'response_body': ''
    }

    # Clean the block: strip leading/trailing whitespace
    block = block.strip()

    # Split request and response: find the HTTP/ response status line
    # The request starts with a method (GET/POST/PUT/DELETE/PATCH/HEAD/OPTIONS/CONNECT/TRACE)
    # The response starts with HTTP/
    http_methods = r'^(?:GET|POST|PUT|DELETE|PATCH|HEAD|OPTIONS|CONNECT|TRACE)\s'
    req_start = re.search(http_methods, block, re.MULTILINE)
    resp_start = re.search(r'^HTTP/[\d.]+ \d+', block, re.MULTILINE)

    if req_start and resp_start:
        # Have both request and response
        # The request is from req_start to just before resp_start
        req_text = block[req_start.start():resp_start.start()].strip()
        resp_text = block[resp_start.start():].strip()

        req_parsed = parse_raw_http_request(req_text)
        resp_parsed = parse_raw_http_response(resp_text)

        item['method'] = req_parsed.get('method', 'GET')
        item['path'] = req_parsed.get('path', '/')
        item['host'] = req_parsed.get('host', '')
        item['request_headers'] = req_parsed.get('headers', {})
        item['request_body'] = req_parsed.get('body')
        item['status_code'] = resp_parsed.get('status_code', 0)
        item['response_headers'] = resp_parsed.get('headers', {})
        item['response_body'] = resp_parsed.get('body', '')
    elif resp_start:
        # Only response
        resp_text = block[resp_start.start():].strip()
        resp_parsed = parse_raw_http_response(resp_text)
        item['status_code'] = resp_parsed.get('status_code', 0)
        item['response_headers'] = resp_parsed.get('headers', {})
        item['response_body'] = resp_parsed.get('body', '')
    elif req_start:
        # Only request
        req_text = block[req_start.start():].strip()
        req_parsed = parse_raw_http_request(req_text)
        item['method'] = req_parsed.get('method', 'GET')
        item['path'] = req_parsed.get('path', '/')
        item['host'] = req_parsed.get('host', '')
        item['request_headers'] = req_parsed.get('headers', {})
        item['request_body'] = req_parsed.get('body')
    else:
        # Can't parse - return None to skip this block
        return None

    # Build full URL
    host = item['host'] or item['request_headers'].get('Host', '')
    scheme = 'https' if item.get('status_code') and '443' in str(item.get('request_headers', {}).get(':authority', '')) else 'http'
    if host:
        item['url'] = f"{scheme}://{host}{item['path']}"
        item['host'] = host.split(':')[0]

    # Parse query params from path
    if '?' in item['path']:
        qs = item['path'].split('?', 1)[1]
        item['query_params'] = dict(parse_qs(qs))

    return item


def parse_raw_http_request(raw):
    """Parse a raw HTTP request string."""
    result = {'method': 'GET', 'path': '/', 'host': '', 'headers': {}, 'body': None}

    lines = raw.split('\n')
    # Parse request line
    request_line = lines[0].strip()
    parts = request_line.split(' ')
    if len(parts) >= 2:
        result['method'] = parts[0]
        result['path'] = parts[1]

    # Parse headers
    i = 1
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            break
        if ':' in line:
            key, value = line.split(':', 1)
            result['headers'][key.strip()] = value.strip()
            if key.strip().lower() == 'host':
                result['host'] = value.strip()
        i += 1

    # Parse body
    if i < len(lines):
        body = '\n'.join(lines[i:]).strip()
        if body:
            result['body'] = body

    return result


def parse_raw_http_response(raw):
    """Parse a raw HTTP response string."""
    result = {'status_code': 0, 'headers': {}, 'body': ''}

    lines = raw.split('\n')
    # Parse status line
    status_line = lines[0].strip()
    # Handle HTTP/1.1 200 OK or HTTP/2 200
    status_match = re.match(r'HTTP/[\d.]+ (\d+)', status_line)
    if status_match:
        result['status_code'] = int(status_match.group(1))

    # Parse headers
    i = 1
    while i < len(lines):
        line = lines[i].strip()
        if not line:
            i += 1
            break
        if ':' in line:
            key, value = line.split(':', 1)
            result['headers'][key.strip()] = value.strip()
        i += 1

    # Parse body
    if i < len(lines):
        result['body'] = '\n'.join(lines[i:])

    return result


def build_output(items):
    """Build the standardized output with summary."""
    # Compute summary
    hosts = list(set(item.get('host', '') for item in items if item.get('host')))
    methods = Counter(item.get('method', 'GET') for item in items)
    content_types = list(set(
        item.get('response_headers', {}).get('Content-Type', 'unknown').split(';')[0]
        for item in items
    ))

    output = {
        'summary': {
            'total_requests': len(items),
            'unique_hosts': hosts,
            'methods': dict(methods),
            'content_types': content_types
        },
        'items': items
    }

    return output


def main():
    parser = argparse.ArgumentParser(
        description='Parse HTTP traffic files into standardized JSON for vulnerability analysis',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s burp_export.xml -o parsed.json
  %(prog)s traffic.har -o parsed.json
  %(prog)s raw_http.txt -f raw_http -o parsed.json
  %(prog)s yakit_export.json -o parsed.json
        """
    )
    parser.add_argument('input', help='Input HTTP traffic file')
    parser.add_argument('-o', '--output', default='/tmp/parsed_traffic.json',
                        help='Output JSON file path (default: /tmp/parsed_traffic.json)')
    parser.add_argument('-f', '--format', choices=['burp_xml', 'har', 'raw_http', 'burp_json'],
                        help='Force specific format (auto-detect if not specified)')

    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"Error: Input file not found: {args.input}")
        sys.exit(1)

    # Detect format
    fmt = args.format or detect_format(args.input)
    print(f"[+] Detected format: {fmt}")

    # Parse
    parsers = {
        'burp_xml': parse_burp_xml,
        'har': parse_har,
        'raw_http': parse_raw_http,
        'burp_json': parse_burp_json,
    }

    if fmt not in parsers:
        print(f"Error: Unsupported format: {fmt}")
        print(f"Supported formats: {', '.join(parsers.keys())}")
        sys.exit(1)

    print(f"[+] Parsing {args.input}...")
    result = parsers[fmt](args.input)

    # Write output
    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(result, f, ensure_ascii=False, indent=2)

    # Print summary
    s = result['summary']
    print(f"\n[+] Successfully parsed {s['total_requests']} requests")
    print(f"[+] Hosts: {', '.join(s['unique_hosts'][:10])}{'...' if len(s['unique_hosts']) > 10 else ''}")
    print(f"[+] Methods: {dict(s['methods'])}")
    print(f"[+] Content-Types: {s['content_types']}")
    print(f"[+] Output written to: {args.output}")


def parse_burp_json(filepath):
    """Parse BurpSuite JSON export or Yakit JSON format."""
    with open(filepath, 'r', encoding='utf-8') as f:
        data = json.load(f)

    items = []

    if isinstance(data, list):
        entries = data
    elif isinstance(data, dict):
        if 'items' in data:
            entries = data['items']
        elif 'entries' in data:
            entries = data['entries']
        elif 'flows' in data:
            entries = data['flows']
        else:
            entries = [data]
    else:
        entries = []

    for entry in entries:
        item = {'id': len(items) + 1, 'url': '', 'host': '', 'method': 'GET', 'path': '/',
                'query_params': {}, 'request_headers': {}, 'request_body': None,
                'status_code': 0, 'response_headers': {}, 'response_body': ''}

        # Handle different JSON structures
        # BurpSuite JSON format
        if 'request' in entry:
            req = entry['request']
            if isinstance(req, str):
                # base64 encoded
                try:
                    req_raw = base64.b64decode(req).decode('utf-8', errors='replace')
                    req_parsed = parse_raw_http_request(req_raw)
                    item['method'] = req_parsed.get('method', 'GET')
                    item['path'] = req_parsed.get('path', '/')
                    item['host'] = req_parsed.get('host', '')
                    item['request_headers'] = req_parsed.get('headers', {})
                    item['request_body'] = req_parsed.get('body')
                except:
                    pass
            elif isinstance(req, dict):
                item['method'] = req.get('method', 'GET')
                item['path'] = req.get('path', '/')
                item['request_headers'] = {h['name']: h['value'] for h in req.get('headers', [])}
                item['request_body'] = req.get('body')
                item['url'] = req.get('url', '')

        if 'response' in entry:
            resp = entry['response']
            if isinstance(resp, str):
                try:
                    resp_raw = base64.b64decode(resp).decode('utf-8', errors='replace')
                    resp_parsed = parse_raw_http_response(resp_raw)
                    item['status_code'] = resp_parsed.get('status_code', 0)
                    item['response_headers'] = resp_parsed.get('headers', {})
                    item['response_body'] = resp_parsed.get('body', '')
                except:
                    pass
            elif isinstance(resp, dict):
                item['status_code'] = resp.get('status_code', resp.get('status', 0))
                item['response_headers'] = {h['name']: h['value'] for h in resp.get('headers', [])}
                item['response_body'] = resp.get('body', '')

        # Yakit format
        if 'url' in entry:
            item['url'] = entry['url']
        if 'host' in entry:
            item['host'] = entry['host']
        if 'method' in entry:
            item['method'] = entry['method']
        if 'path' in entry:
            item['path'] = entry['path']

        # Build URL from components
        if not item['url'] and item['host']:
            scheme = 'https' if item.get('status_code') in [443] or '8443' in item.get('host', '') else 'http'
            item['url'] = f"{scheme}://{item['host']}{item['path']}"

        # Parse query params from path if URL not available
        if not item['query_params'] and '?' in item['path']:
            qs = item['path'].split('?', 1)[1]
            item['query_params'] = dict(parse_qs(qs))

        items.append(item)

    return build_output(items)


if __name__ == '__main__':
    main()
