#!/usr/bin/env python3
"""
Passive Vulnerability Scanner — Selenium Deep Explorer (Optional Module)

Handles JavaScript-rendered admin panels that requests-based crawler cannot analyze.
Uses Selenium WebDriver to:
  - Inject stolen cookies for authenticated browsing
  - Crawl Single Page Applications (React/Vue/Angular)
  - Click interactive elements and capture AJAX/XHR traffic
  - Screenshot admin panels and dangerous features
  - Detect rich text editors (WYSIWYG) for template injection testing
  - Extract JS framework routes and state

If Selenium is not installed, exits gracefully with install instructions.

Usage:
  python3 selenium_explorer.py session_state.json -o selenium_traffic.json
  python3 selenium_explorer.py session_state.json --target-url https://example.com/admin
"""

import json
import sys
import os
import re
import time
import argparse
import hashlib
from urllib.parse import urlparse, urljoin
from datetime import datetime

# Selenium is optional
SELENIUM_AVAILABLE = False
try:
    from selenium import webdriver
    from selenium.webdriver.common.by import By
    from selenium.webdriver.support.ui import WebDriverWait
    from selenium.webdriver.support import expected_conditions as EC
    from selenium.webdriver.chrome.options import Options
    from selenium.webdriver.chrome.service import Service
    from selenium.common.exceptions import (
        TimeoutException, NoSuchElementException, WebDriverException,
        StaleElementReferenceException, InvalidArgumentException
    )
    SELENIUM_AVAILABLE = True
except ImportError:
    pass

# playwright is another optional backend
PLAYWRIGHT_AVAILABLE = False
try:
    from playwright.sync_api import sync_playwright
    PLAYWRIGHT_AVAILABLE = True
except ImportError:
    pass


DANGEROUS_INTERACTIONS = {
    'file_upload': {
        'selectors': [
            'input[type="file"]',
            'input[name*="file"]', 'input[name*="upload"]',
            'input[name*="image"]', 'input[name*="avatar"]',
            'input[name*="attachment"]',
        ],
        'risk': 'HIGH'
    },
    'command_execution': {
        'selectors': [
            'textarea[name*="cmd"]', 'textarea[name*="command"]',
            'input[name*="cmd"]', 'input[name*="command"]',
            'input[name*="ping"]', 'input[name*="host"]',
            'input[name*="ip"]', 'input[name*="exec"]',
        ],
        'risk': 'CRITICAL'
    },
    'sql_execution': {
        'selectors': [
            'textarea[name*="sql"]', 'textarea[name*="query"]',
            'textarea[name*="hql"]', 'textarea[name*="jpql"]',
        ],
        'risk': 'HIGH'
    },
    'template_editor': {
        'selectors': [
            '.CodeMirror', '.ace_editor', '.monaco-editor',
            'textarea[name*="template"]', 'textarea[name*="html"]',
            'textarea[name*="content"]', 'div[contenteditable="true"]',
        ],
        'risk': 'CRITICAL'
    },
    'config_editor': {
        'selectors': [
            'textarea[name*="config"]', 'input[name*="env"]',
            'input[name*="property"]', 'input[name*="setting"]',
        ],
        'risk': 'MEDIUM'
    },
}


def check_selenium_available():
    """Check if any browser automation backend is available."""
    if PLAYWRIGHT_AVAILABLE:
        return 'playwright'
    if SELENIUM_AVAILABLE:
        # Check if chromedriver/chromium is available
        try:
            options = Options()
            options.add_argument('--headless')
            options.add_argument('--no-sandbox')
            options.add_argument('--disable-dev-shm-usage')
            driver = webdriver.Chrome(options=options)
            driver.quit()
            return 'selenium'
        except WebDriverException:
            pass
    return None


def print_install_instructions():
    """Print dependency install instructions."""
    print("""
╔══════════════════════════════════════════════════════════╗
║  Selenium/Playwright is not installed or not configured  ║
║                                                          ║
║  Install one of the following for JS rendering support:  ║
║                                                          ║
║  Option A — Playwright (recommended, auto-downloads):    ║
║    pip install playwright                                ║
║    playwright install chromium                           ║
║                                                          ║
║  Option B — Selenium + ChromeDriver:                     ║
║    pip install selenium                                  ║
║    apt install chromium-chromedriver                     ║
║                                                          ║
║  The skill will continue with requests-based crawling.   ║
║  Run this script again after installing the dependency.  ║
╚══════════════════════════════════════════════════════════╝
    """)


def setup_driver(headless=True):
    """Configure and return a Selenium WebDriver instance."""
    options = Options()
    if headless:
        options.add_argument('--headless=new')
    options.add_argument('--no-sandbox')
    options.add_argument('--disable-dev-shm-usage')
    options.add_argument('--disable-gpu')
    options.add_argument('--window-size=1920,1080')
    options.add_argument('--disable-blink-features=AutomationControlled')
    options.add_argument('--user-agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                         'AppleWebKit/537.36 (KHTML, like Gecko) '
                         'Chrome/125.0.0.0 Safari/537.36')
    options.add_experimental_option('excludeSwitches', ['enable-automation'])
    options.add_experimental_option('useAutomationExtension', False)

    driver = webdriver.Chrome(options=options)
    driver.set_page_load_timeout(30)
    driver.set_script_timeout(30)
    return driver


def inject_cookies(driver, session, target_url):
    """Inject stolen cookies into the browser session."""
    driver.get(target_url)
    time.sleep(1)  # Let the page load enough to set domain

    cookies = session.get('cookies', {})
    for name, value in cookies.items():
        try:
            driver.add_cookie({
                'name': name,
                'value': value,
                'domain': urlparse(target_url).netloc,
                'path': '/',
                'httpOnly': False,
                'secure': urlparse(target_url).scheme == 'https',
            })
        except InvalidArgumentException:
            pass  # Cookie may not be valid for this domain


def crawl_spa(driver, start_url, max_pages=15):
    """Crawl a Single Page Application by clicking interactive elements."""
    visited = set()
    to_visit = [start_url]
    captured_pages = []
    screenshots = []

    while to_visit and len(visited) < max_pages:
        url = to_visit.pop(0)
        if url in visited:
            continue

        try:
            driver.get(url)
            WebDriverWait(driver, 10).until(
                lambda d: d.execute_script('return document.readyState') == 'complete'
            )
            time.sleep(1)  # Additional wait for JS rendering
        except TimeoutException:
            pass
        except WebDriverException as e:
            print(f"    [!] Failed to load {url}: {str(e)[:100]}")
            continue

        visited.add(url)

        page_data = {
            'url': url,
            'title': driver.title,
            'html_snapshot': (driver.page_source or '')[:50000],
            'page_text': driver.find_element(By.TAG_NAME, 'body').text[:10000],
        }
        captured_pages.append(page_data)

        # Screenshot
        try:
            screenshot_path = f"/tmp/selenium_{urlparse(url).netloc}_{len(screenshots)+1:03d}.png"
            driver.save_screenshot(screenshot_path)
            screenshots.append({'url': url, 'screenshot': screenshot_path})
        except Exception:
            pass

        # Discover new links and interactive elements
        try:
            links = driver.find_elements(By.TAG_NAME, 'a')
            for link in links:
                try:
                    href = link.get_attribute('href')
                    if href and href.startswith(start_url.split('/')[0]) and href not in visited:
                        to_visit.append(href)
                except StaleElementReferenceException:
                    continue
        except Exception:
            pass

    return captured_pages, screenshots


def detect_dangerous_features(driver, url):
    """Detect dangerous features on the current page using selectors."""
    findings = []

    for feature_type, config in DANGEROUS_INTERACTIONS.items():
        for selector in config['selectors']:
            try:
                elements = driver.find_elements(By.CSS_SELECTOR, selector)
                if elements:
                    findings.append({
                        'url': url,
                        'type': feature_type,
                        'risk': config['risk'],
                        'selector': selector,
                        'element_count': len(elements),
                        'element_tag': elements[0].tag_name if elements else 'unknown',
                    })
                    break  # One match is enough per feature type
            except Exception:
                continue

    return findings


def detect_js_frameworks(driver):
    """Detect JavaScript frameworks via global variables."""
    frameworks = []

    frameworks_checks = {
        'React': 'return typeof React !== "undefined"',
        'Vue': 'return typeof Vue !== "undefined" || document.querySelector("[data-v-]") !== null',
        'Angular': 'return typeof ng !== "undefined" || document.querySelector("[ng-app]") !== null || document.querySelector("[ng-version]") !== null',
        'jQuery': 'return typeof jQuery !== "undefined"',
        'Bootstrap': 'return typeof bootstrap !== "undefined" || document.querySelector("[data-bs-]") !== null',
    }

    for name, script in frameworks_checks.items():
        try:
            result = driver.execute_script(script)
            if result:
                frameworks.append(name)
        except Exception:
            pass

    return frameworks


def extract_network_traffic_playwright(target_url, session, max_pages=10):
    """Use Playwright for full network traffic capture."""
    if not PLAYWRIGHT_AVAILABLE:
        return [], []

    captured_requests = []
    screenshots = []

    with sync_playwright() as p:
        browser = p.chromium.launch(headless=True)
        context = browser.new_context(
            viewport={'width': 1920, 'height': 1080},
            user_agent='Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
                       'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/125.0.0.0 Safari/537.36',
        )

        # Inject cookies
        cookies = session.get('cookies', {})
        cookie_list = []
        for name, value in cookies.items():
            cookie_list.append({
                'name': name,
                'value': value,
                'domain': urlparse(target_url).netloc,
                'path': '/',
            })
        if cookie_list:
            context.add_cookies(cookie_list)

        page = context.new_page()

        # Capture network traffic
        def handle_request(request):
            captured_requests.append({
                'url': request.url,
                'method': request.method,
                'headers': dict(request.headers),
                'post_data': request.post_data,
            })

        def handle_response(response):
            try:
                body = response.body()[:50000].decode('utf-8', errors='replace')
            except Exception:
                body = '[binary or unavailable]'
            captured_requests.append({
                'url': response.url,
                'status': response.status,
                'headers': dict(response.headers),
                'body': body,
                'type': 'response',
            })

        page.on('request', handle_request)
        page.on('response', handle_response)

        # Navigate
        try:
            page.goto(target_url, timeout=30000, wait_until='networkidle')
            page.wait_for_timeout(2000)
        except Exception:
            pass

        # Screenshot
        try:
            ss_path = f"/tmp/playwright_{urlparse(target_url).netloc}_001.png"
            page.screenshot(path=ss_path, full_page=True)
            screenshots.append({'url': target_url, 'screenshot': ss_path})
        except Exception:
            pass

        # Crawl linked pages
        visited = {target_url}
        try:
            links = page.evaluate('''() => {
                return Array.from(document.querySelectorAll('a[href]'))
                    .map(a => a.href)
                    .filter(h => h.startsWith(location.origin));
            }''')
            for link in links[:max_pages - 1]:
                if link not in visited:
                    visited.add(link)
                    try:
                        page.goto(link, timeout=15000, wait_until='networkidle')
                        page.wait_for_timeout(1000)
                        ss_path = f"/tmp/playwright_{urlparse(link).netloc}_{len(screenshots)+1:03d}.png"
                        page.screenshot(path=ss_path, full_page=True)
                        screenshots.append({'url': link, 'screenshot': ss_path})
                    except Exception:
                        pass
        except Exception:
            pass

        browser.close()

    return captured_requests, screenshots


def main():
    parser = argparse.ArgumentParser(
        description='Selenium Deep Explorer — JS-rendered admin panel discovery',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s session_state.json -o selenium_traffic.json
  %(prog)s session_state.json --target-url https://example.com/admin -o selenium_traffic.json
        """
    )
    parser.add_argument('input', help='Session state JSON file (from extract_session.py)')
    parser.add_argument('-o', '--output', default='/tmp/selenium_traffic.json',
                        help='Output traffic JSON (default: /tmp/selenium_traffic.json)')
    parser.add_argument('--target-url', help='Specific admin URL to explore')
    parser.add_argument('--max-pages', type=int, default=10,
                        help='Maximum pages to crawl (default: 10)')
    parser.add_argument('--no-headless', action='store_true',
                        help='Disable headless mode (for debugging)')

    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"Error: Input file not found: {args.input}")
        sys.exit(1)

    # Load session state
    with open(args.input, 'r', encoding='utf-8') as f:
        state = json.load(f)

    # Check backend availability
    backend = check_selenium_available()

    if backend is None:
        print_install_instructions()

        # Write a placeholder indicating Selenium was not available
        result = {
            'selenium_available': False,
            'install_instructions': 'pip install playwright && playwright install chromium',
            'message': 'Selenium/Playwright not installed. Falling back to requests-based explorer.',
            'traffic': [],
            'screenshots': [],
            'dangerous_features': [],
        }
        with open(args.output, 'w', encoding='utf-8') as f:
            json.dump(result, f, ensure_ascii=False, indent=2)
        print(f"[+] Placeholder written to: {args.output}")
        sys.exit(0)

    print(f"[+] Using backend: {backend}")

    # Determine target URLs
    targets = []
    if args.target_url:
        targets.append(args.target_url)
    else:
        # Use admin panels already discovered by active_explorer, or candidates
        for target in state.get('targets', []):
            base = target.get('base_url', '')
            if base:
                targets.append(base)
        # If none, try admin candidates
        if not targets:
            for cand in state.get('admin_candidates', [])[:5]:
                targets.append(cand['url'])

    if not targets:
        print("[!] No targets to explore. Run active_explorer.py first.")
        sys.exit(1)

    all_traffic = []
    all_screenshots = []
    all_dangerous = []
    all_frameworks = set()

    # Use Playwright if available (better network capture)
    if backend == 'playwright':
        for target_url in targets[:3]:  # Cap at 3 targets
            print(f"\n[*] Exploring {target_url} with Playwright...")
            host = urlparse(target_url).netloc
            session = next((s for s in state.get('sessions', []) if s.get('host') == host),
                           state['sessions'][0] if state.get('sessions') else {})

            traffic, screenshots = extract_network_traffic_playwright(
                target_url, session, args.max_pages
            )
            all_traffic.extend(traffic)
            all_screenshots.extend(screenshots)
            print(f"    Captured {len(traffic)} requests, {len(screenshots)} screenshots")

    elif backend == 'selenium':
        driver = setup_driver(headless=not args.no_headless)
        try:
            for target_url in targets[:3]:
                print(f"\n[*] Exploring {target_url} with Selenium...")
                host = urlparse(target_url).netloc
                session = next((s for s in state.get('sessions', []) if s.get('host') == host),
                               state['sessions'][0] if state.get('sessions') else {})

                # Inject cookies and start crawling
                inject_cookies(driver, session, target_url)
                time.sleep(2)

                # Detect frameworks
                frameworks = detect_js_frameworks(driver)
                all_frameworks.update(frameworks)
                if frameworks:
                    print(f"    Detected frameworks: {', '.join(frameworks)}")

                # Detect dangerous features on landing page
                dangerous = detect_dangerous_features(driver, target_url)
                all_dangerous.extend(dangerous)
                for d in dangerous:
                    icon = '🔴' if d['risk'] == 'CRITICAL' else '🟠' if d['risk'] == 'HIGH' else '🟡'
                    print(f"    {icon} [{d['risk']}] {d['type']}: "
                          f"{d['element_count']} element(s) via {d['selector']}")

                # Crawl SPA pages
                pages, screenshots = crawl_spa(driver, target_url, args.max_pages)
                all_screenshots.extend(screenshots)

                for page in pages:
                    all_traffic.append({
                        'url': page['url'],
                        'title': page['title'],
                        'type': 'page_capture',
                        'body': page['page_text'],
                    })
                print(f"    Crawled {len(pages)} pages, {len(screenshots)} screenshots")
        finally:
            driver.quit()

    # Save results
    output = {
        'selenium_available': True,
        'backend': backend,
        'targets_explored': targets[:3],
        'traffic': all_traffic,
        'screenshots': all_screenshots,
        'dangerous_features': all_dangerous,
        'frameworks_detected': sorted(all_frameworks),
        'statistics': {
            'total_requests': len(all_traffic),
            'total_screenshots': len(all_screenshots),
            'dangerous_features_found': len(all_dangerous),
        }
    }

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    # Summary
    stats = output['statistics']
    print(f"\n{'='*60}")
    print(f"  Selenium Explorer — Summary")
    print(f"{'='*60}")
    print(f"  Requests captured:     {stats['total_requests']}")
    print(f"  Screenshots taken:     {stats['total_screenshots']}")
    print(f"  Dangerous features:    {stats['dangerous_features_found']}")
    print(f"  Frameworks detected:   {', '.join(sorted(all_frameworks)) or 'none'}")
    print(f"\n[+] Output saved to: {args.output}")
    if all_screenshots:
        print(f"[+] Screenshots saved to: /tmp/selenium_*.png")


if __name__ == '__main__':
    main()
