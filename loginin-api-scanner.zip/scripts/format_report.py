#!/usr/bin/env python3
"""
Passive Vulnerability Scanner — Report Formatter v3.0

Converts AI-generated vulnerability findings (JSON) into a formatted Markdown report.
Supports both passive scan findings and active deep dive discoveries.

Usage:
  python3 format_report.py findings.json -o report.md
  python3 format_report.py findings.json -o report.md --active-discoveries discovered_surface.json
  python3 format_report.py findings.json -o report.md --json-output report.json
"""

import json
import sys
import os
import argparse
from datetime import datetime
from collections import Counter


SEVERITY_ICONS = {
    'Critical': '🔴',
    'High': '🔴',
    'Medium': '🟡',
    'Low': '🟢',
    'Info': '🔵'
}

SEVERITY_ORDER = {'Critical': 0, 'High': 1, 'Medium': 2, 'Low': 3, 'Info': 4}


def merge_active_findings(passive_findings, active_discoveries):
    """Merge active exploration findings into the passive findings list."""
    if not active_discoveries:
        return passive_findings

    merged = list(passive_findings) if passive_findings else []
    next_id = len(merged) + 1

    dangerous = active_discoveries.get('dangerous_features', [])

    for feat in dangerous:
        severity = 'Critical' if feat.get('risk') == 'CRITICAL' else \
                   'High' if feat.get('risk') == 'HIGH' else \
                   'Medium' if feat.get('risk') == 'MEDIUM' else 'Info'

        finding = {
            'id': f'ACTIVE-{next_id:03d}',
            'vulnerability': f"Active Discovery: {feat.get('category', 'Unknown Feature')}",
            'category': feat.get('category', 'unknown'),
            'severity': severity,
            'confidence': 'High',
            'url': feat.get('url', ''),
            'method': 'GET',
            'parameter': feat.get('matched_patterns', [None])[0] if feat.get('matched_patterns') else '',
            'description': f"Active exploration discovered a {feat.get('category', 'feature')} "
                           f"on {feat.get('url', '')}. Risk: {feat.get('risk', 'UNKNOWN')}. "
                           f"Matched patterns: {', '.join(feat.get('matched_patterns', []))}. "
                           f"Page title: {feat.get('title', 'N/A')}.",
            'impact': f"This feature could potentially be exploited for {feat.get('category', 'unknown')} attacks.",
            'remediation': 'Verify if this feature requires authentication. Apply least privilege access control. '
                           'Add input validation and output encoding.',
            'source': 'active_deep_dive',
        }
        merged.append(finding)
        next_id += 1

    return merged


def format_active_discovery_section(active_discoveries):
    """Generate the Active Discovery section of the report."""
    if not active_discoveries:
        return ''

    lines = []
    lines.append("## 🔍 主动深度探索结果")
    lines.append("")

    # Admin panels found
    admin_panels = active_discoveries.get('admin_panels', [])
    if admin_panels:
        lines.append("### 发现的管理后台")
        lines.append("")
        lines.append("| URL | 状态码 | 页面标题 | 含登录表单 |")
        lines.append("|-----|--------|---------|-----------|")
        for panel in admin_panels:
            login = '✅' if panel.get('has_login_form') else '❌'
            title = (panel.get('title', '') or '')[:50]
            lines.append(f"| `{panel.get('url', '')}` | {panel.get('status_code', '')} | "
                         f"{title} | {login} |")
        lines.append("")

    # Dangerous features
    dangerous = active_discoveries.get('dangerous_features', [])
    if dangerous:
        lines.append("### 发现的危险功能点")
        lines.append("")
        lines.append("| 类型 | 风险 | URL | 匹配模式 |")
        lines.append("|------|------|-----|---------|")
        for feat in dangerous:
            icon = '🔴' if feat.get('risk') == 'CRITICAL' else \
                   '🟠' if feat.get('risk') == 'HIGH' else '🟡'
            matched = ', '.join(feat.get('matched_patterns', [])[:3])
            lines.append(f"| {feat.get('category', '')} | {icon} {feat.get('risk', '')} | "
                         f"`{feat.get('url', '')[:80]}` | {matched} |")
        lines.append("")

    # New endpoints
    new_endpoints = active_discoveries.get('new_endpoints', [])
    if new_endpoints:
        lines.append("### 新发现的端点")
        lines.append("")
        lines.append(f"共发现 {len(new_endpoints)} 个新端点:")
        lines.append("")
        for ep in new_endpoints[:30]:
            title = (ep.get('title', '') or '')[:60]
            lines.append(f"- `{ep.get('url', '')}` — {title} (来源: {ep.get('source', 'unknown')})")
        if len(new_endpoints) > 30:
            lines.append(f"- ... 及其他 {len(new_endpoints) - 30} 个端点")
        lines.append("")

    # WAF / CAPTCHA / Rate Limit
    waf = active_discoveries.get('waf_info', {})
    captcha = active_discoveries.get('captcha_info', {})
    rate = active_discoveries.get('rate_limit_info', {})

    if waf.get('detected') or captcha.get('detected') or rate.get('hit'):
        lines.append("### 防护措施检测")
        lines.append("")
        lines.append("| 防护类型 | 状态 | 详情 |")
        lines.append("|---------|------|------|")
        lines.append(f"| WAF | {'⚠️ 已检测' if waf.get('detected') else '❌ 未检测'} | "
                     f"{waf.get('type', '').title() if waf.get('type') else '-'} |")
        lines.append(f"| CAPTCHA | {'⚠️ 已检测' if captcha.get('detected') else '❌ 未检测'} | "
                     f"{captcha.get('evidence', '-')[:80]} |")
        lines.append(f"| 速率限制 | {'⚠️ 触发' if rate.get('hit') else '✅ 未触发'} | "
                     f"{'Retry-After: ' + str(rate.get('retry_after')) + 's' if rate.get('hit') else '-'} |")
        lines.append("")

    # Errors
    errors = active_discoveries.get('errors', [])
    if errors:
        lines.append("### 探测中的错误")
        lines.append("")
        for err in errors[:20]:
            lines.append(f"- {err}")
        lines.append("")

    return '\n'.join(lines)


def format_finding_markdown(finding, index):
    """Format a single finding as Markdown."""
    severity = finding.get('severity', 'Info')
    icon = SEVERITY_ICONS.get(severity, '⚪')

    lines = []
    prefix = '🔍 ' if finding.get('source') == 'active_deep_dive' else ''
    lines.append(f"### {finding.get('id', f'VULN-{index+1:03d}')}: {prefix}{finding.get('vulnerability', 'Unknown')}")
    lines.append("")

    source_tag = ' **(主动发现)**' if finding.get('source') == 'active_deep_dive' else ''
    lines.append(f"**严重程度**: {icon} {severity}{source_tag} | **置信度**: {finding.get('confidence', 'N/A')}")
    if finding.get('cwe'):
        lines.append(f"**CWE**: {finding.get('cwe', '')} | **OWASP**: {finding.get('owasp', '')}")
    lines.append("")
    lines.append(f"- **URL**: `{finding.get('url', 'N/A')}`")
    lines.append(f"- **方法**: `{finding.get('method', 'GET')}`")
    if finding.get('parameter'):
        lines.append(f"- **参数**: `{finding.get('parameter', 'N/A')}`")

    if finding.get('request_evidence'):
        lines.append("")
        lines.append("**请求证据**:")
        lines.append("```http")
        lines.append(finding['request_evidence'][:2000])
        lines.append("```")

    if finding.get('response_evidence'):
        lines.append("")
        lines.append("**响应证据**:")
        lines.append("```")
        lines.append(finding['response_evidence'][:2000])
        lines.append("```")

    if finding.get('description'):
        lines.append("")
        lines.append("**漏洞描述**:")
        lines.append(finding['description'])

    if finding.get('impact'):
        lines.append("")
        lines.append("**业务影响**:")
        lines.append(finding['impact'])

    if finding.get('remediation'):
        lines.append("")
        lines.append("**修复建议**:")
        lines.append(finding['remediation'])

    if finding.get('references'):
        lines.append("")
        lines.append("**参考链接**:")
        for ref in finding['references']:
            lines.append(f"- {ref}")

    lines.append("")
    lines.append("---")
    lines.append("")

    return '\n'.join(lines)


def generate_markdown_report(findings_data, output_path, active_discoveries=None):
    """Generate a full Markdown report from findings, including active discoveries."""
    findings = findings_data.get('findings', [])
    summary = findings_data.get('summary', {})

    if not summary:
        severity_counts = Counter(f.get('severity', 'Info') for f in findings)
        hosts = list(set(
            f.get('url', '').split('/')[2] if '//' in f.get('url', '') else f.get('host', '')
            for f in findings if f.get('url') or f.get('host')
        ))
        summary = {
            'total_findings': len(findings),
            'by_severity': dict(severity_counts),
            'affected_hosts': hosts
        }

    lines = []
    lines.append("# 🔍 被动漏洞扫描报告")
    lines.append("")
    lines.append(f"> 生成时间: {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}")
    lines.append(f"> 分析模式: AI驱动被动分析 + 主动深度探索")

    if active_discoveries:
        admin_count = len(active_discoveries.get('admin_panels', []))
        feat_count = len(active_discoveries.get('dangerous_features', []))
        lines.append(f"> 主动探索: 发现 {admin_count} 个管理后台, {feat_count} 个危险功能点")
    lines.append("")

    lines.append("## 📊 概览")
    lines.append("")
    lines.append("| 项目 | 详情 |")
    lines.append("|------|------|")
    lines.append(f"| 发现漏洞总数 | **{summary.get('total_findings', 0)}** |")

    by_sev = summary.get('by_severity', {})
    for sev in ['Critical', 'High', 'Medium', 'Low', 'Info']:
        count = by_sev.get(sev, 0)
        if count > 0:
            icon = SEVERITY_ICONS.get(sev, '')
            lines.append(f"| {icon} {sev} | {count} |")

    hosts = summary.get('affected_hosts', [])
    if hosts:
        lines.append(f"| 受影响主机 | {', '.join(hosts[:5])}{'...' if len(hosts) > 5 else ''} |")
    lines.append("")

    sorted_findings = sorted(findings, key=lambda f: SEVERITY_ORDER.get(f.get('severity', 'Info'), 99))

    lines.append("## 📈 漏洞摘要表")
    lines.append("")
    lines.append("| ID | 类型 | 严重程度 | 置信度 | URL | 参数 | 来源 |")
    lines.append("|----|------|---------|--------|-----|------|------|")
    for f in sorted_findings:
        sev_icon = SEVERITY_ICONS.get(f.get('severity', 'Info'), '')
        url_short = f.get('url', '')[:60] + ('...' if len(f.get('url', '')) > 60 else '')
        source = '🔍主动' if f.get('source') == 'active_deep_dive' else '被动'
        lines.append(
            f"| {f.get('id', '-')} | {f.get('vulnerability', '-')} | "
            f"{sev_icon} {f.get('severity', '-')} | {f.get('confidence', '-')} | "
            f"`{url_short}` | {f.get('parameter', '-')} | {source} |"
        )
    lines.append("")

    for sev in ['Critical', 'High', 'Medium', 'Low', 'Info']:
        sev_findings = [f for f in sorted_findings if f.get('severity') == sev]
        if not sev_findings:
            continue

        icon = SEVERITY_ICONS.get(sev, '')
        lines.append(f"## {icon} {sev} 风险详情")
        lines.append("")

        for i, finding in enumerate(sev_findings):
            lines.append(format_finding_markdown(finding, i))

    # Active discovery section
    if active_discoveries:
        active_section = format_active_discovery_section(active_discoveries)
        if active_section:
            lines.append(active_section)

    lines.append("## 🛡️ 修复优先级检查清单")
    lines.append("")

    urgency_groups = {
        '立即修复 (24-48小时)': [f for f in sorted_findings if f.get('severity') in ('Critical', 'High')],
        '近期修复 (本周内)': [f for f in sorted_findings if f.get('severity') == 'Medium'],
        '计划修复 (本月内)': [f for f in sorted_findings if f.get('severity') in ('Low', 'Info')],
    }

    for label, group in urgency_groups.items():
        if group:
            lines.append(f"### {label}")
            for f in group:
                lines.append(f"- [ ] **{f.get('id', '')}**: {f.get('vulnerability', '')} — "
                             f"`{f.get('url', '')[:80]}`")
            lines.append("")

    lines.append("---")
    lines.append("")
    lines.append("*报告由 AI-Powered Passive Vulnerability Scanner v3.0 生成*  ")
    lines.append("*扫描模式: 被动流量分析 + 主动深度探索*  ")
    lines.append("*⚠️ 本报告基于已捕获的HTTP流量及主动探测结果进行AI分析，可能存在漏报或误报。*")
    lines.append("*主动探测仅使用只读安全载荷，未执行任何破坏性命令。*")

    report = '\n'.join(lines)

    with open(output_path, 'w', encoding='utf-8') as f:
        f.write(report)

    print(f"[+] Markdown report written to: {output_path}")
    return report


def main():
    parser = argparse.ArgumentParser(
        description='Format vulnerability findings into a Markdown report',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s findings.json -o report.md
  %(prog)s findings.json -o report.md --active-discoveries discovered_surface.json
  %(prog)s findings.json -o report.md --json-output findings_clean.json
        """
    )
    parser.add_argument('input', help='Input findings JSON file')
    parser.add_argument('-o', '--output', default='/tmp/vulnerability_report.md',
                        help='Output Markdown report path (default: /tmp/vulnerability_report.md)')
    parser.add_argument('--json-output', help='Also output cleaned JSON findings')
    parser.add_argument('--active-discoveries', help='Active discovery JSON (from active_explorer.py)')

    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"Error: Input file not found: {args.input}")
        sys.exit(1)

    with open(args.input, 'r', encoding='utf-8') as f:
        findings_data = json.load(f)

    # Load active discoveries if provided
    active_discoveries = None
    if args.active_discoveries:
        if os.path.exists(args.active_discoveries):
            with open(args.active_discoveries, 'r', encoding='utf-8') as f:
                active_discoveries = json.load(f)
        else:
            print(f"Warning: Active discoveries file not found: {args.active_discoveries}")

    if 'findings' not in findings_data:
        print("Warning: Input JSON missing 'findings' key, attempting to parse...")
        if isinstance(findings_data, list):
            findings_data = {'findings': findings_data}
        else:
            print("Error: Cannot determine findings structure.")
            sys.exit(1)

    # Merge active findings
    if active_discoveries:
        findings_data['findings'] = merge_active_findings(
            findings_data.get('findings', []), active_discoveries
        )
        findings = findings_data['findings']
        sev_counts = Counter(f.get('severity', 'Info') for f in findings)
        findings_data['summary'] = {
            'total_findings': len(findings),
            'by_severity': dict(sev_counts),
        }
        print(f"[+] Merged {len(findings)} total findings (including active discoveries)")

    generate_markdown_report(findings_data, args.output, active_discoveries)

    if args.json_output:
        with open(args.json_output, 'w', encoding='utf-8') as f:
            json.dump(findings_data, f, ensure_ascii=False, indent=2)
        print(f"[+] JSON findings written to: {args.json_output}")

    f = findings_data.get('findings', [])
    sev = Counter(x.get('severity', 'Info') for x in f)
    active_count = sum(1 for x in f if x.get('source') == 'active_deep_dive')
    print(f"\n[+] Report Summary: {len(f)} findings ({active_count} from active exploration)")
    for s in ['Critical', 'High', 'Medium', 'Low', 'Info']:
        if sev.get(s, 0) > 0:
            print(f"    {SEVERITY_ICONS.get(s, '')} {s}: {sev[s]}")


if __name__ == '__main__':
    main()
