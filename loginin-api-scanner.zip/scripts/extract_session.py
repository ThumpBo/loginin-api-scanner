#!/usr/bin/env python3
"""
Passive Vulnerability Scanner — Session & Attack Surface Extractor

Reads parsed traffic JSON (from parse_http.py) and extracts:
  - Authentication credentials (cookies, tokens, API keys)
  - Discovered URL paths (grouped, with admin/api prefix identification)
  - Admin panel URL candidates (inferred from known paths)
  - Form submission endpoints (POST/PUT with form data)
  - File upload endpoints (multipart/form-data)
  - Technology stack hints (from response headers and HTML)

Usage:
  python3 extract_session.py parsed_traffic.json -o session_state.json
"""

import json
import sys
import os
import re
import argparse
from urllib.parse import urlparse, urljoin
from collections import Counter, defaultdict


# ─── Tier 1 admin paths for inference ───
COMMON_ADMIN_PATHS = [
    '/admin', '/manager', '/console', '/dashboard', '/backend', '/system',
    '/manage', '/panel', '/cp', '/cms', '/config', '/setup', '/install',
    '/administrator', '/administration',
]

COMMON_ADMIN_PATHS_TIER2 = [
    '/phpmyadmin', '/phpMyAdmin', '/mysql', '/db', '/dbadmin', '/pgadmin',
    '/adminer', '/info.php', '/phpinfo.php', '/server-status',
    '/actuator', '/actuator/health', '/actuator/env', '/actuator/mappings',
    '/.env', '/.git/config', '/swagger-ui.html', '/api-docs',
    '/jmx-console', '/jenkins', '/grafana', '/kibana',
    '/solr/admin', '/tomcat/manager', '/zabbix', '/nagios', '/prometheus',
]

COMMON_ADMIN_PATHS_TIER3 = [
    '/wp-admin', '/wp-login.php', '/user/login',    # WordPress / Drupal
    '/django-admin/', '/accounts/login/',             # Django
    '/horizon', '/telescope', '/nova',                # Laravel
    '/rails/info', '/sidekiq',                        # Rails
    '/graphql', '/graphiql',                          # GraphQL
]

# Technology stack signature headers
TECH_HEADERS = {
    'X-Powered-By': None,           # e.g. 'PHP/8.1'
    'Server': None,                 # e.g. 'nginx/1.24', 'Apache/2.4'
    'X-Generator': None,            # e.g. 'Drupal', 'WordPress'
    'X-Runtime': None,              # Ruby on Rails
    'X-AspNet-Version': None,       # ASP.NET
    'X-AspNetMvc-Version': None,    # ASP.NET MVC
    'X-Drupal-Cache': None,         # Drupal
    'Set-Cookie': None,             # Session framework detection
}

# Framework cookie patterns
COOKIE_PATTERNS = {
    'JSESSIONID': 'Java (Tomcat/Spring/JBoss)',
    'PHPSESSID': 'PHP',
    'laravel_session': 'Laravel',
    'XSRF-TOKEN': 'Laravel/Express',
    'csrftoken': 'Django',
    '_csrf': 'Express.js',
    'ASP.NET_SessionId': 'ASP.NET',
    'WFESESSIONID': 'ASP.NET',
    'drupal_session': 'Drupal',
    'wordpress_logged_in': 'WordPress',
    'connect.sid': 'Express (connect/express-session)',
}


def extract_cookies(items):
    """Extract all cookies from request headers, deduplicate and merge by host."""
    cookie_map = defaultdict(dict)  # host -> {cookie_name: cookie_value}

    for item in items:
        host = item.get('host', '')
        if not host:
            continue

        req_headers = item.get('request_headers', {})
        cookie_str = req_headers.get('Cookie', '') or req_headers.get('cookie', '')

        if cookie_str:
            for part in cookie_str.split(';'):
                part = part.strip()
                if '=' in part:
                    key, value = part.split('=', 1)
                    key, value = key.strip(), value.strip()
                    if key and value:
                        cookie_map[host][key] = value

        # Also check response Set-Cookie
        resp_headers = item.get('response_headers', {})
        set_cookie = resp_headers.get('Set-Cookie', '') or resp_headers.get('set-cookie', '')
        if set_cookie:
            for part in set_cookie.split(';'):
                part = part.strip()
                if '=' in part:
                    key, value = part.split('=', 1)
                    key, value = key.strip(), value.strip()
                    if key and value and key.lower() not in ('path', 'domain', 'expires',
                                                               'max-age', 'httponly', 'secure',
                                                               'samesite', 'version', 'comment'):
                        cookie_map[host][key] = value

    return {host: dict(cookies) for host, cookies in cookie_map.items()}


def extract_auth_tokens(items):
    """Extract Authorization headers, CSRF tokens, and API keys."""
    tokens = defaultdict(lambda: {'auth_header': None, 'csrf_token': None, 'api_key': None})

    for item in items:
        host = item.get('host', '')
        if not host:
            continue

        req_headers = item.get('request_headers', {})

        # Authorization header
        auth = req_headers.get('Authorization', '') or req_headers.get('authorization', '')
        if auth and not tokens[host]['auth_header']:
            tokens[host]['auth_header'] = auth

        # CSRF tokens
        for header_name in ['X-CSRF-Token', 'X-CSRFToken', 'X-XSRF-TOKEN', 'X-Requested-With']:
            csrf = req_headers.get(header_name, '') or req_headers.get(header_name.lower(), '')
            if csrf and not tokens[host]['csrf_token']:
                tokens[host]['csrf_token'] = csrf

        # API keys
        for header_name in ['X-API-Key', 'X-Api-Key', 'Api-Key', 'apikey']:
            apikey = req_headers.get(header_name, '') or req_headers.get(header_name.lower(), '')
            if apikey and not tokens[host]['api_key']:
                tokens[host]['api_key'] = apikey

    return dict(tokens)


def extract_paths(items):
    """Collect all request paths, grouped by directory prefix."""
    paths = set()
    path_prefixes = Counter()

    for item in items:
        path = item.get('path', '/')
        if path:
            paths.add(path)
            # Group by first path segment
            if path != '/':
                first_seg = '/' + path.lstrip('/').split('/')[0]
                path_prefixes[first_seg] += 1

    return sorted(paths), dict(path_prefixes.most_common(20))


def identify_admin_candidates(paths, hosts, path_prefixes):
    """Generate admin panel URL candidates by combining hosts with common admin paths."""
    candidates = []

    # From known paths: identify admin-like prefixes
    admin_prefixes = set()
    for prefix, count in path_prefixes.items():
        if any(kw in prefix.lower() for kw in ('admin', 'manage', 'system', 'console',
                                                  'dashboard', 'backend', 'panel', 'config',
                                                  'api', 'graphql', 'setup', 'install')):
            admin_prefixes.add(prefix)

    # From known exact paths
    admin_paths_from_traffic = set()
    for path in paths:
        path_lower = path.lower()
        if any(kw in path_lower for kw in ('admin', 'login', 'manage', 'dashboard',
                                              'console', 'backend', 'config', 'setup',
                                              'system', 'panel', 'api/')):
            admin_paths_from_traffic.add(path)

    # Build candidates: host + inferred paths
    for host in hosts:
        # Tier 1: universal paths (highest priority)
        for p in COMMON_ADMIN_PATHS:
            candidates.append({'url': f"https://{host}{p}", 'host': host, 'path': p,
                               'source': 'tier1_universal', 'priority': 1})

        # Tier 2: web server / middleware
        for p in COMMON_ADMIN_PATHS_TIER2:
            candidates.append({'url': f"https://{host}{p}", 'host': host, 'path': p,
                               'source': 'tier2_middleware', 'priority': 2})

        # Tier 3: CMS specific
        for p in COMMON_ADMIN_PATHS_TIER3:
            candidates.append({'url': f"https://{host}{p}", 'host': host, 'path': p,
                               'source': 'tier3_cms', 'priority': 3})

        # Inferred from traffic (highest priority since directly observed)
        for prefix in admin_prefixes:
            for sub in ['', '/index', '/login', '/dashboard', '/config', '/system',
                        '/user', '/file', '/template', '/database']:
                full_path = prefix + sub
                if full_path not in admin_paths_from_traffic and full_path not in paths:
                    candidates.append({'url': f"https://{host}{full_path}",
                                       'host': host, 'path': full_path,
                                       'source': 'inferred', 'priority': 0})

        # Also try HTTP scheme
        for p in COMMON_ADMIN_PATHS[:5]:
            candidates.append({'url': f"http://{host}{p}", 'host': host, 'path': p,
                               'source': 'tier1_http', 'priority': 4})

    # Sort by priority (lower = check first)
    candidates.sort(key=lambda x: (x['priority'], x['path']))

    # Deduplicate by URL
    seen = set()
    unique = []
    for c in candidates:
        if c['url'] not in seen:
            seen.add(c['url'])
            unique.append(c)
            if len(unique) >= 200:  # Cap at 200 candidates
                break

    return unique


def identify_form_endpoints(items):
    """Identify form submission endpoints (POST/PUT with form data or JSON)."""
    form_endpoints = []
    seen = set()

    for item in items:
        method = item.get('method', 'GET').upper()
        if method not in ('POST', 'PUT', 'PATCH'):
            continue

        url = item.get('url', '')
        if url in seen:
            continue
        seen.add(url)

        req_body = item.get('request_body', '') or ''
        content_type = item.get('request_headers', {}).get('Content-Type', '')

        # Extract form field names from body
        fields = []
        if 'application/x-www-form-urlencoded' in content_type or '&' in req_body:
            for part in req_body.split('&'):
                if '=' in part:
                    fields.append(part.split('=')[0])

        if fields or method == 'POST':
            form_endpoints.append({
                'url': url,
                'host': item.get('host', ''),
                'path': item.get('path', '/'),
                'method': method,
                'content_type': content_type,
                'fields': fields
            })

    return form_endpoints


def identify_upload_endpoints(items):
    """Identify file upload endpoints (multipart/form-data)."""
    upload_endpoints = []
    seen = set()

    for item in items:
        method = item.get('method', 'GET').upper()
        if method not in ('POST', 'PUT'):
            continue

        content_type = item.get('request_headers', {}).get('Content-Type', '')
        if 'multipart/form-data' not in content_type:
            continue

        url = item.get('url', '')
        if url in seen:
            continue
        seen.add(url)

        req_body = item.get('request_body', '') or ''
        # Extract filename from Content-Disposition
        filenames = re.findall(r'filename="([^"]+)"', req_body)
        field_names = re.findall(r'name="([^"]+)"', req_body)

        upload_endpoints.append({
            'url': url,
            'host': item.get('host', ''),
            'path': item.get('path', '/'),
            'method': method,
            'field_name': field_names[0] if field_names else 'file',
            'observed_filenames': filenames
        })

    return upload_endpoints


def extract_base_urls(items):
    """Extract unique scheme+host combinations."""
    targets = []
    seen = set()

    for item in items:
        url = item.get('url', '')
        if not url:
            continue
        parsed = urlparse(url)
        base = f"{parsed.scheme}://{parsed.netloc}"
        if base not in seen and parsed.netloc:
            seen.add(base)
            targets.append({
                'base_url': base,
                'host': parsed.netloc.split(':')[0],
                'scheme': parsed.scheme,
                'port': parsed.port or (443 if parsed.scheme == 'https' else 80)
            })

    return targets


def detect_tech_stack(items):
    """Detect technology stack from response headers and cookies."""
    hints = set()
    frameworks = set()

    for item in items:
        resp_headers = item.get('response_headers', {})
        req_headers = item.get('request_headers', {})

        # Check for tech headers
        for header_name in TECH_HEADERS:
            value = resp_headers.get(header_name, '') or resp_headers.get(header_name.lower(), '')
            if value:
                hints.add(f"{header_name}: {value}")
                if 'PHP' in value:
                    frameworks.add('PHP')
                if 'nginx' in value.lower():
                    frameworks.add('nginx')
                if 'apache' in value.lower():
                    frameworks.add('Apache')
                if 'Werkzeug' in value:
                    frameworks.add('Flask')
                if 'ASP.NET' in value:
                    frameworks.add('ASP.NET')

        # Check for framework-specific cookies
        cookie_str = req_headers.get('Cookie', '') or req_headers.get('cookie', '')
        resp_cookie = resp_headers.get('Set-Cookie', '') or resp_headers.get('set-cookie', '')
        all_cookies = cookie_str + '; ' + resp_cookie

        for pattern, framework in COOKIE_PATTERNS.items():
            if pattern in all_cookies:
                frameworks.add(framework)

        # Check response body for framework hints
        body = (item.get('response_body', '') or '')[:5000]
        if 'wp-content' in body or 'wp-includes' in body:
            frameworks.add('WordPress')
        if 'Drupal' in body and 'drupal' in body.lower():
            frameworks.add('Drupal')
        if 'Laravel' in body or 'laravel' in body.lower():
            frameworks.add('Laravel')
        if 'swagger' in body.lower() or 'Swagger UI' in body:
            frameworks.add('Swagger')
        if 'actuator' in body.lower():
            frameworks.add('Spring Boot')

    return sorted(hints), sorted(frameworks)


def main():
    parser = argparse.ArgumentParser(
        description='Extract session credentials and attack surface from parsed HTTP traffic',
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Examples:
  %(prog)s parsed_traffic.json -o session_state.json
  %(prog)s parsed_traffic.json -o session_state.json --min-items 5
        """
    )
    parser.add_argument('input', help='Parsed traffic JSON file (from parse_http.py)')
    parser.add_argument('-o', '--output', default='/tmp/session_state.json',
                        help='Output session state JSON (default: /tmp/session_state.json)')
    parser.add_argument('--min-items', type=int, default=3,
                        help='Minimum traffic items required (default: 3)')

    args = parser.parse_args()

    if not os.path.exists(args.input):
        print(f"Error: Input file not found: {args.input}")
        sys.exit(1)

    with open(args.input, 'r', encoding='utf-8') as f:
        data = json.load(f)

    items = data.get('items', [])
    if len(items) < args.min_items:
        print(f"Error: Too few traffic items ({len(items)}). Need at least {args.min_items}.")
        sys.exit(1)

    print(f"[+] Analyzing {len(items)} HTTP requests...")

    # Extract
    cookies = extract_cookies(items)
    auth_tokens = extract_auth_tokens(items)
    paths, path_prefixes = extract_paths(items)
    targets = extract_base_urls(items)
    hosts = [t['host'] for t in targets]
    admin_candidates = identify_admin_candidates(paths, hosts, path_prefixes)
    form_endpoints = identify_form_endpoints(items)
    upload_endpoints = identify_upload_endpoints(items)
    tech_headers, frameworks = detect_tech_stack(items)

    # Build sessions
    sessions = []
    for host in hosts:
        session = {'host': host}
        if host in cookies:
            session['cookies'] = cookies[host]
        if host in auth_tokens:
            session.update({k: v for k, v in auth_tokens[host].items() if v})
        sessions.append(session)

    # Build output
    output = {
        'targets': targets,
        'sessions': sessions,
        'discovered_paths': paths,
        'path_prefixes': path_prefixes,
        'admin_candidates': admin_candidates,
        'form_endpoints': form_endpoints,
        'upload_endpoints': upload_endpoints,
        'tech_stack': {
            'headers': tech_headers,
            'frameworks': frameworks
        },
        'statistics': {
            'total_items': len(items),
            'unique_hosts': len(hosts),
            'unique_paths': len(paths),
            'sessions_extracted': len([s for s in sessions if s.get('cookies') or s.get('auth_header')]),
            'admin_candidates_generated': len(admin_candidates),
            'form_endpoints_found': len(form_endpoints),
            'upload_endpoints_found': len(upload_endpoints)
        }
    }

    with open(args.output, 'w', encoding='utf-8') as f:
        json.dump(output, f, ensure_ascii=False, indent=2)

    # Summary
    stats = output['statistics']
    print(f"\n[+] Session State extracted successfully")
    print(f"    Targets: {', '.join(hosts)}")
    print(f"    Sessions with credentials: {stats['sessions_extracted']}/{stats['unique_hosts']}")
    print(f"    Discovered paths: {stats['unique_paths']}")
    print(f"    Admin candidates: {stats['admin_candidates_generated']}")
    print(f"    Form endpoints: {stats['form_endpoints_found']}")
    print(f"    Upload endpoints: {stats['upload_endpoints_found']}")
    if frameworks:
        print(f"    Detected tech: {', '.join(frameworks)}")
    print(f"    Output: {args.output}")


if __name__ == '__main__':
    main()
